/**
 * CoFlow 设计令牌字典（方向二：纸上实验室 Archival Lab Ledger）
 * 所有色值、字号、圆角、阴影均映射自 src/index.css 中的 CSS Custom Properties
 */

export interface ColorTokenSpec {
  name: string
  cssVar: string
  hex: string
  usage: string
  textPreviewColor?: string
}

export interface SemanticColorTokenSpec {
  key: 'success' | 'warning' | 'danger' | 'info' | 'neutral'
  label: string
  alias: string
  inkVar: string
  inkHex: string
  bgVar: string
  bgHex: string
  borderVar: string
  borderHex: string
  usage: string
}

export const SURFACE_TOKENS: ColorTokenSpec[] = [
  {
    name: '纸面 (Paper Base)',
    cssVar: '--cf-surface-paper',
    hex: '#EFECE6',
    usage: '工作台全局底面；承载讨论流、Agent 事件流等未定稿"过程"区域，视觉自然退后',
  },
  {
    name: '卡面 (Fact Card)',
    cssVar: '--cf-surface-card',
    hex: '#FAF8F5',
    usage: '无酸档案纸白；承载项目章程、已拆解任务、证据产物、人工验收记录等"当前事实"',
  },
  {
    name: '次级面 (Secondary Cell)',
    cssVar: '--cf-surface-secondary',
    hex: '#F3EFE8',
    usage: '台账表头、卡片底栏、Key-Value 标签键名槽、输入框默认静默底面',
  },
  {
    name: '三级面 (Tertiary Well)',
    cssVar: '--cf-surface-tertiary',
    hex: '#E5E0D5',
    usage: '深度内凹槽、弱化归档容器、禁用控件底色、旁路取消态底板、进度条轨道',
  },
]

export const TEXT_TOKENS: ColorTokenSpec[] = [
  {
    name: '一级文字 (Primary Ink)',
    cssVar: '--cf-text-primary',
    hex: '#1C1917',
    usage: '碳素墨水黑；用于任务标题、章程条款正文、已确认事实结论、表头核心字段',
  },
  {
    name: '二级文字 (Secondary Graphite)',
    cssVar: '--cf-text-secondary',
    hex: '#44403C',
    usage: '深暖石墨；用于产物说明、验收标准、表格常规数据列、次要按钮文字',
  },
  {
    name: '三级文字 (Tertiary Pencil)',
    cssVar: '--cf-text-tertiary',
    hex: '#78716C',
    usage: '铅笔边注灰；用于讨论过程文本、时间戳、键值对键名、列表辅助元数据',
  },
  {
    name: '四级文字 (Muted Seal)',
    cssVar: '--cf-text-muted',
    hex: '#A8A29E',
    usage: '封存浅灰；用于禁用态文案、输入框占位符、已取消/归档任务弱化文字',
  },
]

export const DIVIDER_TOKENS: ColorTokenSpec[] = [
  {
    name: '一级强分割线 (Strong Rule)',
    cssVar: '--cf-border-strong',
    hex: '#C7C0B3',
    usage: '事实卡片外框、表格外框与表头下沿主分割线、表单输入控件默认边框',
  },
  {
    name: '二级弱分割线 (Subtle Gridline)',
    cssVar: '--cf-border-subtle',
    hex: '#E4DFD5',
    usage: '台账表格行间分割线、卡片内部分区细线、Key-Value 单元格内部隔断',
  },
]

export const PRIMARY_TOKENS: ColorTokenSpec[] = [
  {
    name: '主色标准 · 深墨青 (Primary)',
    cssVar: '--cf-primary',
    hex: '#0F5257',
    usage: '核心主操作按钮、激活态导航指示、进行中任务主框、自动接入徽标',
    textPreviewColor: '#FAF8F5',
  },
  {
    name: '主色深色 · 浓墨青 (Primary Deep)',
    cssVar: '--cf-primary-deep',
    hex: '#09383C',
    usage: '主要按钮悬停/按压态、高优先级焦点激活外框',
    textPreviewColor: '#FAF8F5',
  },
  {
    name: '主色浅底 · 青瓷浅底 (Primary Tint)',
    cssVar: '--cf-primary-tint',
    hex: '#E3F1F2',
    usage: '表格选中行底色、自动接入能力徽标底、输入框聚焦光晕底（配边框 #8AC4C8）',
    textPreviewColor: '#0F5257',
  },
]

export const SEMANTIC_TOKENS: SemanticColorTokenSpec[] = [
  {
    key: 'success',
    label: '成功 (Success)',
    alias: '档案印章绿',
    inkVar: '--cf-success',
    inkHex: '#15803D',
    bgVar: '--cf-success-bg',
    bgHex: '#ECFDF3',
    borderVar: '--cf-success-border',
    borderHex: '#86EFAC',
    usage: '人工验收通过、已完成状态印章、本地连接器在线心跳、校验通过提示',
  },
  {
    key: 'warning',
    label: '警告 (Warning)',
    alias: '火漆琥珀棕',
    inkVar: '--cf-warning',
    inkHex: '#B45309',
    bgVar: '--cf-warning-bg',
    bgHex: '#FFFBEB',
    borderVar: '--cf-warning-border',
    borderHex: '#FCD34D',
    usage: '待澄清/待验收状态、中风险提示、半自动能力降级说明、上下文 Token 逼近阈值',
  },
  {
    key: 'danger',
    label: '危险 (Danger)',
    alias: '朱砂批注红',
    inkVar: '--cf-danger',
    inkHex: '#B91C1C',
    bgVar: '--cf-danger-bg',
    bgHex: '#FEF2F2',
    borderVar: '--cf-danger-border',
    borderHex: '#FCA5A5',
    usage: '任务已阻塞、高风险告警、P0 紧急标签、危险删除/驳回操作、表单校验错误',
  },
  {
    key: 'info',
    label: '信息 (Info)',
    alias: '钢笔蓝',
    inkVar: '--cf-info',
    inkHex: '#0369A1',
    bgVar: '--cf-info-bg',
    bgHex: '#F0F9FF',
    borderVar: '--cf-info-border',
    borderHex: '#7DD3FC',
    usage: '已就绪状态、系统规则说明提示条、上下文包同步状态、低风险观察项',
  },
  {
    key: 'neutral',
    label: '中性 (Neutral)',
    alias: '石墨岩灰',
    inkVar: '--cf-neutral',
    inkHex: '#57534E',
    bgVar: '--cf-neutral-bg',
    bgHex: '#F3F1ED',
    borderVar: '--cf-neutral-border',
    borderHex: '#D6D1C7',
    usage: '待认领状态、已暂停/已取消旁路状态、手动能力等级、常规角色与 KV 标签',
  },
]

export interface TypographyTierSpec {
  level: string
  name: string
  sizeVar: string
  lhVar: string
  sizePx: string
  lineHeight: string
  weight: string
  usage: string
  sampleText: string
}

export const TYPOGRAPHY_SCALE: TypographyTierSpec[] = [
  {
    level: 'T1',
    name: '页面 / 章程主标题',
    sizeVar: '--cf-t1-size',
    lhVar: '--cf-t1-lh',
    sizePx: '20px',
    lineHeight: '28px (1.40)',
    weight: '600 SemiBold',
    usage: '项目总章程标题、工作台一级视图主标题',
    sampleText: 'CoFlow 多智能体协同检索系统 · 项目总章程 (v2.4)',
  },
  {
    level: 'T2',
    name: '模块 / 分区主标题',
    sizeVar: '--cf-t2-size',
    lhVar: '--cf-t2-lh',
    sizePx: '16px',
    lineHeight: '24px (1.50)',
    weight: '600 SemiBold',
    usage: '当前事实看板标题、详情抽屉顶栏标题、模态框标题',
    sampleText: '当前事实台账：待人工核验产物与验收结论',
  },
  {
    level: 'T3',
    name: '卡片 / 子组小标题',
    sizeVar: '--cf-t3-size',
    lhVar: '--cf-t3-lh',
    sizePx: '14px',
    lineHeight: '22px (1.57)',
    weight: '600 SemiBold',
    usage: '重点任务卡片标题、产物证据包名称、空状态标题',
    sampleText: '向量召回率评测基准与章程第 4.2 条对齐核验',
  },
  {
    level: 'T4',
    name: '标准正文 (核心基线)',
    sizeVar: '--cf-t4-size',
    lhVar: '--cf-t4-lh',
    sizePx: '13px',
    lineHeight: '20px (1.54)',
    weight: '400 / 500',
    usage: 'Windows 1440×900 全局默认字号：任务列表标题、章程正文、验收意见、输入框内容',
    sampleText: '聊天只是过程，只有被确认的决策、带证据的产物、人工给出的验收结论才计入项目事实。',
  },
  {
    level: 'T5',
    name: '紧凑辅助 / 表格正文',
    sizeVar: '--cf-t5-size',
    lhVar: '--cf-t5-lh',
    sizePx: '12px',
    lineHeight: '18px (1.50)',
    weight: '400 / 500',
    usage: '风险一句话说明、半自动降级说明、讨论流消息、按钮文案、表格常规列',
    sampleText: '降级说明：本地连接器未授予自动写库权限，Agent 产出补丁后需由负责人手动点击签批合入。',
  },
  {
    level: 'T6',
    name: '徽标与键值对标签',
    sizeVar: '--cf-t6-size',
    lhVar: '--cf-t6-lh',
    sizePx: '11px',
    lineHeight: '16px (1.45)',
    weight: '500 / 600',
    usage: '20px 状态徽标文字、角色标签、能力等级徽标、表格列头、Key-Value 小标签',
    sampleText: '待验收 · 评审人 · 自动接入 · 证据完整度 3/3',
  },
  {
    level: 'T7',
    name: '极小角标 / 等宽微标',
    sizeVar: '--cf-t7-size',
    lhVar: '--cf-t7-lh',
    sizePx: '10px',
    lineHeight: '14px (1.40)',
    weight: '600 SemiBold',
    usage: 'P0–P3 优先级角标、版本号尾缀、快捷键提示、头像组 +N 溢出计数',
    sampleText: 'P0 · CHR-04 · +6 · CTRL+ENTER',
  },
]
