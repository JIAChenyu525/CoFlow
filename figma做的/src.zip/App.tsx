import { useState } from 'react'
import { ProjectWorkbench } from './workbench/ProjectWorkbench'
import { TaskBoardPage } from './pages/TaskBoardPage'
import { TaskDetailPage } from './pages/TaskDetailPage'
import { ContextPackPage } from './pages/ContextPackPage'
import { ProjectHallPage } from './pages/ProjectHallPage'
import { NewProjectWizardPage } from './pages/NewProjectWizardPage'
import { ProjectSettingsPage } from './pages/ProjectSettingsPage'
import { AgentConnectPage } from './pages/AgentConnectPage'
import { ArtifactsAcceptancePage } from './pages/ArtifactsAcceptancePage'
import { DecisionsTimelinePage } from './pages/DecisionsTimelinePage'
import { LoginPage } from './pages/LoginPage'
import { WeeklyReportPage } from './pages/WeeklyReportPage'
import { OnboardingPage } from './pages/OnboardingPage'
import { EventProtocolPage } from './pages/EventProtocolPage'
import { MobileSuitePage } from './pages/MobileSuitePage'
import {
  FinalAuditAndStatesPage,
  CanonicalPageKey,
} from './pages/FinalAuditAndStatesPage'
import { INITIAL_TASKS, CoFlowTask } from './data/mockTasks'
import { INITIAL_PROJECTS, ProjectSummaryItem } from './data/mockProjects'
import {
  SURFACE_TOKENS,
  TEXT_TOKENS,
  DIVIDER_TOKENS,
  PRIMARY_TOKENS,
  SEMANTIC_TOKENS,
  TYPOGRAPHY_SCALE,
} from './design-system/tokens'
import {
  TASK_STATUS_LIST,
  TaskStatusBadge,
  PriorityBadge,
  ROLE_LIST,
  RoleBadge,
  CapabilityBadge,
  RiskRowItem,
  CfButton,
  InlineBanner,
  SingleAvatar,
  AvatarGroup,
  CollaboratorAvatarItem,
  ThinProgressBar,
  StandardProgressBar,
  ContextBudgetProgressBar,
  KeyValueTag,
  TaskStatus,
  PriorityLevel,
  RoleType,
} from './design-system/components'

const SAMPLE_COLLABORATORS: CollaboratorAvatarItem[] = [
  { id: 'u1', name: '林知夏 (发起人)', short: '林', kind: 'human' },
  { id: 'u2', name: '陈默 (任务主理)', short: '陈', kind: 'human' },
  { id: 'a1', name: 'cursor-win-02 (本地 Agent)', short: 'AI', kind: 'agent' },
  { id: 'u3', name: '苏哲 (内容与评测)', short: '苏', kind: 'human' },
  { id: 'a2', name: 'claude-code-01 (本地 Agent)', short: 'CC', kind: 'agent' },
  { id: 'u4', name: '周舟 (竞赛算法)', short: '周', kind: 'human' },
  { id: 'u5', name: '顾言 (评审观察)', short: '顾', kind: 'human' },
  { id: 'a3', name: 'windsurf-node-03 (本地 Agent)', short: 'WS', kind: 'agent' },
]

interface LedgerRow {
  id: string
  title: string
  status: TaskStatus
  priority: PriorityLevel
  capability: 'auto' | 'semi' | 'manual'
  connector: string
  version: string
  tokens: number
  evidenceCount: string
  progress: number
}

const LEDGER_ROWS: LedgerRow[] = [
  {
    id: 'TSK-104',
    title: '项目总章程 v2.4 检索精度基线条款锁定',
    status: 'done',
    priority: 'P0',
    capability: 'manual',
    connector: 'human-review',
    version: 'v2.4.0',
    tokens: 4280,
    evidenceCount: '3/3',
    progress: 100,
  },
  {
    id: 'TSK-108',
    title: '向量检索模块召回率评测与章程指标对齐',
    status: 'pending_accept',
    priority: 'P0',
    capability: 'auto',
    connector: 'cursor-win-02',
    version: 'v1.4.2-rc',
    tokens: 32640,
    evidenceCount: '2/3',
    progress: 85,
  },
  {
    id: 'TSK-112',
    title: '多模态竞赛数据集清洗脚本与异常样本剔除',
    status: 'in_progress',
    priority: 'P1',
    capability: 'semi',
    connector: 'claude-code-01',
    version: 'v0.9.1',
    tokens: 18910,
    evidenceCount: '1/2',
    progress: 60,
  },
  {
    id: 'TSK-115',
    title: '跨节点本地连接器 MCP 断连重传机制验证',
    status: 'blocked',
    priority: 'P0',
    capability: 'auto',
    connector: 'windsurf-03',
    version: 'v1.1.0-alpha',
    tokens: 29450,
    evidenceCount: '0/2',
    progress: 35,
  },
  {
    id: 'TSK-119',
    title: '评审答辩演示文稿与核心实验证据截图归档',
    status: 'clarify',
    priority: 'P2',
    capability: 'manual',
    connector: 'unassigned',
    version: 'v0.1.0',
    tokens: 1200,
    evidenceCount: '0/1',
    progress: 15,
  },
]

export default function App() {
  const [activePage, setActivePage] = useState<
    | 'final_audit'
    | 'mobile_suite'
    | 'login'
    | 'weekly_report'
    | 'onboarding'
    | 'event_protocol'
    | 'agent_connect'
    | 'artifacts_acceptance'
    | 'decisions_timeline'
    | 'project_hall'
    | 'new_project_wizard'
    | 'project_settings'
    | 'workbench'
    | 'task_board'
    | 'new_task_modal_page'
    | 'task_detail'
    | 'context_pack'
    | 'design_system'
  >('final_audit')
  const [currentRole, setCurrentRole] = useState<RoleType>('initiator')
  const [tasks, setTasks] = useState<CoFlowTask[]>(INITIAL_TASKS)
  const [selectedTaskId, setSelectedTaskId] = useState<string>('TSK-114')
  const [projects, setProjects] = useState<ProjectSummaryItem[]>(INITIAL_PROJECTS)
  const [selectedProjectId, setSelectedProjectId] = useState<string>('prj-zx')

  const [activeSheet, setActiveSheet] = useState<'both' | 'tokens' | 'components'>('both')
  const [grayscaleMode, setGrayscaleMode] = useState(false)
  const [dsTableEmpty, setDsTableEmpty] = useState(false)
  const [checkboxStates, setCheckboxStates] = useState({
    evidenceRequired: true,
    autoSyncContext: false,
  })

  const handleUpdateTask = (updated: CoFlowTask) => {
    setTasks((prev) => prev.map((t) => (t.id === updated.id ? updated : t)))
  }

  const handleCreateTask = (newTask: CoFlowTask) => {
    setTasks((prev) => [newTask, ...prev])
  }

  const handleOpenCanonicalPage = ({
    page,
    role,
  }: {
    page: CanonicalPageKey
    role?: 'initiator' | 'member' | 'observer'
  }) => {
    if (role) setCurrentRole(role)
    const map: Record<CanonicalPageKey, typeof activePage> = {
      p01_login: 'login',
      p02_hall: 'project_hall',
      p03_wizard: 'new_project_wizard',
      p04_workbench: 'workbench',
      p05_board: 'task_board',
      p06_new_task: 'new_task_modal_page',
      p07_detail: 'task_detail',
      p08_context: 'context_pack',
      p09_artifacts: 'artifacts_acceptance',
      p10_decisions: 'decisions_timeline',
      p11_agent: 'agent_connect',
      p12_settings: 'project_settings',
      p13_weekly: 'weekly_report',
      p14_protocol: 'event_protocol',
      m_suite: 'mobile_suite',
      ds_tokens: 'design_system',
      ds_components: 'design_system',
    }
    if (page === 'ds_tokens') setActiveSheet('tokens')
    if (page === 'ds_components') setActiveSheet('components')
    setActivePage(map[page])
  }

  const currentProject =
    projects.find((p) => p.id === selectedProjectId) || projects[0]

  if (activePage === 'workbench') {
    return (
      <div className="flex h-screen w-full flex-col overflow-hidden">
        <div
          style={{
            backgroundColor: 'var(--cf-primary-deep)',
            borderBottom: '1px solid var(--cf-primary-border)',
            color: 'var(--cf-surface-card)',
          }}
          className="flex h-[32px] shrink-0 items-center justify-between px-4 text-[11px]"
        >
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActivePage('final_audit')}
              className="border border-[#8AC4C8] bg-[#0F5257] px-2 py-0.5 font-semibold text-white"
            >
              ← 返回状态稿总览 & 01–14 交付清单
            </button>
            <button
              type="button"
              onClick={() => setActivePage('project_hall')}
              className="border border-[#8AC4C8]/60 px-2 py-0.5 text-[#E3F1F2] hover:bg-[#0F5257]"
            >
              02 项目大厅
            </button>
            <button
              type="button"
              onClick={() => setActivePage('task_board')}
              className="border border-[#8AC4C8]/60 px-2 py-0.5 text-[#E3F1F2] hover:bg-[#0F5257]"
            >
              05 任务看板 →
            </button>
          </div>
          <button
            type="button"
            onClick={() => setActivePage('design_system')}
            className="underline text-[#E3F1F2]"
          >
            查阅设计令牌与组件库
          </button>
        </div>
        <div className="flex-1 overflow-hidden">
          <ProjectWorkbench onOpenDesignSystem={() => setActivePage('design_system')} />
        </div>
      </div>
    )
  }

  if (
    activePage === 'final_audit' ||
    activePage === 'mobile_suite' ||
    activePage === 'login' ||
    activePage === 'weekly_report' ||
    activePage === 'onboarding' ||
    activePage === 'event_protocol' ||
    activePage === 'agent_connect' ||
    activePage === 'artifacts_acceptance' ||
    activePage === 'decisions_timeline' ||
    activePage === 'project_hall' ||
    activePage === 'new_project_wizard' ||
    activePage === 'project_settings' ||
    activePage === 'task_board' ||
    activePage === 'new_task_modal_page' ||
    activePage === 'task_detail' ||
    activePage === 'context_pack'
  ) {
    const isObserver = currentRole === 'observer'
    return (
      <div
        style={{
          backgroundColor: 'var(--cf-surface-paper)',
          color: 'var(--cf-text-primary)',
        }}
        className="flex h-screen w-full flex-col overflow-hidden select-none"
      >
        {/* 统一顶栏：状态稿与交付总览 + 01–14 规范命名页面 + 移动页 + 令牌组件库 + 五角色切换 */}
        <header
          style={{
            backgroundColor: 'var(--cf-primary)',
            borderBottom: '1px solid var(--cf-primary-deep)',
            color: 'var(--cf-surface-card)',
          }}
          className="flex h-[44px] shrink-0 items-center justify-between gap-2 px-3"
        >
          {/* 左侧：品牌与本轮四页主导航 + 全站已建页面导航 */}
          <div className="flex items-center gap-1.5 overflow-x-auto">
            <button
              type="button"
              onClick={() => setActivePage('final_audit')}
              style={{
                backgroundColor:
                  activePage === 'final_audit'
                    ? 'var(--cf-surface-card)'
                    : 'var(--cf-primary-deep)',
                color:
                  activePage === 'final_audit'
                    ? 'var(--cf-primary-deep)'
                    : '#A7F3D0',
                borderColor: 'var(--cf-primary-border)',
              }}
              className="h-[26px] shrink-0 border px-2 font-mono-tabular text-[11px] font-bold"
            >
              [交付总览 & 状态稿]
            </button>

            <nav
              style={{
                backgroundColor: 'var(--cf-primary-deep)',
                borderColor: 'var(--cf-primary-border)',
              }}
              className="flex shrink-0 items-center border p-0.5 text-[11px]"
            >
              {[
                { id: 'login', label: '01 登录' },
                { id: 'project_hall', label: '02 项目大厅' },
                { id: 'new_project_wizard', label: '03 新建向导' },
                { id: 'workbench', label: '04 工作台' },
                { id: 'task_board', label: '05 任务看板' },
                { id: 'new_task_modal_page', label: '06 新建任务' },
                { id: 'task_detail', label: '07 任务详情' },
                { id: 'context_pack', label: '08 上下文包' },
                { id: 'artifacts_acceptance', label: '09 产物验收' },
                { id: 'decisions_timeline', label: '10 决策时间线' },
                { id: 'agent_connect', label: '11 Agent连接' },
                { id: 'project_settings', label: '12 项目设置' },
                { id: 'weekly_report', label: '13 周报' },
                { id: 'event_protocol', label: '14 事件协议' },
                { id: 'onboarding', label: '上手闭环' },
                { id: 'mobile_suite', label: '移动三页' },
                { id: 'design_system', label: '令牌组件库' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActivePage(tab.id as typeof activePage)}
                  style={{
                    backgroundColor:
                      activePage === tab.id ? 'var(--cf-surface-card)' : 'transparent',
                    color:
                      activePage === tab.id
                        ? 'var(--cf-primary-deep)'
                        : 'var(--cf-surface-card)',
                  }}
                  className="h-[24px] shrink-0 px-1.5 font-medium transition-colors"
                >
                  {tab.label}
                </button>
              ))}
            </nav>

            {isObserver && (
              <span
                style={{
                  backgroundColor: 'var(--cf-warning)',
                  color: 'var(--cf-surface-card)',
                }}
                className="inline-flex h-[22px] shrink-0 items-center gap-1 px-2 text-[11px] font-semibold"
              >
                <span>当前身份只读（观察员）</span>
              </span>
            )}
          </div>

          {/* 右侧：全局五角色身份切换器（用于验证项目设置中「仅发起人可改角色，非发起人只读」等规则） */}
          <div className="flex shrink-0 items-center gap-2">
            <div
              style={{
                backgroundColor: 'var(--cf-primary-deep)',
                borderColor: 'var(--cf-primary-border)',
              }}
              className="flex items-center border p-0.5 text-[11px]"
            >
              <span className="px-1.5 text-[#A7F3D0] opacity-85">当前身份:</span>
              {(
                [
                  { role: 'initiator', label: '发起人' },
                  { role: 'owner', label: '负责人' },
                  { role: 'reviewer', label: '评审' },
                  { role: 'member', label: '成员' },
                  { role: 'observer', label: '观察员(只读)' },
                ] as { role: RoleType; label: string }[]
              ).map((item) => (
                <button
                  key={item.role}
                  type="button"
                  onClick={() => setCurrentRole(item.role)}
                  style={{
                    backgroundColor:
                      currentRole === item.role ? 'var(--cf-surface-card)' : 'transparent',
                    color:
                      currentRole === item.role
                        ? 'var(--cf-primary-deep)'
                        : 'var(--cf-surface-card)',
                  }}
                  className="h-[22px] px-2 font-medium transition-colors"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </header>

        {/* 页面主体 */}
        <div className="flex-1 overflow-hidden">
          {activePage === 'final_audit' && (
            <FinalAuditAndStatesPage
              onOpenPageWithPreset={handleOpenCanonicalPage}
            />
          )}

          {activePage === 'mobile_suite' && (
            <MobileSuitePage
              tasks={tasks}
              currentRole={currentRole}
              onUpdateTask={handleUpdateTask}
            />
          )}

          {activePage === 'login' && (
            <LoginPage
              onLoginSuccess={() => setActivePage('project_hall')}
              onOpenEventProtocol={() => setActivePage('event_protocol')}
            />
          )}

          {activePage === 'weekly_report' && (
            <WeeklyReportPage
              onOpenOnboarding={() => setActivePage('onboarding')}
            />
          )}

          {activePage === 'onboarding' && (
            <OnboardingPage
              onNavigateTo={(target) => setActivePage(target)}
            />
          )}

          {activePage === 'event_protocol' && <EventProtocolPage />}

          {activePage === 'agent_connect' && (
            <AgentConnectPage currentRole={currentRole} />
          )}

          {activePage === 'artifacts_acceptance' && (
            <ArtifactsAcceptancePage
              tasks={tasks}
              currentRole={currentRole}
              onGoToTaskAcceptance={(taskId) => {
                setSelectedTaskId(taskId)
                setActivePage('task_detail')
              }}
            />
          )}

          {activePage === 'decisions_timeline' && <DecisionsTimelinePage />}

          {activePage === 'project_hall' && (
            <ProjectHallPage
              projects={projects}
              onEnterProjectWorkbench={(prjId) => {
                setSelectedProjectId(prjId)
                setActivePage('workbench')
              }}
              onOpenProjectSettings={(prjId) => {
                setSelectedProjectId(prjId)
                setActivePage('project_settings')
              }}
              onStartCreateProject={() => setActivePage('new_project_wizard')}
            />
          )}

          {activePage === 'new_project_wizard' && (
            <NewProjectWizardPage
              onCancel={() => setActivePage('project_hall')}
              onProjectCreated={(newPrj) => {
                setProjects((prev) => [newPrj, ...prev])
                setSelectedProjectId(newPrj.id)
                setActivePage('project_hall')
              }}
            />
          )}

          {activePage === 'project_settings' && (
            <ProjectSettingsPage
              project={currentProject}
              currentRole={currentRole}
              onUpdateProject={(updated) => {
                setProjects((prev) =>
                  prev.map((p) => (p.id === updated.id ? updated : p))
                )
              }}
              onBackToHall={() => setActivePage('project_hall')}
            />
          )}

          {activePage === 'task_board' && (
            <TaskBoardPage
              key="board-normal"
              tasks={tasks}
              currentRole={currentRole}
              onSelectTask={(taskId) => {
                setSelectedTaskId(taskId)
                setActivePage('task_detail')
              }}
              onCreateTask={handleCreateTask}
              defaultOpenCreateModal={false}
            />
          )}

          {activePage === 'new_task_modal_page' && (
            <TaskBoardPage
              key="board-create-modal"
              tasks={tasks}
              currentRole={currentRole}
              onSelectTask={(taskId) => {
                setSelectedTaskId(taskId)
                setActivePage('task_detail')
              }}
              onCreateTask={handleCreateTask}
              defaultOpenCreateModal={true}
            />
          )}

          {activePage === 'task_detail' && (
            <TaskDetailPage
              tasks={tasks}
              selectedTaskId={selectedTaskId}
              currentRole={currentRole}
              onSelectTask={(taskId) => setSelectedTaskId(taskId)}
              onUpdateTask={handleUpdateTask}
              onNavigateToBoard={() => setActivePage('task_board')}
              onNavigateToContextPack={(taskId) => {
                setSelectedTaskId(taskId)
                setActivePage('context_pack')
              }}
            />
          )}

          {activePage === 'context_pack' && (
            <ContextPackPage
              tasks={tasks}
              selectedTaskId={selectedTaskId}
              currentRole={currentRole}
              onSelectTask={(taskId) => setSelectedTaskId(taskId)}
              onBackToTaskDetail={() => setActivePage('task_detail')}
            />
          )}
        </div>
      </div>
    )
  }

  return (
    <div
      style={{
        backgroundColor: 'var(--cf-surface-paper)',
        color: 'var(--cf-text-primary)',
      }}
      className="min-h-screen pb-14"
    >
      {/* =====================================================================
          顶部规格书控制栏 (Specification Sheet Header)
         ===================================================================== */}
      <header
        style={{
          backgroundColor: 'var(--cf-primary)',
          borderBottom: '1px solid var(--cf-primary-deep)',
          color: 'var(--cf-surface-card)',
        }}
        className="sticky top-0 z-30"
      >
        <div className="mx-auto flex max-w-[1440px] flex-wrap items-center justify-between gap-3 px-6 py-2.5">
          <div className="flex items-center gap-3">
            <span
              style={{
                backgroundColor: 'var(--cf-primary-deep)',
                borderColor: 'var(--cf-primary-border)',
              }}
              className="border px-2 py-0.5 font-mono-tabular text-[11px] font-semibold tracking-wider text-[#A7F3D0]"
            >
              DIRECTION 02 · 纸上实验室
            </span>
            <h1 className="text-[15px] font-semibold tracking-tight">
              CoFlow 设计令牌与组件库规范书（Design Tokens & Component Library）
            </h1>
            <span className="hidden font-mono-tabular text-[11px] opacity-80 xl:inline">
              1440×900 · zh-CN · CSS Custom Properties (--cf-*)
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => setActivePage('final_audit')}
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                color: 'var(--cf-primary-deep)',
              }}
              className="inline-flex h-[26px] items-center gap-1.5 px-2.5 text-[12px] font-semibold"
            >
              <span>← 返回状态稿总览 & 01–14 交付清单</span>
            </button>

            {/* 灰度色觉无障碍检验开关 */}
            <button
              type="button"
              onClick={() => setGrayscaleMode((v) => !v)}
              style={{
                backgroundColor: grayscaleMode ? 'var(--cf-warning)' : 'var(--cf-primary-deep)',
                borderColor: 'var(--cf-primary-border)',
              }}
              className="inline-flex h-[26px] items-center gap-1.5 border px-2.5 text-[12px] font-medium text-white transition-colors"
            >
              <span className="h-2 w-2 rounded-full bg-current" />
              <span>
                {grayscaleMode
                  ? '已开启：全灰度无颜色辨识测试'
                  : '开启全灰度测试（检验不靠颜色区分状态）'}
              </span>
            </button>

            {/* 页签切换 */}
            <div
              style={{
                backgroundColor: 'var(--cf-primary-deep)',
                borderColor: 'var(--cf-primary-border)',
              }}
              className="flex items-center border p-0.5 text-[12px]"
            >
              {[
                { id: 'both', label: '全览模式 (令牌 + 组件库)' },
                { id: 'tokens', label: '一、设计令牌页' },
                { id: 'components', label: '二、组件库页' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveSheet(tab.id as typeof activeSheet)}
                  style={{
                    backgroundColor:
                      activeSheet === tab.id ? 'var(--cf-surface-card)' : 'transparent',
                    color:
                      activeSheet === tab.id
                        ? 'var(--cf-primary-deep)'
                        : 'var(--cf-surface-card)',
                  }}
                  className="h-[24px] px-2.5 font-medium transition-colors"
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      <main
        className={`mx-auto max-w-[1440px] space-y-8 px-6 pt-6 ${
          grayscaleMode ? 'cf-grayscale-proof' : ''
        }`}
      >
        {/* ===================================================================
            第一页：一、设计令牌页 (PAGE 01 · DESIGN TOKENS)
           =================================================================== */}
        {(activeSheet === 'both' || activeSheet === 'tokens') && (
          <section
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="border p-6"
          >
            {/* 页头 */}
            <div
              style={{ borderColor: 'var(--cf-border-strong)' }}
              className="mb-6 flex flex-wrap items-baseline justify-between gap-2 border-b pb-3"
            >
              <div>
                <div className="font-mono-tabular text-[11px] font-semibold uppercase tracking-widest text-[var(--cf-primary)]">
                  SHEET 01 // REUSABLE CSS CUSTOM PROPERTIES
                </div>
                <h2
                  style={{
                    fontSize: 'var(--cf-t1-size)',
                    lineHeight: 'var(--cf-t1-lh)',
                  }}
                  className="mt-0.5 font-semibold"
                >
                  一、设计令牌页（Design Tokens）
                </h2>
              </div>
              <p className="text-[12px] text-[var(--cf-text-tertiary)]">
                全部令牌已定义为全局 `:root` CSS 变量（`--cf-*`），组件通过变量引用，零硬编码色值。
              </p>
            </div>

            <div className="space-y-7">
              {/* -------------------------------------------------------------
                  1.1 颜色令牌：四级表面 + 四级文字 + 两级分割线 + 主色体系 + 五种语义色
                 ------------------------------------------------------------- */}
              <div>
                <div className="mb-3 flex items-center justify-between">
                  <h3
                    style={{ fontSize: 'var(--cf-t3-size)', lineHeight: 'var(--cf-t3-lh)' }}
                    className="font-semibold"
                  >
                    1. 颜色系统（表面层级 / 文字色阶 / 分割线 / 主色 / 五种语义色）
                  </h3>
                  <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                    src/index.css :root
                  </span>
                </div>

                {/* 四级表面 */}
                <div className="mb-4">
                  <div className="mb-1.5 text-[12px] font-semibold text-[var(--cf-text-secondary)]">
                    A. 四级表面（纸面 / 卡面 / 次级面 / 三级面 —— 支撑「过程 vs 当前事实」物理分离）
                  </div>
                  <div className="grid grid-cols-1 gap-3 md:grid-cols-4">
                    {SURFACE_TOKENS.map((token) => (
                      <div
                        key={token.cssVar}
                        style={{
                          borderColor: 'var(--cf-border-strong)',
                          borderRadius: 'var(--cf-radius-control)',
                          backgroundColor: 'var(--cf-surface-card)',
                        }}
                        className="flex flex-col overflow-hidden border"
                      >
                        <div
                          style={{
                            backgroundColor: `var(${token.cssVar})`,
                            borderBottom: '1px solid var(--cf-border-subtle)',
                          }}
                          className="flex h-14 items-end justify-between px-3 py-2"
                        >
                          <span className="text-[12px] font-semibold text-[var(--cf-text-primary)]">
                            {token.name}
                          </span>
                          <span className="font-mono-tabular text-[11px] font-medium text-[var(--cf-text-secondary)]">
                            {token.hex}
                          </span>
                        </div>
                        <div className="flex flex-1 flex-col justify-between p-2.5 text-[12px]">
                          <code className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]">
                            var({token.cssVar})
                          </code>
                          <p className="mt-1 text-[11px] leading-[16px] text-[var(--cf-text-secondary)]">
                            {token.usage}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 四级文字色 + 两级分割线 + 主色（含深色与浅底） */}
                <div className="mb-4 grid grid-cols-1 gap-4 lg:grid-cols-12">
                  {/* 四级文字色 */}
                  <div
                    style={{
                      borderColor: 'var(--cf-border-strong)',
                      backgroundColor: 'var(--cf-surface-secondary)',
                      borderRadius: 'var(--cf-radius-control)',
                    }}
                    className="border p-3 lg:col-span-5"
                  >
                    <div className="mb-2 text-[12px] font-semibold text-[var(--cf-text-primary)]">
                      B. 四级文字色（Text Hierarchy）
                    </div>
                    <div className="space-y-2">
                      {TEXT_TOKENS.map((t) => (
                        <div
                          key={t.cssVar}
                          style={{
                            backgroundColor: 'var(--cf-surface-card)',
                            borderColor: 'var(--cf-border-subtle)',
                          }}
                          className="flex items-center justify-between gap-2 border px-2.5 py-1.5"
                        >
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span
                                style={{ backgroundColor: `var(${t.cssVar})` }}
                                className="h-3 w-3 shrink-0 border border-black/10"
                              />
                              <span
                                style={{ color: `var(${t.cssVar})` }}
                                className="text-[13px] font-semibold"
                              >
                                {t.name}
                              </span>
                              <code className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                                {t.cssVar} ({t.hex})
                              </code>
                            </div>
                            <div className="mt-0.5 text-[11px] text-[var(--cf-text-secondary)]">
                              {t.usage}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 两级分割线 */}
                  <div
                    style={{
                      borderColor: 'var(--cf-border-strong)',
                      backgroundColor: 'var(--cf-surface-secondary)',
                      borderRadius: 'var(--cf-radius-control)',
                    }}
                    className="border p-3 lg:col-span-3"
                  >
                    <div className="mb-2 text-[12px] font-semibold text-[var(--cf-text-primary)]">
                      C. 两级分割线（Dividers）
                    </div>
                    <div className="space-y-3">
                      {DIVIDER_TOKENS.map((d) => (
                        <div
                          key={d.cssVar}
                          style={{
                            backgroundColor: 'var(--cf-surface-card)',
                            borderColor: 'var(--cf-border-subtle)',
                          }}
                          className="border p-2.5"
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-[12px] font-semibold">{d.name}</span>
                            <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                              {d.hex}
                            </span>
                          </div>
                          <code className="font-mono-tabular text-[11px] text-[var(--cf-primary)]">
                            var({d.cssVar})
                          </code>
                          <div
                            style={{ borderTop: `2px solid var(${d.cssVar})` }}
                            className="my-2"
                          />
                          <p className="text-[11px] leading-[16px] text-[var(--cf-text-secondary)]">
                            {d.usage}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 主色（含深色与浅底） */}
                  <div
                    style={{
                      borderColor: 'var(--cf-border-strong)',
                      backgroundColor: 'var(--cf-surface-secondary)',
                      borderRadius: 'var(--cf-radius-control)',
                    }}
                    className="border p-3 lg:col-span-4"
                  >
                    <div className="mb-2 text-[12px] font-semibold text-[var(--cf-text-primary)]">
                      D. 主色体系：实验室深墨青（含深色与浅底）
                    </div>
                    <div className="space-y-2">
                      {PRIMARY_TOKENS.map((p) => (
                        <div
                          key={p.cssVar}
                          style={{
                            backgroundColor: 'var(--cf-surface-card)',
                            borderColor: 'var(--cf-border-subtle)',
                          }}
                          className="flex items-center gap-2.5 border p-2"
                        >
                          <div
                            style={{
                              backgroundColor: `var(${p.cssVar})`,
                              color: p.textPreviewColor,
                              borderColor: 'var(--cf-primary-border)',
                            }}
                            className="flex h-11 w-16 shrink-0 items-center justify-center border font-mono-tabular text-[11px] font-semibold"
                          >
                            {p.hex}
                          </div>
                          <div className="min-w-0">
                            <div className="text-[12px] font-semibold">{p.name}</div>
                            <code className="font-mono-tabular text-[11px] text-[var(--cf-primary)]">
                              var({p.cssVar})
                            </code>
                            <div className="text-[11px] text-[var(--cf-text-secondary)]">
                              {p.usage}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* 五种语义色 */}
                <div>
                  <div className="mb-1.5 text-[12px] font-semibold text-[var(--cf-text-secondary)]">
                    E. 五种语义色（成功 / 警告 / 危险 / 信息 / 中性 —— 每组含主墨色、浅底色、边框色）
                  </div>
                  <div className="grid grid-cols-1 gap-2.5 md:grid-cols-5">
                    {SEMANTIC_TOKENS.map((sem) => (
                      <div
                        key={sem.key}
                        style={{
                          backgroundColor: `var(${sem.bgVar})`,
                          borderColor: `var(${sem.borderVar})`,
                          borderRadius: 'var(--cf-radius-control)',
                        }}
                        className="flex flex-col justify-between border p-2.5"
                      >
                        <div>
                          <div className="flex items-center justify-between">
                            <span
                              style={{ color: `var(${sem.inkVar})` }}
                              className="text-[13px] font-semibold"
                            >
                              {sem.label}
                            </span>
                            <span
                              style={{
                                backgroundColor: `var(${sem.inkVar})`,
                                color: 'var(--cf-surface-card)',
                              }}
                              className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold"
                            >
                              {sem.alias}
                            </span>
                          </div>

                          <div className="mt-2 space-y-1 font-mono-tabular text-[10px] text-[var(--cf-text-secondary)]">
                            <div className="flex justify-between">
                              <span>{sem.inkVar}:</span>
                              <strong style={{ color: `var(${sem.inkVar})` }}>{sem.inkHex}</strong>
                            </div>
                            <div className="flex justify-between">
                              <span>{sem.bgVar}:</span>
                              <span>{sem.bgHex}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>{sem.borderVar}:</span>
                              <span>{sem.borderHex}</span>
                            </div>
                          </div>
                        </div>

                        <p
                          style={{ borderColor: `var(${sem.borderVar})` }}
                          className="mt-2 border-t pt-1.5 text-[11px] leading-[16px] text-[var(--cf-text-secondary)]"
                        >
                          {sem.usage}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* -------------------------------------------------------------
                  1.2 字号阶梯 (7 级字号 + 中文行高 + 用途)
                 ------------------------------------------------------------- */}
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <h3
                    style={{ fontSize: 'var(--cf-t3-size)', lineHeight: 'var(--cf-t3-lh)' }}
                    className="font-semibold"
                  >
                    2. 字号阶梯（共 7 级 · 针对 Windows 1440×900 简体中文 13px 核心基线调校）
                  </h3>
                  <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                    --cf-font-sans / --cf-font-mono
                  </span>
                </div>

                <div
                  style={{
                    borderColor: 'var(--cf-border-strong)',
                    borderRadius: 'var(--cf-radius-container)',
                  }}
                  className="overflow-hidden border"
                >
                  <table className="w-full border-collapse text-left">
                    <thead>
                      <tr
                        style={{
                          backgroundColor: 'var(--cf-surface-secondary)',
                          borderBottom: '1px solid var(--cf-border-strong)',
                        }}
                        className="text-[11px] font-semibold text-[var(--cf-text-secondary)]"
                      >
                        <th className="w-16 px-3 py-2">层级</th>
                        <th className="w-40 px-3 py-2">名称与变量</th>
                        <th className="w-28 px-3 py-2">字号 / 中文行高</th>
                        <th className="w-24 px-3 py-2">字重</th>
                        <th className="w-64 px-3 py-2">法定用途</th>
                        <th className="px-3 py-2">实寸渲染样例</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[var(--cf-border-subtle)] text-[12px]">
                      {TYPOGRAPHY_SCALE.map((tier) => (
                        <tr
                          key={tier.level}
                          className={
                            tier.level === 'T4' ? 'bg-[var(--cf-primary-tint)]/35' : ''
                          }
                        >
                          <td className="px-3 py-2 font-mono-tabular font-semibold text-[var(--cf-primary)]">
                            {tier.level}
                          </td>
                          <td className="px-3 py-2">
                            <div className="font-semibold text-[var(--cf-text-primary)]">
                              {tier.name}
                            </div>
                            <code className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                              var({tier.sizeVar})
                            </code>
                          </td>
                          <td className="px-3 py-2 font-mono-tabular text-[11px]">
                            <div>{tier.sizePx}</div>
                            <div className="text-[var(--cf-text-tertiary)]">LH: {tier.lineHeight}</div>
                          </td>
                          <td className="px-3 py-2 font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                            {tier.weight}
                          </td>
                          <td className="px-3 py-2 text-[11px] text-[var(--cf-text-secondary)]">
                            {tier.usage}
                          </td>
                          <td className="px-3 py-2">
                            <div
                              style={{
                                fontSize: `var(${tier.sizeVar})`,
                                lineHeight: `var(${tier.lhVar})`,
                              }}
                              className={
                                ['T1', 'T2', 'T3', 'T7'].includes(tier.level)
                                  ? 'font-semibold text-[var(--cf-text-primary)]'
                                  : 'font-normal text-[var(--cf-text-primary)]'
                              }
                            >
                              {tier.sampleText}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* -------------------------------------------------------------
                  1.3 间距与圆角 + 1.4 阴影 + 1.5 数字与代码（等宽字体使用场景）
                 ------------------------------------------------------------- */}
              <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
                {/* 3. 间距与圆角 */}
                <div
                  style={{
                    borderColor: 'var(--cf-border-strong)',
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderRadius: 'var(--cf-radius-container)',
                  }}
                  className="border p-3.5 lg:col-span-4"
                >
                  <h3 className="mb-2 text-[14px] font-semibold text-[var(--cf-text-primary)]">
                    3. 间距与圆角（Spacing & Radius）
                  </h3>
                  <div className="space-y-2.5 text-[12px]">
                    <div
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: 'var(--cf-border-subtle)',
                      }}
                      className="border p-2.5"
                    >
                      <div className="flex items-center justify-between font-semibold">
                        <span>间距基数 (Spacing Base)</span>
                        <code className="font-mono-tabular text-[11px] text-[var(--cf-primary)]">
                          --cf-space-unit: 4px
                        </code>
                      </div>
                      <div className="mt-2 flex flex-wrap items-end gap-2 font-mono-tabular text-[10px]">
                        {[
                          { k: '1', px: '4px', w: 4 },
                          { k: '1.5', px: '6px', w: 6 },
                          { k: '2', px: '8px', w: 8 },
                          { k: '3', px: '12px', w: 12 },
                          { k: '4', px: '16px', w: 16 },
                          { k: '5', px: '20px', w: 20 },
                          { k: '6', px: '24px', w: 24 },
                        ].map((s) => (
                          <div key={s.k} className="flex flex-col items-center gap-1">
                            <div
                              style={{
                                width: `${s.w}px`,
                                height: '14px',
                                backgroundColor: 'var(--cf-primary)',
                              }}
                            />
                            <span>{s.px}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      {[
                        {
                          label: '容器圆角',
                          cssVar: '--cf-radius-container',
                          val: '3px',
                          desc: '卡片 / 表格 / 模态框',
                        },
                        {
                          label: '控件圆角',
                          cssVar: '--cf-radius-control',
                          val: '2px',
                          desc: '按钮 / 输入框 / 提示条',
                        },
                        {
                          label: '徽标圆角',
                          cssVar: '--cf-radius-badge',
                          val: '2px / 0px',
                          desc: '主状态 2px / 旁路 0px',
                        },
                      ].map((r) => (
                        <div
                          key={r.cssVar}
                          style={{
                            backgroundColor: 'var(--cf-surface-card)',
                            borderColor: 'var(--cf-border-strong)',
                            borderRadius: `var(${r.cssVar})`,
                          }}
                          className="border p-2"
                        >
                          <div className="text-[11px] font-semibold">{r.label}</div>
                          <div className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                            {r.val}
                          </div>
                          <div className="mt-0.5 text-[10px] text-[var(--cf-text-tertiary)]">
                            {r.desc}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* 4. 阴影 */}
                <div
                  style={{
                    borderColor: 'var(--cf-border-strong)',
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderRadius: 'var(--cf-radius-container)',
                  }}
                  className="border p-3.5 lg:col-span-3"
                >
                  <h3 className="mb-2 text-[14px] font-semibold text-[var(--cf-text-primary)]">
                    4. 阴影（两级实体投影）
                  </h3>
                  <div className="space-y-3 text-[12px]">
                    <div
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: 'var(--cf-border-strong)',
                        boxShadow: 'var(--cf-shadow-card)',
                        borderRadius: 'var(--cf-radius-container)',
                      }}
                      className="border p-2.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold">档案纸叠影 (Card Shadow)</span>
                        <code className="font-mono-tabular text-[10px] text-[var(--cf-primary)]">
                          2px 2px 0 #D6D1C7
                        </code>
                      </div>
                      <div className="mt-1 text-[11px] text-[var(--cf-text-secondary)]">
                        变量：<code className="font-mono-tabular">--cf-shadow-card</code>
                        。专用于「当前事实」卡片与重点台账块，无模糊弥散，强调纸质档案刚性边界。
                      </div>
                    </div>

                    <div
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: 'var(--cf-border-strong)',
                        boxShadow: 'var(--cf-shadow-float)',
                        borderRadius: 'var(--cf-radius-container)',
                      }}
                      className="border p-2.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold">浮层检视阴影 (Float Shadow)</span>
                        <code className="font-mono-tabular text-[10px] text-[var(--cf-primary)]">
                          0 8px 24px -4px
                        </code>
                      </div>
                      <div className="mt-1 text-[11px] text-[var(--cf-text-secondary)]">
                        变量：<code className="font-mono-tabular">--cf-shadow-float</code>
                        。仅用于下拉选择菜单、日期面板、命令浮层等脱离文档流的弹出层。
                      </div>
                    </div>
                  </div>
                </div>

                {/* 5. 数字与代码（等宽字体使用场景） */}
                <div
                  style={{
                    borderColor: 'var(--cf-border-strong)',
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderRadius: 'var(--cf-radius-container)',
                  }}
                  className="border p-3.5 lg:col-span-5"
                >
                  <div className="mb-2 flex items-center justify-between">
                    <h3 className="text-[14px] font-semibold text-[var(--cf-text-primary)]">
                      5. 数字与代码（等宽字体法定使用场景）
                    </h3>
                    <code className="font-mono-tabular text-[11px] text-[var(--cf-primary)]">
                      IBM Plex Mono · tabular-nums
                    </code>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    {[
                      {
                        scene: '1. 任务/风险/章程唯一 ID',
                        sample: 'TSK-0108 · RSK-19 · CHR-04',
                      },
                      {
                        scene: '2. 产物快照哈希与版本号',
                        sample: 'v2.4.1-rc · #7b91e0c4',
                      },
                      {
                        scene: '3. 上下文包与 Token 计量',
                        sample: '24,680 / 32,000 tok (77.1%)',
                      },
                      {
                        scene: '4. 时间戳与截止倒计时',
                        sample: '16:42:19 · SLA -02h:15m',
                      },
                      {
                        scene: '5. 本地 Agent 连接器节点',
                        sample: 'cursor-win-02 · mcp://:7420',
                      },
                      {
                        scene: '6. 表格右对齐量化评测列',
                        sample: 'Recall@10: 94.82% (+2.14%)',
                      },
                    ].map((item) => (
                      <div
                        key={item.scene}
                        style={{
                          backgroundColor: 'var(--cf-surface-card)',
                          borderColor: 'var(--cf-border-subtle)',
                        }}
                        className="border px-2.5 py-1.5"
                      >
                        <div className="text-[11px] text-[var(--cf-text-tertiary)]">
                          {item.scene}
                        </div>
                        <div className="mt-0.5 font-mono-tabular text-[12px] font-semibold text-[var(--cf-primary)]">
                          {item.sample}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* ===================================================================
            第二页：二、组件库页 (PAGE 02 · COMPONENT LIBRARY & SPECIAL SPECS)
           =================================================================== */}
        {(activeSheet === 'both' || activeSheet === 'components') && (
          <section
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="border p-6"
          >
            {/* 页头 */}
            <div
              style={{ borderColor: 'var(--cf-border-strong)' }}
              className="mb-6 flex flex-wrap items-baseline justify-between gap-2 border-b pb-3"
            >
              <div>
                <div className="font-mono-tabular text-[11px] font-semibold uppercase tracking-widest text-[var(--cf-primary)]">
                  SHEET 02 // REUSABLE COMPONENT SYSTEM (13 CATEGORIES + RISK ROW)
                </div>
                <h2
                  style={{
                    fontSize: 'var(--cf-t1-size)',
                    lineHeight: 'var(--cf-t1-lh)',
                  }}
                  className="mt-0.5 font-semibold"
                >
                  二、组件库页（Component Library）
                </h2>
              </div>
              <p className="text-[12px] text-[var(--cf-text-tertiary)]">
                所有组件均封装于 `src/design-system/components.tsx`，可直接用于下一阶段拼装全部业务页面。
              </p>
            </div>

            <div className="space-y-8">
              {/* =============================================================
                  【特殊要求一 & 组件 1】9 种任务状态徽标（核心组件）
                 ============================================================= */}
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderColor: 'var(--cf-primary)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="border-2 p-4"
              >
                <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-[var(--cf-border-strong)] pb-2.5">
                  <div className="flex items-center gap-2">
                    <span
                      style={{
                        backgroundColor: 'var(--cf-primary)',
                        color: 'var(--cf-surface-card)',
                      }}
                      className="px-2 py-0.5 font-mono-tabular text-[11px] font-semibold"
                    >
                      核心组件 · 特殊要求 01
                    </span>
                    <h3 className="text-[15px] font-semibold">
                      1. 任务状态徽标（9 种：6 种主状态 + 3 种旁路状态 · 锁定 20px 高仍一眼可辨）
                    </h3>
                  </div>
                  <span className="font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                    四维冗余编码：底色极性 + 边框虚实/左印章边 + 10px 独特几何标 + 字形修饰
                  </span>
                </div>

                {/* 6 主状态 vs 3 旁路状态 分组展示 */}
                <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
                  {/* 六种主状态 */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                    }}
                    className="border p-3 lg:col-span-8"
                  >
                    <div className="mb-2 flex items-center justify-between text-[12px]">
                      <span className="font-semibold text-[var(--cf-text-primary)]">
                        六种主状态（正向流转生命周期 · 2px 微圆角档案签）
                      </span>
                      <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                        待澄清 → 待认领 → 已就绪 → 进行中 → 待验收 → 已完成
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
                      {TASK_STATUS_LIST.filter((s) => s.category === 'main').map((item) => (
                        <div
                          key={item.status}
                          style={{
                            backgroundColor: 'var(--cf-surface-secondary)',
                            borderColor: 'var(--cf-border-subtle)',
                          }}
                          className="flex flex-col justify-between border p-2"
                        >
                          <div className="flex items-center justify-between gap-2">
                            {/* 20px 紧凑态 */}
                            <TaskStatusBadge status={item.status} size="compact" />
                            <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                              20px
                            </span>
                          </div>
                          <div className="mt-2 text-[11px] leading-[15px] text-[var(--cf-text-secondary)]">
                            {item.encodingDesc}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 三种旁路状态 */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                    }}
                    className="border p-3 lg:col-span-4"
                  >
                    <div className="mb-2 flex items-center justify-between text-[12px]">
                      <span className="font-semibold text-[var(--cf-danger)]">
                        三种旁路状态（异常/挂起/终止 · 0px 直角异形框）
                      </span>
                      <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                        与主状态视觉解耦
                      </span>
                    </div>

                    <div className="space-y-2">
                      {TASK_STATUS_LIST.filter((s) => s.category === 'bypass').map((item) => (
                        <div
                          key={item.status}
                          style={{
                            backgroundColor: 'var(--cf-surface-secondary)',
                            borderColor: 'var(--cf-border-subtle)',
                          }}
                          className="flex items-center justify-between gap-2 border p-2"
                        >
                          <TaskStatusBadge status={item.status} size="compact" />
                          <span className="text-right text-[11px] leading-[15px] text-[var(--cf-text-secondary)]">
                            {item.encodingDesc}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* 20px 极限密集并排对比条 (彩色 vs 100% 灰度同屏对照) */}
                <div
                  style={{
                    backgroundColor: 'var(--cf-surface-card)',
                    borderColor: 'var(--cf-border-subtle)',
                  }}
                  className="mt-3 flex flex-wrap items-center justify-between gap-3 border px-3 py-2"
                >
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                      20px 高原尺寸九态同排速览：
                    </span>
                    {TASK_STATUS_LIST.map((s) => (
                      <TaskStatusBadge key={s.status} status={s.status} size="compact" />
                    ))}
                  </div>
                  <div className="cf-grayscale-proof flex flex-wrap items-center gap-1.5 border-l border-[var(--cf-border-strong)] pl-3">
                    <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                      [纯灰度盲测对照]:
                    </span>
                    {TASK_STATUS_LIST.map((s) => (
                      <TaskStatusBadge key={s.status} status={s.status} size="compact" />
                    ))}
                  </div>
                </div>
              </div>

              {/* =============================================================
                  【特殊要求二】紧凑行式「风险提示」组件（高 / 中 / 低 三级）
                 ============================================================= */}
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderColor: 'var(--cf-border-strong)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="border p-4"
              >
                <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span
                      style={{
                        backgroundColor: 'var(--cf-danger)',
                        color: 'var(--cf-surface-card)',
                      }}
                      className="px-2 py-0.5 font-mono-tabular text-[11px] font-semibold"
                    >
                      特殊要求 02 · 风险专区行组件
                    </span>
                    <h3 className="text-[15px] font-semibold">
                      紧凑行式「风险提示」组件（高 / 中 / 低三级 + 一句话说明 + 任务锚点）
                    </h3>
                  </div>
                  <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                    单行高度 30px · 一屏可叠放 4–6 条不挤占任务主视野
                  </span>
                </div>

                <div className="space-y-1.5">
                  <RiskRowItem
                    severity="high"
                    code="RSK-01"
                    message="本地 Agent (windsurf-03) 连续 15 分钟心跳超时，多模态评测脚本产物尚未回传证据快照。"
                    targetRef="→ TSK-115"
                    slaOrMeta="超期 00h:18m"
                    actionLabel="接管并重指派"
                  />
                  <RiskRowItem
                    severity="medium"
                    code="RSK-02"
                    message="TSK-108 上下文包体积已达预算 88.4% (28.3k/32k tok)，继续追加讨论记录将触发自动截断。"
                    targetRef="→ TSK-108"
                    slaOrMeta="余量 3.7k tok"
                    actionLabel="压缩上下文包"
                  />
                  <RiskRowItem
                    severity="low"
                    code="RSK-03"
                    message="章程第 3.1 条「测试集负样本比例」存在 2 条未收敛的成员讨论提问，建议转为正式澄清项。"
                    targetRef="→ CHR-v2.4"
                    slaOrMeta="2 条边注待确认"
                    actionLabel="转为澄清事实"
                  />
                </div>
              </div>

              {/* =============================================================
                  【徽标类 2 / 3 / 4】优先级 P0-P3 + 角色标签 5 种 + 能力等级徽标 3 种
                 ============================================================= */}
              <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
                {/* 2. 优先级标签 P0-P3 */}
                <div
                  style={{
                    borderColor: 'var(--cf-border-strong)',
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderRadius: 'var(--cf-radius-container)',
                  }}
                  className="border p-3.5 lg:col-span-3"
                >
                  <h3 className="mb-2 text-[14px] font-semibold">2. 优先级标签 (P0–P3)</h3>
                  <p className="mb-3 text-[11px] text-[var(--cf-text-tertiary)]">
                    P0 最紧急（朱砂红左粗边+双箭头），支持完整版与纯代号紧凑版：
                  </p>
                  <div className="space-y-2">
                    {(['P0', 'P1', 'P2', 'P3'] as PriorityLevel[]).map((lvl) => (
                      <div
                        key={lvl}
                        style={{
                          backgroundColor: 'var(--cf-surface-card)',
                          borderColor: 'var(--cf-border-subtle)',
                        }}
                        className="flex items-center justify-between border px-2.5 py-1.5"
                      >
                        <PriorityBadge level={lvl} showLabel={true} />
                        <PriorityBadge level={lvl} showLabel={false} />
                      </div>
                    ))}
                  </div>
                </div>

                {/* 3. 角色标签 5 种 */}
                <div
                  style={{
                    borderColor: 'var(--cf-border-strong)',
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderRadius: 'var(--cf-radius-container)',
                  }}
                  className="border p-3.5 lg:col-span-4"
                >
                  <h3 className="mb-2 text-[14px] font-semibold">3. 角色标签（5 种权限角色）</h3>
                  <p className="mb-3 text-[11px] text-[var(--cf-text-tertiary)]">
                    同一页面上不同角色对应不同操作槽位与章程签批权：
                  </p>
                  <div className="space-y-1.5">
                    {ROLE_LIST.map((r) => (
                      <div
                        key={r.role}
                        style={{
                          backgroundColor: 'var(--cf-surface-card)',
                          borderColor: 'var(--cf-border-subtle)',
                        }}
                        className="flex items-center justify-between border px-2.5 py-1.5 text-[12px]"
                      >
                        <RoleBadge role={r.role} />
                        <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                          {r.code} · {r.permissionNote}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 4. 能力等级徽标 3 种 */}
                <div
                  style={{
                    borderColor: 'var(--cf-border-strong)',
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderRadius: 'var(--cf-radius-container)',
                  }}
                  className="border p-3.5 lg:col-span-5"
                >
                  <h3 className="mb-2 text-[14px] font-semibold">
                    4. 能力等级徽标（自动接入 / 半自动 / 手动）
                  </h3>
                  <p className="mb-3 text-[11px] text-[var(--cf-text-tertiary)]">
                    三者靠色彩与填充度明显区分；「半自动」专门配备内联降级说明条：
                  </p>
                  <div className="space-y-2.5">
                    <div
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: 'var(--cf-border-subtle)',
                      }}
                      className="flex items-center justify-between border p-2"
                    >
                      <CapabilityBadge level="auto" />
                      <span className="text-[11px] text-[var(--cf-text-secondary)]">
                        本地连接器双向实时读写上下文与产物
                      </span>
                    </div>

                    <div
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: 'var(--cf-border-subtle)',
                      }}
                      className="border p-2"
                    >
                      <CapabilityBadge
                        level="semi"
                        degradeReason="本地连接器缺少自动执行沙箱权限，Agent 生成评测脚本后需由成员在本地终端确认运行并回传日志。"
                      />
                    </div>

                    <div
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: 'var(--cf-border-subtle)',
                      }}
                      className="flex items-center justify-between border p-2"
                    >
                      <CapabilityBadge level="manual" />
                      <span className="text-[11px] text-[var(--cf-text-secondary)]">
                        纯人工撰写或上传产物文件，无 Agent 介入
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* =============================================================
                  【控件类 5】按钮矩阵（4 种变体 × 3 种尺寸 × 4 种状态）
                 ============================================================= */}
              <div
                style={{
                  borderColor: 'var(--cf-border-strong)',
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="border p-4"
              >
                <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                  <h3 className="text-[14px] font-semibold">
                    5. 按钮（变体：主要 / 次要 / 幽灵 / 危险 · 尺寸：标准 32px / 小 26px / 极小 22px · 状态：默认 / 悬停 / 禁用 / 加载中）
                  </h3>
                  <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                    radius: var(--cf-radius-control) (2px)
                  </span>
                </div>

                <div
                  style={{
                    backgroundColor: 'var(--cf-surface-card)',
                    borderColor: 'var(--cf-border-subtle)',
                  }}
                  className="overflow-x-auto border"
                >
                  <table className="w-full border-collapse text-left text-[12px]">
                    <thead>
                      <tr
                        style={{
                          backgroundColor: 'var(--cf-surface-secondary)',
                          borderBottom: '1px solid var(--cf-border-strong)',
                        }}
                        className="text-[11px] text-[var(--cf-text-secondary)]"
                      >
                        <th className="px-3 py-2">按钮类型</th>
                        <th className="px-3 py-2">默认 (Default)</th>
                        <th className="px-3 py-2">悬停 (Hover)</th>
                        <th className="px-3 py-2">禁用 (Disabled)</th>
                        <th className="px-3 py-2">加载中 (Loading)</th>
                        <th className="px-3 py-2">小尺寸 (26px) / 极小尺寸 (22px)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[var(--cf-border-subtle)]">
                      {[
                        {
                          variant: 'primary' as const,
                          name: '主要按钮 (Primary)',
                          text: '签批验收通过',
                        },
                        {
                          variant: 'secondary' as const,
                          name: '次要按钮 (Secondary)',
                          text: '导出上下文包',
                        },
                        {
                          variant: 'ghost' as const,
                          name: '幽灵按钮 (Ghost)',
                          text: '查看历史快照',
                        },
                        {
                          variant: 'danger' as const,
                          name: '危险按钮 (Danger)',
                          text: '驳回产物并返工',
                        },
                      ].map((row) => (
                        <tr key={row.variant}>
                          <td className="px-3 py-2.5 font-semibold text-[var(--cf-text-primary)]">
                            {row.name}
                          </td>
                          <td className="px-3 py-2.5">
                            <CfButton variant={row.variant} visualState="default">
                              {row.text}
                            </CfButton>
                          </td>
                          <td className="px-3 py-2.5">
                            <CfButton variant={row.variant} visualState="hover">
                              {row.text}
                            </CfButton>
                          </td>
                          <td className="px-3 py-2.5">
                            <CfButton variant={row.variant} visualState="disabled">
                              {row.text}
                            </CfButton>
                          </td>
                          <td className="px-3 py-2.5">
                            <CfButton variant={row.variant} visualState="loading">
                              同步证据中...
                            </CfButton>
                          </td>
                          <td className="px-3 py-2.5">
                            <div className="flex items-center gap-2">
                              <CfButton variant={row.variant} size="sm">
                                小号 26px
                              </CfButton>
                              <CfButton variant={row.variant} size="xs">
                                极小 22px
                              </CfButton>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* =============================================================
                  【控件类 6】输入控件（单行文本、多行文本域、下拉选择、复选框、日期选择 × 默认/聚焦/错误/禁用）
                 ============================================================= */}
              <div
                style={{
                  borderColor: 'var(--cf-border-strong)',
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="border p-4"
              >
                <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                  <h3 className="text-[14px] font-semibold">
                    6. 输入控件（单行文本框 / 多行文本域 / 下拉选择 / 复选框 / 日期选择 · 四态：默认 / 聚焦 / 错误 / 禁用）
                  </h3>
                  <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                    13px 正文输入 · 等宽数值输入混排
                  </span>
                </div>

                {/* 四种状态矩阵：单行文本框 */}
                <div className="mb-4 grid grid-cols-1 gap-3 md:grid-cols-4">
                  {/* 默认态 */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-subtle)',
                    }}
                    className="border p-2.5"
                  >
                    <label className="mb-1 block text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                      单行文本框 · 默认 (Default)
                    </label>
                    <input
                      type="text"
                      defaultValue="向量召回率评测基准 v1.4"
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: 'var(--cf-border-strong)',
                        borderRadius: 'var(--cf-radius-control)',
                      }}
                      className="h-[30px] w-full border px-2.5 text-[13px] text-[var(--cf-text-primary)] outline-none"
                    />
                    <span className="mt-1 block text-[11px] text-[var(--cf-text-tertiary)]">
                      常规 `1px solid var(--cf-border-strong)`
                    </span>
                  </div>

                  {/* 聚焦态 */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-subtle)',
                    }}
                    className="border p-2.5"
                  >
                    <label className="mb-1 block text-[11px] font-semibold text-[var(--cf-primary)]">
                      单行文本框 · 聚焦 (Focused)
                    </label>
                    <input
                      type="text"
                      defaultValue="cursor-win-02"
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: 'var(--cf-primary)',
                        boxShadow: '0 0 0 2px var(--cf-primary-tint)',
                        borderRadius: 'var(--cf-radius-control)',
                      }}
                      className="font-mono-tabular h-[30px] w-full border px-2.5 text-[13px] text-[var(--cf-text-primary)] outline-none"
                    />
                    <span className="mt-1 block text-[11px] text-[var(--cf-primary)]">
                      墨青实框 + `2px` 青瓷浅底光晕环
                    </span>
                  </div>

                  {/* 错误态 */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-subtle)',
                    }}
                    className="border p-2.5"
                  >
                    <label className="mb-1 block text-[11px] font-semibold text-[var(--cf-danger)]">
                      单行文本框 · 错误 (Error)
                    </label>
                    <input
                      type="text"
                      defaultValue="ART-缺失哈希凭证"
                      style={{
                        backgroundColor: 'var(--cf-danger-bg)',
                        borderColor: 'var(--cf-danger)',
                        borderRadius: 'var(--cf-radius-control)',
                      }}
                      className="h-[30px] w-full border px-2.5 text-[13px] text-[var(--cf-danger)] outline-none"
                    />
                    <span className="mt-1 block text-[11px] font-medium text-[var(--cf-danger)]">
                      校验失败：提交产物必须附带 SHA-1 短哈希
                    </span>
                  </div>

                  {/* 禁用态 */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-subtle)',
                    }}
                    className="border p-2.5"
                  >
                    <label className="mb-1 block text-[11px] font-semibold text-[var(--cf-text-muted)]">
                      单行文本框 · 禁用 (Disabled)
                    </label>
                    <input
                      type="text"
                      disabled
                      defaultValue="CHR-2025-LOCKED (章程已封存)"
                      style={{
                        backgroundColor: 'var(--cf-surface-tertiary)',
                        borderColor: 'var(--cf-border-subtle)',
                        color: 'var(--cf-text-muted)',
                        borderRadius: 'var(--cf-radius-control)',
                      }}
                      className="font-mono-tabular h-[30px] w-full cursor-not-allowed border px-2.5 text-[12px]"
                    />
                    <span className="mt-1 block text-[11px] text-[var(--cf-text-muted)]">
                      当前角色无章程基线修改权限
                    </span>
                  </div>
                </div>

                {/* 多行文本域 + 下拉选择 + 日期选择 + 复选框 */}
                <div className="grid grid-cols-1 gap-3 md:grid-cols-12">
                  {/* 多行文本域 */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-subtle)',
                    }}
                    className="border p-2.5 md:col-span-4"
                  >
                    <div className="mb-1 flex items-center justify-between">
                      <label className="text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                        多行文本域 (Textarea · 人工验收结论)
                      </label>
                      <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                        MD / 证据引用
                      </span>
                    </div>
                    <textarea
                      rows={3}
                      defaultValue={
                        '已核验产物 #7b91e0：Top-10 召回率达 94.8%，符合章程第 4.2 条（≥93.0%）要求，准予合入主干事实库。'
                      }
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: 'var(--cf-border-strong)',
                        borderRadius: 'var(--cf-radius-control)',
                      }}
                      className="w-full border p-2 text-[13px] leading-[19px] text-[var(--cf-text-primary)] outline-none focus:border-[var(--cf-primary)]"
                    />
                  </div>

                  {/* 下拉选择 & 日期选择 */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-subtle)',
                    }}
                    className="space-y-2.5 border p-2.5 md:col-span-4"
                  >
                    <div>
                      <label className="mb-1 block text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                        下拉选择 (Select · 指派本地连接器)
                      </label>
                      <div className="relative">
                        <select
                          defaultValue="cursor-win-02"
                          style={{
                            backgroundColor: 'var(--cf-surface-card)',
                            borderColor: 'var(--cf-border-strong)',
                            borderRadius: 'var(--cf-radius-control)',
                          }}
                          className="font-mono-tabular h-[30px] w-full appearance-none border pl-2.5 pr-7 text-[12px] text-[var(--cf-text-primary)] outline-none focus:border-[var(--cf-primary)]"
                        >
                          <option value="cursor-win-02">cursor-win-02 (自动接入 · 在线)</option>
                          <option value="claude-code-01">claude-code-01 (半自动 · 需确认)</option>
                          <option value="manual">manual-human (纯人工执行)</option>
                        </select>
                        <svg
                          width="10"
                          height="10"
                          viewBox="0 0 10 10"
                          fill="none"
                          className="pointer-events-none absolute right-2.5 top-2.5 text-[var(--cf-text-secondary)]"
                        >
                          <path d="M2 3.5L5 6.5L8 3.5" stroke="currentColor" strokeWidth="1.4" />
                        </svg>
                      </div>
                    </div>

                    <div>
                      <label className="mb-1 block text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                        日期与截止时间选择 (Date Picker)
                      </label>
                      <input
                        type="date"
                        defaultValue="2025-05-18"
                        style={{
                          backgroundColor: 'var(--cf-surface-card)',
                          borderColor: 'var(--cf-border-strong)',
                          borderRadius: 'var(--cf-radius-control)',
                        }}
                        className="font-mono-tabular h-[30px] w-full border px-2.5 text-[12px] text-[var(--cf-text-primary)] outline-none focus:border-[var(--cf-primary)]"
                      />
                    </div>
                  </div>

                  {/* 复选框 (选中 / 未选 / 禁用) */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-subtle)',
                    }}
                    className="border p-2.5 md:col-span-4"
                  >
                    <div className="mb-1.5 text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                      复选框 (Checkbox · 验收清单核对项)
                    </div>
                    <div className="space-y-1.5 text-[12px]">
                      <label className="flex cursor-pointer items-center gap-2">
                        <input
                          type="checkbox"
                          checked={checkboxStates.evidenceRequired}
                          onChange={(e) =>
                            setCheckboxStates((s) => ({
                              ...s,
                              evidenceRequired: e.target.checked,
                            }))
                          }
                          className="h-3.5 w-3.5 accent-[#0F5257]"
                        />
                        <span>强制要求附带可复现评测日志 (选中态)</span>
                      </label>
                      <label className="flex cursor-pointer items-center gap-2">
                        <input
                          type="checkbox"
                          checked={checkboxStates.autoSyncContext}
                          onChange={(e) =>
                            setCheckboxStates((s) => ({
                              ...s,
                              autoSyncContext: e.target.checked,
                            }))
                          }
                          className="h-3.5 w-3.5 accent-[#0F5257]"
                        />
                        <span>允许 Agent 自动拉取上游草稿讨论 (未选态)</span>
                      </label>
                      <label className="flex cursor-not-allowed items-center gap-2 text-[var(--cf-text-muted)]">
                        <input type="checkbox" disabled checked className="h-3.5 w-3.5" />
                        <span>人工终审签批不可跳过 (章程锁定禁用态)</span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>

              {/* =============================================================
                  【控件类 7】提示条（信息 / 警告 / 危险 / 成功）
                 ============================================================= */}
              <div
                style={{
                  borderColor: 'var(--cf-border-strong)',
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="border p-4"
              >
                <h3 className="mb-3 text-[14px] font-semibold">
                  7. 提示条（信息 / 警告 / 危险 / 成功 —— 用于页面内的规则说明与状态告警）
                </h3>
                <div className="grid grid-cols-1 gap-2.5 md:grid-cols-2">
                  <InlineBanner
                    tone="info"
                    title="上下文包快照已生成"
                    description="当前任务已打包章程 v2.4 与上游 2 份依赖产物，本地连接器可通过 MCP 协议直接拉取。"
                    code="CTX-904"
                  />
                  <InlineBanner
                    tone="warning"
                    title="半自动连接器权限受限"
                    description="节点 claude-code-01 处于只读沙箱模式，产出的代码补丁需由任务负责人手动核验并点击合入。"
                    code="WARN-12"
                  />
                  <InlineBanner
                    tone="danger"
                    title="验收阻断：缺少关键证据附件"
                    description="提交的产物包 #7b91e0 未包含章程第 4.2 条规定的召回率对比 CSV 表，系统已拦截验收流转。"
                    code="ERR-402"
                  />
                  <InlineBanner
                    tone="success"
                    title="人工验收结论已锁定入库"
                    description="评审人「陈默」已签批通过 TSK-104，该结论已升格为项目基线事实，后续任务将自动继承。"
                    code="FACT-88"
                  />
                </div>
              </div>

              {/* =============================================================
                  【容器类 8】卡片（普通、悬停、弱化、虚线）
                 ============================================================= */}
              <div
                style={{
                  borderColor: 'var(--cf-border-strong)',
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="border p-4"
              >
                <h3 className="mb-3 text-[14px] font-semibold">
                  8. 卡片容器（普通事实卡 / 悬停交互卡 / 弱化次要信息卡 / 虚线新增或空槽卡）
                </h3>
                <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
                  {/* 1) 普通卡片 */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                      boxShadow: 'var(--cf-shadow-card)',
                      borderRadius: 'var(--cf-radius-container)',
                    }}
                    className="flex flex-col justify-between border p-3"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]">
                          [普通 · Default]
                        </span>
                        <TaskStatusBadge status="ready" size="compact" />
                      </div>
                      <h4 className="mt-1.5 text-[13px] font-semibold text-[var(--cf-text-primary)]">
                        标准事实卡片（无酸档案纸白）
                      </h4>
                      <p className="mt-1 text-[12px] text-[var(--cf-text-secondary)]">
                        承载当前已确认的任务、产物包与验收记录，带 `2px` 纸张叠放硬阴影。
                      </p>
                    </div>
                    <div className="mt-3 border-t border-[var(--cf-border-subtle)] pt-1.5 font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                      --cf-surface-card · #FAF8F5
                    </div>
                  </div>

                  {/* 2) 悬停卡片 */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-primary)',
                      boxShadow: 'var(--cf-shadow-card-hover)',
                      borderRadius: 'var(--cf-radius-container)',
                    }}
                    className="flex -translate-y-0.5 flex-col justify-between border p-3 transition-transform"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]">
                          [悬停 · Hover]
                        </span>
                        <TaskStatusBadge status="in_progress" size="compact" />
                      </div>
                      <h4 className="mt-1.5 text-[13px] font-semibold text-[var(--cf-primary)]">
                        可交互悬停态（墨青边框 + 3px 抬升影）
                      </h4>
                      <p className="mt-1 text-[12px] text-[var(--cf-text-secondary)]">
                        鼠标悬停或键盘聚焦时边框切换为 `--cf-primary`，硬阴影加深至 `3px`。
                      </p>
                    </div>
                    <div className="mt-3 flex items-center justify-between border-t border-[var(--cf-border-subtle)] pt-1.5 font-mono-tabular text-[11px] text-[var(--cf-primary)]">
                      <span>点击检视证据链</span>
                      <span>→</span>
                    </div>
                  </div>

                  {/* 3) 弱化卡片（次要/过程信息） */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-tertiary)',
                      borderColor: 'var(--cf-border-subtle)',
                      borderRadius: 'var(--cf-radius-container)',
                    }}
                    className="flex flex-col justify-between border p-3"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                          [弱化 · Muted]
                        </span>
                        <TaskStatusBadge status="paused" size="compact" />
                      </div>
                      <h4 className="mt-1.5 text-[13px] font-medium text-[var(--cf-text-secondary)]">
                        弱化容器（承载过程讨论或次要归档）
                      </h4>
                      <p className="mt-1 text-[12px] text-[var(--cf-text-tertiary)]">
                        无阴影、采用三级凹槽面 `--cf-surface-tertiary`，在视觉层级上主动退让给事实卡。
                      </p>
                    </div>
                    <div className="mt-3 border-t border-[var(--cf-border-strong)]/40 pt-1.5 font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                      无投影 · 视觉后退
                    </div>
                  </div>

                  {/* 4) 虚线卡片（新增入口或待填槽位） */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-paper)',
                      borderColor: 'var(--cf-border-strong-hover)',
                      borderRadius: 'var(--cf-radius-container)',
                    }}
                    className="flex cursor-pointer flex-col items-center justify-center border border-dashed p-3 text-center transition-colors hover:border-[var(--cf-primary)] hover:bg-[var(--cf-surface-card)]"
                  >
                    <div
                      style={{
                        borderColor: 'var(--cf-border-strong)',
                        backgroundColor: 'var(--cf-surface-card)',
                      }}
                      className="flex h-7 w-7 items-center justify-center border font-mono-tabular text-[14px] font-semibold text-[var(--cf-primary)]"
                    >
                      +
                    </div>
                    <h4 className="mt-1.5 text-[13px] font-semibold text-[var(--cf-text-primary)]">
                      虚线容器（新增产物证据 / 拆解子任务）
                    </h4>
                    <p className="mt-0.5 text-[11px] text-[var(--cf-text-tertiary)]">
                      用于待上传证据槽位或新建入口 (`1px dashed`)
                    </p>
                  </div>
                </div>
              </div>

              {/* =============================================================
                  【容器类 9 & 10】高密度台账表格 + 空状态组件
                 ============================================================= */}
              <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
                {/* 9. 表格 */}
                <div
                  style={{
                    borderColor: 'var(--cf-border-strong)',
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderRadius: 'var(--cf-radius-container)',
                  }}
                  className="border p-4 lg:col-span-8"
                >
                  <div className="mb-2.5 flex items-center justify-between">
                    <h3 className="text-[14px] font-semibold">
                      9. 表格（有数据 / 空状态 / 表头 / 行悬停态 / 数字右对齐等宽列）
                    </h3>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setDsTableEmpty((v) => !v)}
                        className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] px-2 py-0.5 font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]"
                      >
                        {dsTableEmpty ? '切换至：有数据态' : '切换至：空表格态'}
                      </button>
                    </div>
                  </div>

                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                      borderRadius: 'var(--cf-radius-container)',
                    }}
                    className="overflow-x-auto border"
                  >
                    <table className="w-full border-collapse text-left">
                      <thead>
                        <tr
                          style={{
                            backgroundColor: 'var(--cf-surface-secondary)',
                            borderBottom: '1px solid var(--cf-border-strong)',
                          }}
                          className="text-[11px] font-semibold text-[var(--cf-text-secondary)]"
                        >
                          <th className="px-2.5 py-2">ID</th>
                          <th className="px-2.5 py-2">任务事实名称</th>
                          <th className="px-2.5 py-2">20px 状态</th>
                          <th className="px-2.5 py-2">优先级</th>
                          <th className="px-2.5 py-2">连接器节点</th>
                          <th className="px-2.5 py-2 text-right">证据完备度</th>
                          <th className="px-2.5 py-2 text-right">Token 消耗 (右对齐)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[var(--cf-border-subtle)] text-[12px]">
                        {dsTableEmpty ? (
                          <tr>
                            <td
                              colSpan={7}
                              className="px-4 py-8 text-center text-[12px] text-[var(--cf-text-tertiary)]"
                            >
                              当前表格无匹配数据（表格「空」状态变体）。
                            </td>
                          </tr>
                        ) : (
                          LEDGER_ROWS.map((row, idx) => {
                          const isHoverDemo = idx === 1
                          return (
                            <tr
                              key={row.id}
                              style={{
                                backgroundColor: isHoverDemo
                                  ? 'var(--cf-primary-tint)'
                                  : undefined,
                              }}
                              className="transition-colors hover:bg-[var(--cf-surface-secondary)]"
                            >
                              <td className="px-2.5 py-2 font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]">
                                {row.id}
                              </td>
                              <td className="px-2.5 py-2 font-medium text-[var(--cf-text-primary)]">
                                <div className="flex items-center gap-1.5">
                                  <span className="max-w-[230px] truncate">{row.title}</span>
                                  {isHoverDemo && (
                                    <span className="font-mono-tabular text-[10px] text-[var(--cf-primary)]">
                                      [行悬停态]
                                    </span>
                                  )}
                                </div>
                              </td>
                              <td className="px-2.5 py-2">
                                <TaskStatusBadge status={row.status} size="compact" />
                              </td>
                              <td className="px-2.5 py-2">
                                <PriorityBadge level={row.priority} showLabel={false} />
                              </td>
                              <td className="px-2.5 py-2 font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                                {row.connector}
                              </td>
                              <td className="px-2.5 py-2 text-right font-mono-tabular text-[11px] font-semibold text-[var(--cf-text-primary)]">
                                {row.evidenceCount}
                              </td>
                              <td className="px-2.5 py-2 text-right font-mono-tabular text-[12px] font-medium text-[var(--cf-text-primary)]">
                                {row.tokens.toLocaleString()}
                              </td>
                            </tr>
                          )
                        })
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* 10. 空状态 */}
                <div
                  style={{
                    borderColor: 'var(--cf-border-strong)',
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderRadius: 'var(--cf-radius-container)',
                  }}
                  className="flex flex-col justify-between border p-4 lg:col-span-4"
                >
                  <h3 className="mb-2 text-[14px] font-semibold">
                    10. 空状态（标题 + 一行说明 + 可选按钮）
                  </h3>
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                      borderRadius: 'var(--cf-radius-container)',
                    }}
                    className="flex flex-1 flex-col items-center justify-center border border-dashed p-5 text-center"
                  >
                    {/* 档案夹几何矢量图标 */}
                    <div
                      style={{
                        backgroundColor: 'var(--cf-surface-secondary)',
                        borderColor: 'var(--cf-border-strong)',
                      }}
                      className="mb-2.5 flex h-10 w-10 items-center justify-center border text-[var(--cf-text-tertiary)]"
                    >
                      <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <path
                          d="M3 5H8L9.5 7H17V15.5H3V5Z"
                          stroke="currentColor"
                          strokeWidth="1.4"
                        />
                        <path d="M7 11H13" stroke="currentColor" strokeWidth="1.4" />
                      </svg>
                    </div>
                    <h4 className="text-[14px] font-semibold text-[var(--cf-text-primary)]">
                      暂无已确认的验收产物
                    </h4>
                    <p className="mt-1 max-w-[260px] text-[12px] text-[var(--cf-text-tertiary)]">
                      过程中的讨论不计入事实，请由本地连接器推送或手动上传带证据的产物包。
                    </p>
                    <div className="mt-3 flex items-center gap-2">
                      <CfButton variant="primary" size="sm">
                        登记首份产物证据
                      </CfButton>
                      <CfButton variant="secondary" size="sm">
                        绑定本地 Agent
                      </CfButton>
                    </div>
                  </div>
                </div>
              </div>

              {/* =============================================================
                  【其他类 11 / 12 / 13】头像与头像组 + 三种进度条 + 分隔线与 KV 标签
                 ============================================================= */}
              <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
                {/* 11. 头像与头像组 */}
                <div
                  style={{
                    borderColor: 'var(--cf-border-strong)',
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderRadius: 'var(--cf-radius-container)',
                  }}
                  className="border p-4 lg:col-span-4"
                >
                  <h3 className="mb-2.5 text-[14px] font-semibold">
                    11. 头像与头像组（区分人类/Agent · 超 5 个显示 +N）
                  </h3>
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-subtle)',
                    }}
                    className="space-y-3 border p-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[12px] text-[var(--cf-text-secondary)]">
                        单人头像（圆章=人类 / 墨青方章=Agent）：
                      </span>
                      <div className="flex items-center gap-2">
                        <SingleAvatar item={SAMPLE_COLLABORATORS[0]} />
                        <SingleAvatar item={SAMPLE_COLLABORATORS[2]} />
                      </div>
                    </div>

                    <div className="border-t border-[var(--cf-border-subtle)] pt-2.5">
                      <div className="mb-1.5 flex items-center justify-between text-[12px]">
                        <span className="text-[var(--cf-text-secondary)]">
                          重叠头像组（共 8 个节点，限制 5 个显示 `+3`）：
                        </span>
                        <span className="font-mono-tabular text-[11px] text-[var(--cf-primary)]">
                          max=5 → +3
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <AvatarGroup items={SAMPLE_COLLABORATORS} max={5} />
                        <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                          5 人 + 3 Agent
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 12. 进度条（细列表型、标准卡片型、预算型三段颜色） */}
                <div
                  style={{
                    borderColor: 'var(--cf-border-strong)',
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderRadius: 'var(--cf-radius-container)',
                  }}
                  className="border p-4 lg:col-span-5"
                >
                  <h3 className="mb-2.5 text-[14px] font-semibold">
                    12. 进度条（列表细型 4px / 卡片标准型 8px / 上下文包三段预算型）
                  </h3>
                  <div className="space-y-2.5">
                    <div
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: 'var(--cf-border-subtle)',
                      }}
                      className="grid grid-cols-2 gap-3 border p-2.5"
                    >
                      <div>
                        <div className="mb-1 text-[11px] text-[var(--cf-text-tertiary)]">
                          A. 细进度条 (4px · 用于高密度列表行内)
                        </div>
                        <ThinProgressBar percent={68} />
                      </div>
                      <div>
                        <div className="mb-1 text-[11px] text-[var(--cf-text-tertiary)]">
                          B. 细进度条 (100% 满格自动转档案绿)
                        </div>
                        <ThinProgressBar percent={100} />
                      </div>
                    </div>

                    <div
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: 'var(--cf-border-subtle)',
                      }}
                      className="border p-2.5"
                    >
                      <StandardProgressBar
                        label="C. 标准进度条（用于里程碑卡片）"
                        doneCount={14}
                        totalCount={18}
                      />
                    </div>

                    <ContextBudgetProgressBar
                      charterTokens={9600}
                      artifactTokens={14200}
                      warningTokens={4520}
                      maxTokens={32000}
                    />
                  </div>
                </div>

                {/* 13. 分隔线与 Key-Value 小标签 */}
                <div
                  style={{
                    borderColor: 'var(--cf-border-strong)',
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderRadius: 'var(--cf-radius-container)',
                  }}
                  className="border p-4 lg:col-span-3"
                >
                  <h3 className="mb-2.5 text-[14px] font-semibold">
                    13. 分隔线与 Key-Value 小标签
                  </h3>
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-subtle)',
                    }}
                    className="space-y-3 border p-3"
                  >
                    {/* 分隔线样式 */}
                    <div className="space-y-2 text-[11px]">
                      <div className="flex items-center gap-2">
                        <span className="font-mono-tabular font-semibold text-[var(--cf-text-secondary)]">
                          SEC-01 · 强分割线
                        </span>
                        <div
                          style={{ borderTop: '1px solid var(--cf-border-strong)' }}
                          className="flex-1"
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono-tabular text-[var(--cf-text-tertiary)]">
                          草稿过程弱虚线
                        </span>
                        <div
                          style={{ borderTop: '1px dashed var(--cf-border-strong)' }}
                          className="flex-1"
                        />
                      </div>
                    </div>

                    {/* Key-Value 小标签组 */}
                    <div className="border-t border-[var(--cf-border-subtle)] pt-2.5">
                      <div className="mb-2 text-[11px] text-[var(--cf-text-secondary)]">
                        Key-Value 台账小标签（20px 高，左键名浅底 + 右等宽值）：
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        <KeyValueTag k="章程" v="v2.4" highlight />
                        <KeyValueTag k="节点" v="cursor-win-02" />
                        <KeyValueTag k="产物哈希" v="#7b91e0" />
                        <KeyValueTag k="Token" v="32.6k" />
                        <KeyValueTag k="耗时" v="04m12s" />
                        <KeyValueTag k="验收人" v="陈默" mono={false} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}
      </main>
    </div>
  )
}
