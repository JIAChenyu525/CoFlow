import { useState, useRef } from 'react'
import {
  TaskStatusBadge,
  PriorityBadge,
  RoleBadge,
  SingleAvatar,
  ThinProgressBar,
  TaskStatus,
  RoleType,
} from '../design-system/components'
import { CoFlowTask } from '../data/mockTasks'

interface MobileSuitePageProps {
  tasks: CoFlowTask[]
  currentRole: RoleType
  onUpdateTask: (updated: CoFlowTask) => void
}

type MobileNavTab = 'workbench' | 'tasks' | 'artifacts' | 'decisions' | 'settings'

interface MobileMessage {
  id: string
  kind: 'chat' | 'system' | 'proposal' | 'artifact' | 'blocker' | 'agent_report'
  sender?: string
  senderShort?: string
  role?: RoleType
  time: string
  text: string
  tag?: string
  codePath?: string
  needWhat?: string
  proposalId?: string
  proposalConfirmed?: boolean
}

const INITIAL_MOBILE_MESSAGES: MobileMessage[] = [
  {
    id: 'mm-1',
    kind: 'system',
    time: '10:02',
    tag: '升级章程',
    text: '林知夏 升级章程至 CHR-v2.4：单次检索 P99 延迟 ≤ 180ms',
  },
  {
    id: 'mm-2',
    kind: 'blocker',
    sender: '许嘉树',
    senderShort: '许',
    role: 'member',
    time: '14:15',
    tag: 'TSK-109',
    text: '政务云实测网关拦截连接器探针，任务已阻塞 5 天。',
    needWhat: '需要：营业执照盖章扫描件 + 白名单授权函',
  },
  {
    id: 'mm-3',
    kind: 'artifact',
    sender: '陈默',
    senderShort: '陈',
    role: 'owner',
    time: '15:26',
    tag: 'v1.4.2-rc',
    text: '已回传 Top-10 混合检索评测产物（Recall@10 = 94.82%）。',
    codePath: 'artifacts/eval/recall_bench_v1.4.csv (#7b91e0c4)',
  },
  {
    id: 'mm-4',
    kind: 'agent_report',
    time: '16:12',
    tag: 'claude-code-01 · TSK-112',
    text: '已剔除 47 张损坏 OCR 图像切片 (进度 65% · 9.8k tok)',
    codePath: 'scripts/clean_multimodal.py --strict-ocr',
  },
  {
    id: 'mm-5',
    kind: 'proposal',
    sender: '苏哲',
    senderShort: '苏',
    role: 'member',
    time: '16:30',
    proposalId: 'DEC-P04',
    proposalConfirmed: false,
    text: '提议周五挑战杯路演切换为本地离线快照包 v1.4，与外网网关联调解耦。',
  },
  {
    id: 'mm-6',
    kind: 'chat',
    sender: '周舟',
    senderShort: '周',
    role: 'reviewer',
    time: '16:45',
    text: '建议把 Cross-Encoder 重排截断窗口固定在 Top-30，P99 延迟能稳压在 145ms 内。',
  },
]

const KANBAN_STATUS_COLS: { status: TaskStatus; label: string }[] = [
  { status: 'clarify', label: '待澄清' },
  { status: 'unclaimed', label: '待认领' },
  { status: 'ready', label: '已就绪' },
  { status: 'in_progress', label: '进行中' },
  { status: 'pending_accept', label: '待验收' },
  { status: 'done', label: '已完成' },
]

export function MobileSuitePage({
  tasks,
  currentRole,
  onUpdateTask,
}: MobileSuitePageProps) {
  // 画布布局模式：三屏同排对照 (3 × 390×844) vs 单屏专注预览
  const [displayLayout, setDisplayLayout] = useState<
    'triple' | 'm_workbench' | 'm_board' | 'm_detail'
  >('triple')
  const [mobileEmptyDemo, setMobileEmptyDemo] = useState(false)
  const isObserver = currentRole === 'observer'

  // =========================================================================
  // 屏幕一状态：工作台（移动端）
  // =========================================================================
  const [activeNavTab, setActiveNavTab] = useState<MobileNavTab>('workbench')
  const [drawerOpen, setDrawerOpen] = useState<boolean>(true) // 顶部滑出的「今日需要我处理 & 风险」抽屉
  const [messages, setMessages] = useState<MobileMessage[]>(INITIAL_MOBILE_MESSAGES)
  const [expandedAgentIds, setExpandedAgentIds] = useState<Record<string, boolean>>({})
  const [chatInput, setChatInput] = useState('')
  const [pendingDecisionConfirmed, setPendingDecisionConfirmed] = useState(false)

  // =========================================================================
  // 屏幕二状态：任务看板（移动端）
  // =========================================================================
  const [activeBoardCol, setActiveBoardCol] = useState<TaskStatus>('pending_accept')
  const boardScrollRef = useRef<HTMLDivElement | null>(null)
  const colRefs = useRef<Record<string, HTMLDivElement | null>>({})

  // =========================================================================
  // 屏幕三状态：任务详情（移动端）
  // =========================================================================
  const [detailTaskId, setDetailTaskId] = useState<string>('TSK-108')
  const [moreSheetOpen, setMoreSheetOpen] = useState<boolean>(false)
  const [acceptSheetOpen, setAcceptSheetOpen] = useState<boolean>(false)
  const [mobileToast, setMobileToast] = useState<string | null>(null)

  const detailTask = tasks.find((t) => t.id === detailTaskId) || tasks[4]

  const triggerToast = (msg: string) => {
    setMobileToast(msg)
    setTimeout(() => setMobileToast(null), 2200)
  }

  // 屏幕二：点击分段控件快速滚动到指定状态列
  const handleJumpToColumn = (status: TaskStatus) => {
    setActiveBoardCol(status)
    const el = colRefs.current[status]
    if (el && boardScrollRef.current) {
      boardScrollRef.current.scrollTo({
        left: el.offsetLeft - 12,
        behavior: 'smooth',
      })
    }
  }

  // 屏幕一：发送消息
  const handleSendMobileChat = (e: React.FormEvent) => {
    e.preventDefault()
    if (isObserver || !chatInput.trim()) return
    setMessages((prev) => [
      ...prev,
      {
        id: `mm-${Date.now()}`,
        kind: 'chat',
        sender: '林知夏',
        senderShort: '林',
        role: currentRole,
        time: '17:50',
        text: chatInput.trim(),
      },
    ])
    setChatInput('')
    if (mobileEmptyDemo) setMobileEmptyDemo(false)
  }

  // 屏幕一：将普通消息转为决策提案
  const handlePromoteMobileMsg = (m: MobileMessage) => {
    if (isObserver) return
    setMessages((prev) => [
      ...prev,
      {
        id: `mm-p-${Date.now()}`,
        kind: 'proposal',
        sender: m.sender || '周舟',
        senderShort: m.senderShort || '周',
        time: '17:51',
        proposalId: 'DEC-P05',
        proposalConfirmed: false,
        text: `由讨论形成决策提案：${m.text}`,
      },
    ])
  }

  // 屏幕三：执行底部固定区的主要动作
  const getPrimaryActionConfig = (
    status: TaskStatus
  ): { label: string; nextStatus?: TaskStatus; openAcceptModal?: boolean } => {
    switch (status) {
      case 'pending_accept':
        return { label: '去验收（签批结论）', openAcceptModal: true }
      case 'in_progress':
        return { label: '提交验收 → 待验收', nextStatus: 'pending_accept' }
      case 'ready':
        return { label: '开始执行 → 进行中', nextStatus: 'in_progress' }
      case 'unclaimed':
        return { label: '认领任务 → 已就绪', nextStatus: 'ready' }
      case 'clarify':
        return { label: '补齐定义 → 待认领', nextStatus: 'unclaimed' }
      case 'done':
        return { label: '重新打开 (产生返工轮次)', nextStatus: 'in_progress' }
      default:
        return { label: '解除旁路 → 恢复进行中', nextStatus: 'in_progress' }
    }
  }

  const primaryAction = getPrimaryActionConfig(detailTask.status)

  const handlePrimaryActionClick = () => {
    if (isObserver) return
    if (primaryAction.openAcceptModal) {
      setAcceptSheetOpen(true)
      return
    }
    if (primaryAction.nextStatus) {
      const nextRework =
        detailTask.status === 'done'
          ? detailTask.reworkRound + 1
          : detailTask.reworkRound
      onUpdateTask({
        ...detailTask,
        status: primaryAction.nextStatus,
        reworkRound: nextRework,
        updatedAt: '2025-05-14 17:52',
      })
      triggerToast(`已流转至：${primaryAction.nextStatus}`)
    }
  }

  return (
    <div className="flex h-full w-full flex-col overflow-hidden select-text">
      {/* =====================================================================
          顶部画布控制栏（切换三屏并排 390×844 vs 单屏预览 + 移动端简短空状态验证）
         ===================================================================== */}
      <div
        style={{
          backgroundColor: 'var(--cf-surface-secondary)',
          borderBottom: '1px solid var(--cf-border-strong)',
        }}
        className="flex shrink-0 flex-wrap items-center justify-between gap-2 px-6 py-2 text-[11px]"
      >
        <div className="flex items-center gap-2">
          <span
            style={{
              backgroundColor: 'var(--cf-primary)',
              color: 'var(--cf-surface-card)',
            }}
            className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-bold"
          >
            MOBILE 390×844 SUITE
          </span>
          <span className="font-bold text-[var(--cf-text-primary)]">
            移动端三页（390×844 · iOS/Android 通用 · 最小触控目标 44×44 · 第一优先级：「今天需要我做什么」）
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setMobileEmptyDemo((v) => !v)}
            style={{
              backgroundColor: mobileEmptyDemo
                ? 'var(--cf-warning)'
                : 'var(--cf-surface-card)',
              color: mobileEmptyDemo
                ? 'var(--cf-surface-card)'
                : 'var(--cf-text-secondary)',
              borderColor: 'var(--cf-border-strong)',
            }}
            className="h-[24px] border px-2.5 font-medium"
          >
            {mobileEmptyDemo
              ? '✓ 已开启：移动端简短空状态'
              : '切换验证：移动端简短空状态'}
          </button>

          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
            }}
            className="flex items-center border p-0.5"
          >
            {[
              { id: 'triple', label: '三屏同台并排 (3 × 390×844)' },
              { id: 'm_workbench', label: '一、工作台' },
              { id: 'm_board', label: '二、任务看板' },
              { id: 'm_detail', label: '三、任务详情' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setDisplayLayout(tab.id as typeof displayLayout)}
                style={{
                  backgroundColor:
                    displayLayout === tab.id ? 'var(--cf-primary)' : 'transparent',
                  color:
                    displayLayout === tab.id
                      ? 'var(--cf-surface-card)'
                      : 'var(--cf-text-secondary)',
                }}
                className="h-[22px] px-2 font-semibold"
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* =====================================================================
          画布展示区：三台 390×844 移动设备视口容器
         ===================================================================== */}
      <div className="flex-1 overflow-auto bg-[#DFDBD2] px-4 py-4">
        <div className="mx-auto flex w-fit items-start justify-center gap-6">
          {/* =================================================================
              移动页面一：一、工作台（移动端 · 390×844）
             ================================================================= */}
          {(displayLayout === 'triple' || displayLayout === 'm_workbench') && (
            <div className="flex flex-col items-center">
              <div className="mb-1.5 flex w-[390px] items-center justify-between px-1 text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                <span>01 · 工作台（移动端）</span>
                <span className="font-mono-tabular text-[var(--cf-primary)]">
                  390 × 844 px
                </span>
              </div>

              {/* 390×844 手机视口严格容器 */}
              <div
                style={{
                  width: '390px',
                  height: '844px',
                  backgroundColor: 'var(--cf-surface-paper)',
                  borderColor: 'var(--cf-text-primary)',
                  boxShadow: '0 10px 28px rgba(28,25,23,0.18)',
                }}
                className="relative flex flex-col overflow-hidden rounded-[22px] border-[3px]"
              >
                {/* iOS/Android 通用状态栏 (24px) */}
                <div
                  style={{
                    backgroundColor: 'var(--cf-primary-deep)',
                    color: 'var(--cf-surface-card)',
                  }}
                  className="flex h-[24px] shrink-0 items-center justify-between px-4 font-mono-tabular text-[10px]"
                >
                  <span>09:41</span>
                  <span>COFLOW MOBILE · 5G</span>
                </div>

                {/* 1. 顶部：项目代号 + 项目名 + 交付进度百分比 */}
                <header
                  style={{
                    backgroundColor: 'var(--cf-primary)',
                    color: 'var(--cf-surface-card)',
                  }}
                  className="shrink-0 px-3.5 py-2.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex min-w-0 items-center gap-2">
                      <span
                        style={{
                          backgroundColor: 'var(--cf-primary-deep)',
                          borderColor: 'var(--cf-primary-border)',
                        }}
                        className="shrink-0 border px-1.5 py-0.5 font-mono-tabular text-[11px] font-bold text-[#A7F3D0]"
                      >
                        ZX
                      </span>
                      <h2 className="truncate text-[14px] font-bold text-white">
                        多智能体企业知识库混合检索系统
                      </h2>
                    </div>
                    <span className="font-mono-tabular shrink-0 text-[12px] font-bold text-[#A7F3D0]">
                      进度 72%
                    </span>
                  </div>
                  {/* 紧凑进度条 */}
                  <div className="mt-1.5 h-[4px] w-full overflow-hidden bg-[#062629]">
                    <div className="h-full w-[72%] bg-[#34D399]" />
                  </div>
                </header>

                {/* 2. 一条横向可滚动的项目内导航（工作台 / 任务与分工 / 产物与验收 / 决策与时间线 / 项目设置）
                       每个按钮严格保证 min-h-[44px] 触控目标 */}
                <nav
                  style={{
                    backgroundColor: 'var(--cf-surface-card)',
                    borderBottom: '1px solid var(--cf-border-strong)',
                  }}
                  className="flex shrink-0 items-center overflow-x-auto whitespace-nowrap px-1.5"
                >
                  {(
                    [
                      { id: 'workbench', label: '工作台' },
                      { id: 'tasks', label: '任务与分工' },
                      { id: 'artifacts', label: '产物与验收' },
                      { id: 'decisions', label: '决策与时间线' },
                      { id: 'settings', label: '项目设置' },
                    ] as { id: MobileNavTab; label: string }[]
                  ).map((nav) => {
                    const isActive = activeNavTab === nav.id
                    return (
                      <button
                        key={nav.id}
                        type="button"
                        onClick={() => setActiveNavTab(nav.id)}
                        style={{
                          borderBottom: isActive
                            ? '3px solid var(--cf-primary)'
                            : '3px solid transparent',
                          color: isActive
                            ? 'var(--cf-primary)'
                            : 'var(--cf-text-secondary)',
                        }}
                        className="inline-flex min-h-[44px] shrink-0 items-center justify-center px-3 text-[13px] font-semibold transition-colors"
                      >
                        {nav.label}
                      </button>
                    )
                  })}
                </nav>

                {/* 3. 核心设计：顶部可滑出的「今天需要我做什么（风险 / 需要处理）」角标入口与抽屉面板 */}
                <div
                  style={{
                    backgroundColor: 'var(--cf-warning-bg)',
                    borderBottom: '1px solid var(--cf-warning)',
                  }}
                  className="shrink-0"
                >
                  {/* 44px 高触控入口横梁 */}
                  <button
                    type="button"
                    onClick={() => setDrawerOpen((v) => !v)}
                    className="flex min-h-[44px] w-full items-center justify-between px-3.5 text-left"
                  >
                    <div className="flex items-center gap-2">
                      <span
                        style={{
                          backgroundColor: 'var(--cf-danger)',
                          color: 'var(--cf-surface-card)',
                        }}
                        className="px-1.5 py-0.5 font-mono-tabular text-[11px] font-bold"
                      >
                        今日待办 {pendingDecisionConfirmed ? 2 : 3}
                      </span>
                      <span
                        style={{
                          backgroundColor: 'var(--cf-warning)',
                          color: 'var(--cf-surface-card)',
                        }}
                        className="px-1.5 py-0.5 font-mono-tabular text-[11px] font-bold"
                      >
                        高风险 2
                      </span>
                      <span className="text-[12px] font-bold text-[var(--cf-text-primary)]">
                        今天需要我做什么
                      </span>
                    </div>
                    <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]">
                      {drawerOpen ? '收起面板 ▲' : '展开处理 ▾'}
                    </span>
                  </button>

                  {/* 从顶部滑出的「需要处理 + 风险」高密度抽屉面板 */}
                  {drawerOpen && !mobileEmptyDemo && (
                    <div
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderTop: '1px solid var(--cf-border-strong)',
                      }}
                      className="max-h-[250px] divide-y divide-[var(--cf-border-subtle)] overflow-y-auto px-3 py-2 text-[12px] shadow-md"
                    >
                      {/* 待确认决策 */}
                      {!pendingDecisionConfirmed && (
                        <div className="flex items-center justify-between gap-2 py-1.5">
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5">
                              <span className="bg-[var(--cf-warning)] px-1 py-0.2 text-[10px] font-bold text-white">
                                待确认决策
                              </span>
                              <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                                DEC-P04
                              </span>
                            </div>
                            <p className="mt-0.5 truncate text-[12px] font-medium text-[var(--cf-text-primary)]">
                              路演演示台切换为本地离线快照包 v1.4
                            </p>
                          </div>
                          {(currentRole === 'initiator' || currentRole === 'owner') && (
                            <button
                              type="button"
                              onClick={() => setPendingDecisionConfirmed(true)}
                              style={{
                                backgroundColor: 'var(--cf-primary)',
                                color: 'var(--cf-surface-card)',
                              }}
                              className="min-h-[44px] min-w-[76px] shrink-0 px-2.5 text-[11px] font-semibold"
                            >
                              确认入库
                            </button>
                          )}
                        </div>
                      )}

                      {/* 待验收任务 */}
                      <div className="flex items-center justify-between gap-2 py-1.5">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <TaskStatusBadge status="pending_accept" size="compact" />
                            <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                              TSK-108
                            </span>
                            <span className="text-[11px] font-semibold text-[var(--cf-warning)]">
                              已等待验收 6 天
                            </span>
                          </div>
                          <p className="mt-0.5 truncate text-[12px] font-medium text-[var(--cf-text-primary)]">
                            向量检索模块召回率评测与章程指标对齐
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => setDetailTaskId('TSK-108')}
                          style={{
                            borderColor: 'var(--cf-primary)',
                            color: 'var(--cf-primary)',
                            backgroundColor: 'var(--cf-primary-tint)',
                          }}
                          className="min-h-[44px] min-w-[68px] shrink-0 border px-2 text-[11px] font-semibold"
                        >
                          去验收 →
                        </button>
                      </div>

                      {/* 高风险与阻塞 */}
                      <div className="py-1.5">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-bold text-[var(--cf-danger)]">
                            [高风险 · TSK-109] 阻塞 5 天
                          </span>
                          <span className="font-mono-tabular text-[var(--cf-danger)]">
                            需要：营业执照
                          </span>
                        </div>
                        <div className="mt-1 flex items-center justify-between text-[11px]">
                          <span className="font-bold text-[var(--cf-danger)]">
                            [高风险 · TSK-106] 负样本基线对齐
                          </span>
                          <span className="font-mono-tabular text-[var(--cf-danger)]">
                            已逾期 3 天
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* 4. 主要内容：项目频道消息流 (#general · 6 种消息类型区分) */}
                <div className="flex-1 space-y-2.5 overflow-y-auto p-3">
                  <div className="flex items-center justify-between text-[11px] text-[var(--cf-text-tertiary)]">
                    <span className="font-mono-tabular font-bold text-[var(--cf-text-primary)]">
                      #general 频道流
                    </span>
                    <span>长按或点右侧「转决策」沉淀事实</span>
                  </div>

                  {mobileEmptyDemo ? (
                    /* 移动端简短空状态 */
                    <div
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: 'var(--cf-border-strong)',
                      }}
                      className="my-8 border border-dashed p-5 text-center"
                    >
                      <div className="text-[13px] font-bold text-[var(--cf-text-primary)]">
                        暂无讨论消息
                      </div>
                      <p className="mt-1 text-[12px] text-[var(--cf-text-tertiary)]">
                        在底部发消息，或展开顶部「今日待办」处理验收。
                      </p>
                    </div>
                  ) : (
                    messages.map((m) => {
                      /* 系统事件 */
                      if (m.kind === 'system') {
                        return (
                          <div
                            key={m.id}
                            style={{
                              backgroundColor: 'var(--cf-surface-tertiary)',
                              borderColor: 'var(--cf-border-strong)',
                            }}
                            className="border-y px-2.5 py-1.5 text-[11px]"
                          >
                            <div className="flex items-center justify-between">
                              <span className="bg-[var(--cf-neutral)] px-1.5 py-0.2 font-mono-tabular text-[10px] font-semibold text-white">
                                系统 · {m.tag}
                              </span>
                              <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                                {m.time}
                              </span>
                            </div>
                            <p className="mt-1 text-[var(--cf-text-secondary)]">{m.text}</p>
                          </div>
                        )
                      }

                      /* Agent 汇报（弱化折叠条，44px 触控高度） */
                      if (m.kind === 'agent_report') {
                        const expanded = !!expandedAgentIds[m.id]
                        return (
                          <div
                            key={m.id}
                            style={{
                              backgroundColor: 'var(--cf-surface-tertiary)',
                              borderColor: 'var(--cf-border-strong)',
                            }}
                            className="ml-3 border-l-2 px-2.5 py-1 text-[11px]"
                          >
                            <button
                              type="button"
                              onClick={() =>
                                setExpandedAgentIds((prev) => ({
                                  ...prev,
                                  [m.id]: !expanded,
                                }))
                              }
                              className="flex min-h-[44px] w-full items-center justify-between gap-2 text-left"
                            >
                              <div className="min-w-0">
                                <div className="font-mono-tabular text-[10px] font-semibold text-[var(--cf-text-secondary)]">
                                  [AGENT 汇报] {m.tag}
                                </div>
                                <div className="truncate text-[var(--cf-text-secondary)]">
                                  {m.text}
                                </div>
                              </div>
                              <span className="font-mono-tabular shrink-0 text-[10px] text-[var(--cf-primary)]">
                                {expanded ? '收起 ▲' : '路径 ▾'}
                              </span>
                            </button>
                            {expanded && m.codePath && (
                              <div className="overflow-x-auto border-t border-dashed border-[var(--cf-border-strong)] py-1.5 font-mono-tabular text-[11px] text-[var(--cf-primary)]">
                                {m.codePath}
                              </div>
                            )}
                          </div>
                        )
                      }

                      /* 阻塞求助 */
                      if (m.kind === 'blocker') {
                        return (
                          <div
                            key={m.id}
                            style={{
                              backgroundColor: 'var(--cf-danger-bg)',
                              borderColor: 'var(--cf-danger)',
                              borderLeftWidth: '4px',
                            }}
                            className="border p-2.5 text-[12px]"
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-1.5">
                                <span className="bg-[var(--cf-danger)] px-1.5 py-0.2 text-[10px] font-bold text-white">
                                  阻塞
                                </span>
                                <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-danger)]">
                                  {m.tag}
                                </span>
                                <span className="font-semibold">{m.sender}</span>
                              </div>
                              <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                                {m.time}
                              </span>
                            </div>
                            <p className="mt-1 text-[13px] leading-[19px] text-[var(--cf-text-primary)]">
                              {m.text}
                            </p>
                            {m.needWhat && (
                              <div className="mt-1.5 border border-[var(--cf-danger-border)] bg-white px-2 py-1 text-[11px] font-bold text-[var(--cf-danger)]">
                                {m.needWhat}
                              </div>
                            )}
                          </div>
                        )
                      }

                      /* 产物提交（路径支持横向滚动或换行，绝不溢出） */
                      if (m.kind === 'artifact') {
                        return (
                          <div
                            key={m.id}
                            style={{
                              backgroundColor: 'var(--cf-surface-card)',
                              borderColor: 'var(--cf-primary)',
                              borderLeftWidth: '4px',
                            }}
                            className="border p-2.5 text-[12px]"
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-1.5">
                                <span className="bg-[var(--cf-primary)] px-1.5 py-0.2 text-[10px] font-bold text-white">
                                  产物
                                </span>
                                <span className="font-semibold">{m.sender}</span>
                                <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                                  {m.tag}
                                </span>
                              </div>
                              <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                                {m.time}
                              </span>
                            </div>
                            <p className="mt-1 text-[13px] leading-[19px]">{m.text}</p>
                            {m.codePath && (
                              <div className="mt-1.5 overflow-x-auto border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)] px-2 py-1 font-mono-tabular text-[11px] whitespace-nowrap text-[var(--cf-primary)]">
                                位置：{m.codePath}
                              </div>
                            )}
                          </div>
                        )
                      }

                      /* 决策提案 */
                      if (m.kind === 'proposal') {
                        return (
                          <div
                            key={m.id}
                            style={{
                              backgroundColor: 'var(--cf-warning-bg)',
                              borderColor: 'var(--cf-warning)',
                              borderLeftWidth: '4px',
                            }}
                            className="border p-2.5 text-[12px]"
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-1.5">
                                <span className="bg-[var(--cf-warning)] px-1.5 py-0.2 text-[10px] font-bold text-white">
                                  决策提案
                                </span>
                                <span className="font-mono-tabular text-[11px] font-bold">
                                  {m.proposalId}
                                </span>
                                <span className="font-semibold">{m.sender}</span>
                              </div>
                              <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                                {m.time}
                              </span>
                            </div>
                            <p className="mt-1 text-[13px] leading-[19px]">{m.text}</p>
                          </div>
                        )
                      }

                      /* 普通讨论（右侧配 44×44 触控热区的「形成决策」按钮） */
                      return (
                        <div
                          key={m.id}
                          style={{
                            backgroundColor: 'var(--cf-surface-card)',
                            borderColor: 'var(--cf-border-subtle)',
                          }}
                          className="border p-2.5"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-1.5">
                              <SingleAvatar
                                item={{
                                  id: m.id,
                                  name: m.sender || '成员',
                                  short: m.senderShort || '员',
                                  kind: 'human',
                                }}
                                size={22}
                              />
                              <span className="text-[12px] font-bold">{m.sender}</span>
                              {m.role && <RoleBadge role={m.role} />}
                              <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                                {m.time}
                              </span>
                            </div>

                            {!isObserver && (
                              <button
                                type="button"
                                onClick={() => handlePromoteMobileMsg(m)}
                                style={{
                                  borderColor: 'var(--cf-border-strong)',
                                  backgroundColor: 'var(--cf-surface-secondary)',
                                  color: 'var(--cf-primary)',
                                }}
                                className="inline-flex min-h-[44px] min-w-[64px] items-center justify-center border px-2 text-[11px] font-semibold"
                              >
                                + 转决策
                              </button>
                            )}
                          </div>
                          <p className="mt-1 text-[13px] leading-[20px] text-[var(--cf-text-primary)]">
                            {m.text}
                          </p>
                        </div>
                      )
                    })
                  )}
                </div>

                {/* 5. 底部固定输入框（触控目标 ≥ 44×44） */}
                {isObserver ? (
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-secondary)',
                      borderTop: '1px solid var(--cf-border-strong)',
                    }}
                    className="flex min-h-[52px] shrink-0 items-center justify-center px-3 text-[12px] text-[var(--cf-text-secondary)]"
                  >
                    当前身份只读（观察员）：输入框已隐藏
                  </div>
                ) : (
                  <form
                    onSubmit={handleSendMobileChat}
                    style={{
                      backgroundColor: 'var(--cf-surface-secondary)',
                      borderTop: '1px solid var(--cf-border-strong)',
                    }}
                    className="flex shrink-0 items-center gap-2 p-2.5"
                  >
                    <input
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder="发送消息至 #general..."
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: 'var(--cf-border-strong)',
                      }}
                      className="min-h-[44px] flex-1 border px-3 text-[13px] outline-none focus:border-[var(--cf-primary)]"
                    />
                    <button
                      type="submit"
                      style={{
                        backgroundColor: 'var(--cf-primary)',
                        color: 'var(--cf-surface-card)',
                      }}
                      className="min-h-[44px] min-w-[60px] shrink-0 px-3 text-[13px] font-semibold"
                    >
                      发送
                    </button>
                  </form>
                )}
              </div>
            </div>
          )}

          {/* =================================================================
              移动页面二：二、任务看板（移动端 · 390×844）
             ================================================================= */}
          {(displayLayout === 'triple' || displayLayout === 'm_board') && (
            <div className="flex flex-col items-center">
              <div className="mb-1.5 flex w-[390px] items-center justify-between px-1 text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                <span>02 · 任务看板（移动端 · 露出 1.5 列左右滑）</span>
                <span className="font-mono-tabular text-[var(--cf-primary)]">
                  390 × 844 px
                </span>
              </div>

              <div
                style={{
                  width: '390px',
                  height: '844px',
                  backgroundColor: 'var(--cf-surface-paper)',
                  borderColor: 'var(--cf-text-primary)',
                  boxShadow: '0 10px 28px rgba(28,25,23,0.18)',
                }}
                className="relative flex flex-col overflow-hidden rounded-[22px] border-[3px]"
              >
                {/* 状态栏 */}
                <div
                  style={{
                    backgroundColor: 'var(--cf-primary-deep)',
                    color: 'var(--cf-surface-card)',
                  }}
                  className="flex h-[24px] shrink-0 items-center justify-between px-4 font-mono-tabular text-[10px]"
                >
                  <span>09:41</span>
                  <span>COFLOW MOBILE · 5G</span>
                </div>

                {/* 1. 顶部：项目代号 + 项目名 */}
                <header
                  style={{
                    backgroundColor: 'var(--cf-primary)',
                    color: 'var(--cf-surface-card)',
                  }}
                  className="flex min-h-[48px] shrink-0 items-center justify-between px-3.5 py-1.5"
                >
                  <div className="flex min-w-0 items-center gap-2">
                    <span
                      style={{
                        backgroundColor: 'var(--cf-primary-deep)',
                        borderColor: 'var(--cf-primary-border)',
                      }}
                      className="shrink-0 border px-1.5 py-0.5 font-mono-tabular text-[11px] font-bold text-[#A7F3D0]"
                    >
                      ZX
                    </span>
                    <h2 className="truncate text-[14px] font-bold text-white">
                      多智能体企业知识库混合检索系统
                    </h2>
                  </div>
                  <span className="font-mono-tabular shrink-0 text-[11px] text-[#E3F1F2]">
                    任务看板
                  </span>
                </header>

                {/* 2. 顶部状态切换分段控件（让用户快速跳到某一列，每个触控按钮 min-h-[44px]） */}
                <div
                  style={{
                    backgroundColor: 'var(--cf-surface-card)',
                    borderBottom: '1px solid var(--cf-border-strong)',
                  }}
                  className="shrink-0 px-2 py-1.5"
                >
                  <div className="flex items-center gap-1 overflow-x-auto whitespace-nowrap">
                    {KANBAN_STATUS_COLS.map((col) => {
                      const count = mobileEmptyDemo
                        ? 0
                        : tasks.filter((t) => t.status === col.status).length
                      const isSelected = activeBoardCol === col.status
                      return (
                        <button
                          key={col.status}
                          type="button"
                          onClick={() => handleJumpToColumn(col.status)}
                          style={{
                            backgroundColor: isSelected
                              ? 'var(--cf-primary)'
                              : 'var(--cf-surface-secondary)',
                            color: isSelected
                              ? 'var(--cf-surface-card)'
                              : 'var(--cf-text-primary)',
                            borderColor: isSelected
                              ? 'var(--cf-primary)'
                              : 'var(--cf-border-strong)',
                          }}
                          className="inline-flex min-h-[44px] shrink-0 items-center gap-1 border px-2.5 text-[12px] font-semibold transition-colors"
                        >
                          <span>{col.label}</span>
                          <span className="font-mono-tabular text-[11px] opacity-85">
                            ({count})
                          </span>
                        </button>
                      )
                    })}
                  </div>

                  {/* 左右滑动提示 */}
                  <div className="mt-1 flex items-center justify-between px-1 text-[11px] text-[var(--cf-text-tertiary)]">
                    <span>⇄ 左右滑动切换状态列（每次露出 1.5 列）</span>
                    <span className="font-mono-tabular text-[10px]">
                      点任务卡进详情 →
                    </span>
                  </div>
                </div>

                {/* 3. 横向滚动的列表（不是六列并排！每列宽 238px，在 390px 屏下恰好露出 1.55 列） */}
                <div
                  ref={boardScrollRef}
                  className="flex flex-1 snap-x snap-mandatory gap-3 overflow-x-auto px-3 py-3"
                >
                  {KANBAN_STATUS_COLS.map((col) => {
                    const colTasks = mobileEmptyDemo
                      ? []
                      : tasks.filter((t) => t.status === col.status)
                    const totalWeight = colTasks.reduce((s, t) => s + t.weight, 0)

                    return (
                      <div
                        key={col.status}
                        ref={(el) => {
                          colRefs.current[col.status] = el
                        }}
                        style={{
                          width: '238px',
                          backgroundColor: 'var(--cf-surface-secondary)',
                          borderColor:
                            activeBoardCol === col.status
                              ? 'var(--cf-primary)'
                              : 'var(--cf-border-strong)',
                          borderRadius: 'var(--cf-radius-container)',
                        }}
                        className="flex h-full shrink-0 snap-start flex-col overflow-hidden border"
                      >
                        {/* 列头：状态名 + 数量 */}
                        <div
                          style={{
                            backgroundColor: 'var(--cf-surface-card)',
                            borderBottom: '1px solid var(--cf-border-strong)',
                          }}
                          className="flex items-center justify-between px-3 py-2"
                        >
                          <TaskStatusBadge status={col.status} size="compact" />
                          <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-text-primary)]">
                            {colTasks.length} 项 · 权重 {totalWeight}
                          </span>
                        </div>

                        {/* 列内任务卡 */}
                        <div className="flex-1 space-y-2.5 overflow-y-auto p-2.5">
                          {colTasks.length === 0 ? (
                            /* 移动端简短空状态 */
                            <div
                              style={{
                                backgroundColor: 'var(--cf-surface-card)',
                                borderColor: 'var(--cf-border-strong)',
                              }}
                              className="flex h-28 items-center justify-center border border-dashed p-3 text-center text-[12px] text-[var(--cf-text-tertiary)]"
                            >
                              本列暂无任务
                            </div>
                          ) : (
                            colTasks.map((t) => {
                              const isSelectedTask = t.id === detailTaskId
                              return (
                                <div
                                  key={t.id}
                                  onClick={() => {
                                    setDetailTaskId(t.id)
                                    if (displayLayout === 'm_board') {
                                      setDisplayLayout('m_detail')
                                    }
                                  }}
                                  style={{
                                    backgroundColor: 'var(--cf-surface-card)',
                                    borderColor: isSelectedTask
                                      ? 'var(--cf-primary)'
                                      : 'var(--cf-border-strong)',
                                    boxShadow: 'var(--cf-shadow-card)',
                                    borderRadius: 'var(--cf-radius-container)',
                                  }}
                                  className="min-h-[88px] cursor-pointer border p-3 transition-transform active:scale-[0.99]"
                                >
                                  {/* 优先级 + 截止日 */}
                                  <div className="flex items-center justify-between gap-1">
                                    <div className="flex items-center gap-1.5">
                                      <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                                        {t.id}
                                      </span>
                                      <PriorityBadge
                                        level={t.priority}
                                        showLabel={false}
                                      />
                                      {t.reworkRound > 0 && (
                                        <span className="border border-[var(--cf-warning)] bg-[var(--cf-warning-bg)] px-1 font-mono-tabular text-[10px] font-bold text-[var(--cf-warning)]">
                                          R{t.reworkRound}
                                        </span>
                                      )}
                                    </div>
                                    <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                                      {t.dueDate.slice(5)}
                                    </span>
                                  </div>

                                  {/* 标题（最多两行） */}
                                  <h4 className="mt-1.5 line-clamp-2 text-[13px] font-bold leading-[19px] text-[var(--cf-text-primary)]">
                                    {t.title}
                                  </h4>

                                  {/* 底栏：负责人头像 + 产物数/依赖数 */}
                                  <div className="mt-2.5 flex items-center justify-between border-t border-[var(--cf-border-subtle)] pt-2">
                                    <div className="flex items-center gap-1.5">
                                      {t.assigneeName ? (
                                        <>
                                          <SingleAvatar
                                            item={{
                                              id: t.id,
                                              name: t.assigneeName,
                                              short: t.assigneeShort || '员',
                                              kind: 'human',
                                            }}
                                            size={22}
                                          />
                                          <span className="text-[11px] font-medium text-[var(--cf-text-secondary)]">
                                            {t.assigneeName}
                                          </span>
                                        </>
                                      ) : (
                                        <span className="text-[11px] text-[var(--cf-warning)]">
                                          未指派
                                        </span>
                                      )}
                                    </div>

                                    <div className="font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                                      产物 {t.artifacts.length} · 依赖 {t.dependencies.length}
                                    </div>
                                  </div>
                                </div>
                              )
                            })
                          )}
                        </div>
                      </div>
                    )
                  })}
                </div>

                {/* 底部旁路阻塞速查条（44px 高触控） */}
                <div
                  style={{
                    backgroundColor: 'var(--cf-danger-bg)',
                    borderTop: '1px solid var(--cf-danger)',
                  }}
                  className="flex min-h-[46px] shrink-0 items-center justify-between px-3.5 text-[11px]"
                >
                  <div className="flex items-center gap-1.5 min-w-0">
                    <TaskStatusBadge status="blocked" size="compact" />
                    <span className="truncate font-semibold text-[var(--cf-danger)]">
                      旁路阻塞 2 项：TSK-109 缺营业执照 · TSK-106 逾期
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setDetailTaskId('TSK-109')}
                    className="min-h-[44px] shrink-0 px-2 font-mono-tabular font-bold text-[var(--cf-danger)] underline"
                  >
                    查看 →
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* =================================================================
              移动页面三：三、任务详情（移动端 · 390×844）
             ================================================================= */}
          {(displayLayout === 'triple' || displayLayout === 'm_detail') && (
            <div className="flex flex-col items-center">
              <div className="mb-1.5 flex w-[390px] items-center justify-between px-1 text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                <span>03 · 任务详情（移动端 · 底部主动作 + 更多面板）</span>
                <span className="font-mono-tabular text-[var(--cf-primary)]">
                  390 × 844 px
                </span>
              </div>

              <div
                style={{
                  width: '390px',
                  height: '844px',
                  backgroundColor: 'var(--cf-surface-paper)',
                  borderColor: 'var(--cf-text-primary)',
                  boxShadow: '0 10px 28px rgba(28,25,23,0.18)',
                }}
                className="relative flex flex-col overflow-hidden rounded-[22px] border-[3px]"
              >
                {/* 状态栏 */}
                <div
                  style={{
                    backgroundColor: 'var(--cf-primary-deep)',
                    color: 'var(--cf-surface-card)',
                  }}
                  className="flex h-[24px] shrink-0 items-center justify-between px-4 font-mono-tabular text-[10px]"
                >
                  <span>09:41</span>
                  <span>COFLOW MOBILE · 5G</span>
                </div>

                {/* 1. 顶部：返回 (44×44)、状态徽标、优先级 + 快速切换任务 */}
                <header
                  style={{
                    backgroundColor: 'var(--cf-surface-card)',
                    borderBottom: '1px solid var(--cf-border-strong)',
                  }}
                  className="flex min-h-[48px] shrink-0 items-center justify-between px-2"
                >
                  <button
                    type="button"
                    onClick={() => {
                      if (displayLayout === 'm_detail') setDisplayLayout('m_board')
                    }}
                    className="inline-flex min-h-[44px] min-w-[64px] items-center justify-center gap-1 text-[13px] font-bold text-[var(--cf-primary)]"
                  >
                    <span>← 返回</span>
                  </button>

                  <div className="flex items-center gap-1.5">
                    <TaskStatusBadge status={detailTask.status} size="compact" />
                    <PriorityBadge level={detailTask.priority} showLabel={false} />
                    <select
                      value={detailTask.id}
                      onChange={(e) => setDetailTaskId(e.target.value)}
                      className="font-mono-tabular h-[32px] border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] px-1.5 text-[11px] font-bold text-[var(--cf-primary)]"
                    >
                      {tasks.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.id}
                        </option>
                      ))}
                    </select>
                  </div>
                </header>

                {/* 操作反馈轻提示 */}
                {mobileToast && (
                  <div
                    style={{
                      backgroundColor: 'var(--cf-success)',
                      color: 'var(--cf-surface-card)',
                    }}
                    className="shrink-0 px-3.5 py-1.5 text-center text-[12px] font-semibold"
                  >
                    ✓ {mobileToast}
                  </div>
                )}

                {/* 主体滚动区：标题 → 元信息（可折行） → 任务定义 → 产物与证据 → 验收记录 */}
                <div className="flex-1 space-y-3 overflow-y-auto p-3">
                  {/* 2. 标题 + 元信息（负责人、验收人、截止、权重 · 可折行 2×2 网格） */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                      boxShadow: 'var(--cf-shadow-card)',
                      borderRadius: 'var(--cf-radius-container)',
                    }}
                    className="border p-3"
                  >
                    <div className="flex items-center justify-between font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                      <span>
                        {detailTask.id} · v{detailTask.definitionVersion}
                      </span>
                      {detailTask.reworkRound > 0 && (
                        <span className="border border-[var(--cf-warning)] bg-[var(--cf-warning-bg)] px-1.5 font-bold text-[var(--cf-warning)]">
                          返工 R{detailTask.reworkRound}
                        </span>
                      )}
                    </div>

                    <h1 className="mt-1 text-[15px] font-bold leading-[22px] text-[var(--cf-text-primary)]">
                      {detailTask.title}
                    </h1>

                    {/* 元信息：负责人、验收人、截止、权重（自动折行 2×2 台账格） */}
                    <div
                      style={{
                        backgroundColor: 'var(--cf-surface-secondary)',
                        borderColor: 'var(--cf-border-subtle)',
                      }}
                      className="mt-2.5 grid grid-cols-2 gap-2 border p-2 text-[12px]"
                    >
                      <div>
                        <span className="text-[10px] text-[var(--cf-text-tertiary)]">
                          负责人：
                        </span>
                        <div className="font-semibold text-[var(--cf-text-primary)]">
                          {detailTask.assigneeName || '未指派'}
                        </div>
                      </div>
                      <div>
                        <span className="text-[10px] text-[var(--cf-text-tertiary)]">
                          验收人：
                        </span>
                        <div className="font-semibold text-[var(--cf-text-primary)]">
                          {detailTask.reviewerName}
                        </div>
                      </div>
                      <div>
                        <span className="text-[10px] text-[var(--cf-text-tertiary)]">
                          截止日期：
                        </span>
                        <div className="font-mono-tabular font-semibold text-[var(--cf-text-primary)]">
                          {detailTask.dueDate}
                        </div>
                      </div>
                      <div>
                        <span className="text-[10px] text-[var(--cf-text-tertiary)]">
                          权重：
                        </span>
                        <div className="font-mono-tabular font-bold text-[var(--cf-primary)]">
                          {detailTask.weight} pt
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 3. 任务定义：说明、输入材料、工作范围、非工作范围、验收标准（长路径可横向滚动或换行） */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                      borderRadius: 'var(--cf-radius-container)',
                    }}
                    className="space-y-2.5 border p-3 text-[12px]"
                  >
                    <div className="font-bold text-[var(--cf-text-primary)]">
                      任务定义
                    </div>

                    <div>
                      <div className="text-[11px] font-semibold text-[var(--cf-text-tertiary)]">
                        任务说明
                      </div>
                      <p className="mt-0.5 text-[13px] leading-[19px] text-[var(--cf-text-primary)]">
                        {detailTask.description}
                      </p>
                    </div>

                    {/* 输入材料（代码/路径支持横向滚动或断行，不溢出） */}
                    <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)] p-2">
                      <div className="text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                        输入材料 ({detailTask.inputMaterials.length})
                      </div>
                      <div className="mt-1 space-y-1 overflow-x-auto font-mono-tabular text-[11px] text-[var(--cf-primary)]">
                        {detailTask.inputMaterials.map((inp, i) => (
                          <div key={i} className="break-all">
                            • {inp}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* 工作范围 & 非工作范围 */}
                    <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)] p-2">
                      <div className="text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                        工作范围
                      </div>
                      <div className="mt-1 space-y-1 overflow-x-auto font-mono-tabular text-[11px] text-[var(--cf-text-primary)]">
                        {detailTask.workScope.map((ws, i) => (
                          <div key={i} className="break-all">
                            • {ws}
                          </div>
                        ))}
                      </div>
                      <div className="mt-2 border-t border-[var(--cf-border-subtle)] pt-1.5 text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                        非工作范围
                      </div>
                      <div className="mt-0.5 text-[11px] text-[var(--cf-text-tertiary)]">
                        {detailTask.nonWorkScope.join('；')}
                      </div>
                    </div>

                    {/* 验收标准（突出显示） */}
                    <div
                      style={{
                        backgroundColor: 'var(--cf-primary-tint)',
                        borderColor: 'var(--cf-primary)',
                        borderLeftWidth: '4px',
                      }}
                      className="border p-2.5"
                    >
                      <div className="text-[11px] font-bold text-[var(--cf-primary)]">
                        ★ 验收标准
                      </div>
                      <ul className="mt-1 space-y-1 text-[12px] font-medium leading-[18px] text-[var(--cf-text-primary)]">
                        {detailTask.acceptanceCriteria.map((c, i) => (
                          <li key={i}>{c}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* 4. 产物与证据列表 */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                      borderRadius: 'var(--cf-radius-container)',
                    }}
                    className="border p-3 text-[12px]"
                  >
                    <div className="mb-2 flex items-center justify-between">
                      <span className="font-bold text-[var(--cf-text-primary)]">
                        产物与证据 ({mobileEmptyDemo ? 0 : detailTask.artifacts.length})
                      </span>
                      <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                        横向可滑路径
                      </span>
                    </div>

                    {mobileEmptyDemo || detailTask.artifacts.length === 0 ? (
                      <div className="py-3 text-center text-[12px] text-[var(--cf-text-tertiary)]">
                        暂无产物证据
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {detailTask.artifacts.map((art) => (
                          <div
                            key={art.id}
                            className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)] p-2"
                          >
                            <div className="flex items-center justify-between gap-1">
                              <div className="flex min-w-0 items-center gap-1.5">
                                <span className="shrink-0 border border-[var(--cf-border-strong)] bg-white px-1 text-[10px] font-semibold">
                                  {art.type}
                                </span>
                                <span className="truncate font-mono-tabular text-[12px] font-bold">
                                  {art.name}
                                </span>
                              </div>
                              <span className="font-mono-tabular shrink-0 text-[10px] font-semibold text-[var(--cf-primary)]">
                                {art.version}
                              </span>
                            </div>
                            <div className="mt-1 overflow-x-auto font-mono-tabular text-[11px] whitespace-nowrap text-[var(--cf-primary)]">
                              {art.location}
                            </div>
                            <div className="mt-1 flex justify-between font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                              <span>{art.submitter}</span>
                              <span>{art.time}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* 5. 验收记录 */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                      borderRadius: 'var(--cf-radius-container)',
                    }}
                    className="border p-3 text-[12px]"
                  >
                    <div className="mb-2 font-bold text-[var(--cf-text-primary)]">
                      验收记录 ({mobileEmptyDemo ? 0 : detailTask.acceptanceRecords.length})
                    </div>

                    {mobileEmptyDemo || detailTask.acceptanceRecords.length === 0 ? (
                      <div className="py-3 text-center text-[12px] text-[var(--cf-text-tertiary)]">
                        暂无验收记录
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {detailTask.acceptanceRecords.map((rec) => (
                          <div
                            key={rec.id}
                            className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)] p-2.5"
                          >
                            <div className="flex items-center justify-between">
                              <span
                                style={{
                                  backgroundColor:
                                    rec.conclusion === '通过'
                                      ? 'var(--cf-success)'
                                      : 'var(--cf-warning)',
                                  color: 'white',
                                }}
                                className="px-1.5 py-0.5 text-[10px] font-bold"
                              >
                                结论：{rec.conclusion}
                              </span>
                              <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                                {rec.reviewer} · {rec.time}
                              </span>
                            </div>
                            <p className="mt-1.5 text-[12px] leading-[18px] text-[var(--cf-text-primary)]">
                              {rec.comment}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* 6. 底部固定操作区（当前状态可执行的主要动作 + 其余动作收进「更多」，触控目标 ≥ 44×44） */}
                <div
                  style={{
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderTop: '1px solid var(--cf-border-strong)',
                  }}
                  className="flex shrink-0 items-center gap-2 p-2.5"
                >
                  {isObserver ? (
                    <div className="flex min-h-[44px] w-full items-center justify-center border border-dashed border-[var(--cf-border-strong)] text-[12px] text-[var(--cf-text-tertiary)]">
                      当前身份只读（观察员）
                    </div>
                  ) : (
                    <>
                      <button
                        type="button"
                        onClick={() => setMoreSheetOpen(true)}
                        style={{
                          backgroundColor: 'var(--cf-surface-card)',
                          borderColor: 'var(--cf-border-strong)',
                          color: 'var(--cf-text-primary)',
                        }}
                        className="min-h-[44px] min-w-[76px] shrink-0 border px-3 text-[13px] font-semibold"
                      >
                        更多 ⋯
                      </button>

                      <button
                        type="button"
                        onClick={handlePrimaryActionClick}
                        style={{
                          backgroundColor: 'var(--cf-primary)',
                          color: 'var(--cf-surface-card)',
                        }}
                        className="min-h-[44px] flex-1 px-4 text-[13px] font-bold"
                      >
                        {primaryAction.label}
                      </button>
                    </>
                  )}
                </div>

                {/* 「更多」底部弹出动作面板 (Action Sheet) */}
                {moreSheetOpen && (
                  <div className="absolute inset-0 z-30 flex flex-col justify-end bg-black/45">
                    <div
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderTop: '2px solid var(--cf-primary)',
                      }}
                      className="p-3 space-y-1.5"
                    >
                      <div className="mb-1 flex items-center justify-between px-1 text-[12px] font-bold text-[var(--cf-text-secondary)]">
                        <span>更多任务操作 ({detailTask.id})</span>
                        <button
                          type="button"
                          onClick={() => setMoreSheetOpen(false)}
                          className="min-h-[44px] min-w-[44px] text-right font-mono-tabular text-[var(--cf-primary)]"
                        >
                          关闭 ✕
                        </button>
                      </div>

                      {[
                        {
                          label: '登记产物证据',
                          action: () => {
                            setMoreSheetOpen(false)
                            triggerToast('已打开产物登记')
                          },
                        },
                        {
                          label: '编辑任务定义 (版本号 +1)',
                          action: () => {
                            onUpdateTask({
                              ...detailTask,
                              definitionVersion: detailTask.definitionVersion + 1,
                            })
                            setMoreSheetOpen(false)
                            triggerToast(
                              `定义已保存，版本升至 v${detailTask.definitionVersion + 1}`
                            )
                          },
                        },
                        {
                          label: '标记为「已阻塞」',
                          danger: true,
                          action: () => {
                            onUpdateTask({
                              ...detailTask,
                              status: 'blocked',
                              blockerReason: '移动端登记阻塞：等待上游支持',
                            })
                            setMoreSheetOpen(false)
                            triggerToast('已标记为阻塞状态')
                          },
                        },
                      ].map((item) => (
                        <button
                          key={item.label}
                          type="button"
                          onClick={item.action}
                          style={{
                            backgroundColor: 'var(--cf-surface-secondary)',
                            borderColor: 'var(--cf-border-strong)',
                            color: item.danger
                              ? 'var(--cf-danger)'
                              : 'var(--cf-text-primary)',
                          }}
                          className="flex min-h-[44px] w-full items-center justify-between border px-3 text-[13px] font-semibold"
                        >
                          <span>{item.label}</span>
                          <span>→</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* 「去验收」底部签批抽屉 */}
                {acceptSheetOpen && (
                  <div className="absolute inset-0 z-30 flex flex-col justify-end bg-black/45">
                    <div
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderTop: '2px solid var(--cf-warning)',
                      }}
                      className="p-3.5 space-y-2.5 text-[12px]"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[14px] font-bold text-[var(--cf-text-primary)]">
                          签批验收结论 · {detailTask.id}
                        </span>
                        <button
                          type="button"
                          onClick={() => setAcceptSheetOpen(false)}
                          className="min-h-[44px] min-w-[44px] text-right font-mono-tabular"
                        >
                          关闭 ✕
                        </button>
                      </div>
                      <p className="text-[11px] text-[var(--cf-text-secondary)]">
                        已核对 {detailTask.artifacts.length} 份证据产物与{' '}
                        {detailTask.acceptanceCriteria.length} 条验收标准：
                      </p>
                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => {
                            onUpdateTask({
                              ...detailTask,
                              status: 'in_progress',
                              reworkRound: detailTask.reworkRound + 1,
                            })
                            setAcceptSheetOpen(false)
                            triggerToast('已退回返工 (R+1)')
                          }}
                          style={{
                            backgroundColor: 'var(--cf-danger-bg)',
                            borderColor: 'var(--cf-danger)',
                            color: 'var(--cf-danger)',
                          }}
                          className="min-h-[44px] border font-bold"
                        >
                          退回进行中
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            onUpdateTask({
                              ...detailTask,
                              status: 'done',
                            })
                            setAcceptSheetOpen(false)
                            triggerToast('验收通过！已写入事实层')
                          }}
                          style={{
                            backgroundColor: 'var(--cf-success)',
                            color: 'white',
                          }}
                          className="min-h-[44px] font-bold"
                        >
                          ✓ 验收通过
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
