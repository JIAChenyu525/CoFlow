import React, { useState } from 'react'
import {
  CfButton,
  RoleBadge,
  SingleAvatar,
  RoleType,
} from '../design-system/components'
import {
  ProjectSummaryItem,
  ProjectStage,
  INITIAL_CHARTER_HISTORY,
  CharterVersionRecord,
  INITIAL_MEMBER_ACCOUNTS,
  ProjectMemberAccount,
  ROLE_PERMISSION_DESCRIPTIONS,
} from '../data/mockProjects'

interface ProjectSettingsPageProps {
  project: ProjectSummaryItem
  currentRole: RoleType
  onUpdateProject: (updated: ProjectSummaryItem) => void
  onBackToHall: () => void
}

const DATA_RETENTION_POLICIES = [
  {
    code: 'POL-01',
    title: '事件流全量保留',
    badge: 'PERMANENT AUDIT',
    description:
      '项目立项、章程版本升级、任务状态机流转、讨论提炼决策及验收退回等全部结构化事件永久保留，确保协作轨迹完整可回溯。',
  },
  {
    code: 'POL-02',
    title: '详细 Agent 日志短保留',
    badge: '14-DAY TTL',
    description:
      '本地连接器上报的高频流式心跳、终端调试标准输出与中间态思考过程默认仅保留 14 天，超期自动清理以降低存储噪音。',
  },
  {
    code: 'POL-03',
    title: '关键决策与验收长期保留',
    badge: 'LONG-TERM LEDGER',
    description:
      '经发起人或负责人确认的决策、带 SHA-1 证据哈希的交付产物元数据，以及人工给出的验收结论随项目档案长期封存。',
  },
  {
    code: 'POL-04',
    title: '敏感本地路径不进入事件与归档',
    badge: 'PATH SANITIZED',
    description:
      '本地连接器在打包上报前自动剥离成员电脑操作系统的绝对路径与用户名（如 C:\\Users\\xxx），仅在事实层记录仓库内相对路径。',
  },
  {
    code: 'POL-05',
    title: '模型 API Key 平台不读取、不保存',
    badge: 'ZERO-KEY STORAGE',
    description:
      '成员本地 AI 工具使用的 OpenAI、Anthropic 或私有模型 API Key 严格驻留本地环境，CoFlow 云端与上下文快照零读取、零落盘。',
  },
  {
    code: 'POL-06',
    title: '云端与本地删除分开授权',
    badge: 'DUAL-AUTH DELETE',
    description:
      '在工作台归档或移除云端项目记录不会触发任何对成员本地磁盘源码或产物的删除指令；本地工作区清理由成员在终端独立授权。',
  },
]

export function ProjectSettingsPage({
  project,
  currentRole,
  onUpdateProject,
  onBackToHall,
}: ProjectSettingsPageProps) {
  // 仅发起人可修改成员角色；非发起人看到的是只读角色展示
  const isInitiator = currentRole === 'initiator'
  const isObserver = currentRole === 'observer'

  // 1. 项目信息状态
  const [editName, setEditName] = useState(project.name)
  const [editCode, setEditCode] = useState(project.code)
  const [selectedStage, setSelectedStage] = useState<ProjectStage>(project.stage)
  const [stageSavedToast, setStageSavedToast] = useState(false)

  // 2. 项目章程当前版本字段与版本历史
  const [charterVersion, setCharterVersion] = useState('v2.4.0')
  const [charterGoal, setCharterGoal] = useState(
    '交付挑战杯与企业实测双达标的多智能体企业知识库混合检索系统，Top-10 召回率 ≥ 93.0%。'
  )
  const [charterScope, setCharterScope] = useState(
    '混合检索引擎源码、2,400 条评测基准集 (v1.4)、企业资质核验沙箱接口、竞赛答辩白皮书与演示台。'
  )
  const [charterNonGoals, setCharterNonGoals] = useState(
    '本期不自研底层基座大模型，不介入客户旧版 ERP 前端改造，不支持移动端原生 App。'
  )
  const [charterConstraints, setCharterConstraints] = useState(
    '单次检索 P99 延迟 ≤ 180ms；单任务上下文包 ≤ 32k tok；严禁明文上传客户未脱敏数据。'
  )
  const [charterAcceptance, setCharterAcceptance] = useState(
    '仅凭「可复现实验快照 + 评审人人工签批结论」入库，讨论区口头确认一律不计入事实。'
  )

  const [isRevisingCharter, setIsRevisingCharter] = useState(false)
  const [changeNoteInput, setChangeNoteInput] = useState('')
  const [changeNoteError, setChangeNoteError] = useState(false)
  const [charterHistory, setCharterHistory] = useState<CharterVersionRecord[]>(
    INITIAL_CHARTER_HISTORY
  )

  // 3. 成员与角色列表
  const [members, setMembers] = useState<ProjectMemberAccount[]>(
    INITIAL_MEMBER_ACCOUNTS
  )

  // 应用阶段与项目基本信息更新
  const handleApplyProjectInfo = () => {
    if (isObserver) return
    onUpdateProject({
      ...project,
      name: editName.trim() || project.name,
      code: editCode.trim().toUpperCase() || project.code,
      stage: selectedStage,
    })
    setStageSavedToast(true)
    setTimeout(() => setStageSavedToast(false), 2000)
  }

  // 保存修订后的章程并生成新版本
  const handleSaveRevisedCharter = (e: React.FormEvent) => {
    e.preventDefault()
    if (!changeNoteInput.trim()) {
      setChangeNoteError(true)
      return
    }

    const minorNum = charterHistory.length
    const nextVer = `v2.${minorNum}.0`
    setCharterVersion(nextVer)

    const newRecord: CharterVersionRecord = {
      version: nextVer,
      changeNote: changeNoteInput.trim(),
      author: isInitiator ? '林知夏' : '陈默',
      time: '2025-05-14 17:35',
    }

    setCharterHistory((prev) => [newRecord, ...prev])
    setChangeNoteInput('')
    setChangeNoteError(false)
    setIsRevisingCharter(false)
  }

  // 发起人修改成员角色
  const handleRoleChange = (memberId: string, nextRole: RoleType) => {
    if (!isInitiator) return
    setMembers((prev) =>
      prev.map((m) => (m.id === memberId && !m.isSelf ? { ...m, role: nextRole } : m))
    )
  }

  return (
    <div className="flex h-full w-full flex-col overflow-y-auto select-text">
      <div className="mx-auto w-full max-w-[1320px] space-y-5 px-6 py-5">
        {/* 页头 */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--cf-border-strong)] pb-3">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onBackToHall}
              className="text-[12px] font-semibold text-[var(--cf-primary)] hover:underline"
            >
              ← 返回项目大厅
            </button>
            <span className="text-[var(--cf-border-strong)]">|</span>
            <span
              style={{
                backgroundColor: 'var(--cf-primary)',
                color: 'var(--cf-surface-card)',
              }}
              className="px-2 py-0.5 font-mono-tabular text-[12px] font-bold"
            >
              {project.code}
            </span>
            <h1 className="text-[18px] font-bold text-[var(--cf-text-primary)]">
              项目设置 · {project.name}
            </h1>
          </div>

          <div className="flex items-center gap-2 text-[12px]">
            <span className="text-[var(--cf-text-tertiary)]">当前查看身份：</span>
            <RoleBadge role={currentRole} />
            {!isInitiator && (
              <span
                style={{
                  backgroundColor: 'var(--cf-warning-bg)',
                  borderColor: 'var(--cf-warning)',
                  color: 'var(--cf-warning)',
                }}
                className="border px-2 py-0.5 text-[11px] font-semibold"
              >
                非发起人视角：成员角色表处于只读展示态（可在顶栏切换为「发起人」修改角色）
              </span>
            )}
          </div>
        </div>

        {/* ===================================================================
            模块一：项目信息（名称、代号、当前阶段[下拉 + 应用按钮]）
           =================================================================== */}
        <section
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="border"
        >
          <div
            style={{
              backgroundColor: 'var(--cf-surface-secondary)',
              borderBottom: '1px solid var(--cf-border-strong)',
            }}
            className="flex items-center justify-between px-4 py-2"
          >
            <h2 className="text-[14px] font-bold text-[var(--cf-text-primary)]">
              一、项目信息（名称 · 代号 · 当前阶段）
            </h2>
            {stageSavedToast && (
              <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-success)]">
                ✓ 项目信息与阶段已应用生效
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 gap-4 p-4 md:grid-cols-12 items-end text-[12px]">
            <div className="md:col-span-5">
              <label className="mb-1 block font-semibold text-[var(--cf-text-secondary)]">
                项目名称
              </label>
              <input
                type="text"
                disabled={isObserver}
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="h-[32px] w-full border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] px-2.5 text-[13px] font-medium"
              />
            </div>

            <div className="md:col-span-2">
              <label className="mb-1 block font-semibold text-[var(--cf-text-secondary)]">
                项目代号
              </label>
              <input
                type="text"
                maxLength={6}
                disabled={isObserver}
                value={editCode}
                onChange={(e) => setEditCode(e.target.value.toUpperCase())}
                className="font-mono-tabular h-[32px] w-full border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] px-2.5 text-[13px] font-bold uppercase"
              />
            </div>

            <div className="md:col-span-5">
              <label className="mb-1 block font-semibold text-[var(--cf-text-secondary)]">
                当前阶段（定义 / 开发 / 联调 / 验收 / 归档）
              </label>
              {isObserver ? (
                <div className="flex h-[32px] items-center border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)] px-2.5 text-[12px] font-semibold text-[var(--cf-text-secondary)]">
                  阶段 · {selectedStage}（当前身份只读，操作按钮已隐藏）
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <select
                    value={selectedStage}
                    onChange={(e) => setSelectedStage(e.target.value as ProjectStage)}
                    className="h-[32px] flex-1 border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] px-2.5 text-[13px] font-semibold text-[var(--cf-primary)]"
                  >
                    <option value="定义">定义 (Definition)</option>
                    <option value="开发">开发 (Development)</option>
                    <option value="联调">联调 (Integration)</option>
                    <option value="验收">验收 (Acceptance)</option>
                    <option value="归档">归档 (Archived)</option>
                  </select>
                  <CfButton
                    variant="primary"
                    size="default"
                    onClick={handleApplyProjectInfo}
                  >
                    应用
                  </CfButton>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* ===================================================================
            模块二：项目章程（当前版本全部字段 + 版本历史 + 「修订章程」入口）
           =================================================================== */}
        <section
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="border"
        >
          <div
            style={{
              backgroundColor: 'var(--cf-surface-secondary)',
              borderBottom: '1px solid var(--cf-border-strong)',
            }}
            className="flex flex-wrap items-center justify-between gap-2 px-4 py-2"
          >
            <div className="flex items-center gap-2">
              <h2 className="text-[14px] font-bold text-[var(--cf-text-primary)]">
                二、项目章程（当前版本全部字段 & 版本历史）
              </h2>
              <span
                style={{
                  backgroundColor: 'var(--cf-primary)',
                  color: 'var(--cf-surface-card)',
                }}
                className="px-2 py-0.5 font-mono-tabular text-[11px] font-semibold"
              >
                当前生效：{charterVersion}
              </span>
            </div>

            {!isObserver && (
              <CfButton
                variant={isRevisingCharter ? 'ghost' : 'primary'}
                size="sm"
                onClick={() => {
                  setIsRevisingCharter((v) => !v)
                  setChangeNoteError(false)
                }}
              >
                {isRevisingCharter ? '收起修订表单' : '修订章程'}
              </CfButton>
            )}
          </div>

          <div className="grid grid-cols-1 gap-4 p-4 lg:grid-cols-12">
            {/* 左侧 7 列：当前版本的全部字段 或 展开的「修订章程」完整表单 */}
            <div className="lg:col-span-7 space-y-3">
              {isRevisingCharter ? (
                <form
                  onSubmit={handleSaveRevisedCharter}
                  style={{
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderColor: 'var(--cf-primary)',
                  }}
                  className="space-y-3 border-2 p-3.5 text-[12px]"
                >
                  <div className="flex items-center justify-between border-b border-[var(--cf-border-strong)] pb-1.5">
                    <span className="font-bold text-[var(--cf-primary)]">
                      修订项目章程（保存后将生成新版本 v2.{charterHistory.length}.0）
                    </span>
                    <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                      L0 STABLE LAYER REVISION
                    </span>
                  </div>

                  <div>
                    <label className="mb-0.5 block font-semibold">1. 项目目标</label>
                    <textarea
                      rows={2}
                      value={charterGoal}
                      onChange={(e) => setCharterGoal(e.target.value)}
                      className="w-full border border-[var(--cf-border-strong)] bg-white p-2 text-[12px]"
                    />
                  </div>

                  <div>
                    <label className="mb-0.5 block font-semibold">2. 交付范围</label>
                    <textarea
                      rows={2}
                      value={charterScope}
                      onChange={(e) => setCharterScope(e.target.value)}
                      className="w-full border border-[var(--cf-border-strong)] bg-white p-2 text-[12px]"
                    />
                  </div>

                  <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                    <div>
                      <label className="mb-0.5 block font-semibold">3. 非目标</label>
                      <textarea
                        rows={2}
                        value={charterNonGoals}
                        onChange={(e) => setCharterNonGoals(e.target.value)}
                        className="w-full border border-[var(--cf-border-strong)] bg-white p-2 text-[12px]"
                      />
                    </div>
                    <div>
                      <label className="mb-0.5 block font-semibold text-[var(--cf-danger)]">
                        4. 硬性约束
                      </label>
                      <textarea
                        rows={2}
                        value={charterConstraints}
                        onChange={(e) => setCharterConstraints(e.target.value)}
                        className="w-full border border-[var(--cf-border-strong)] bg-white p-2 text-[12px]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="mb-0.5 block font-semibold text-[var(--cf-primary)]">
                      5. 验收口径
                    </label>
                    <textarea
                      rows={2}
                      value={charterAcceptance}
                      onChange={(e) => setCharterAcceptance(e.target.value)}
                      className="w-full border border-[var(--cf-primary)] bg-white p-2 text-[12px]"
                    />
                  </div>

                  {/* 必填的"本次变更说明" */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-warning-bg)',
                      borderColor: changeNoteError
                        ? 'var(--cf-danger)'
                        : 'var(--cf-warning)',
                    }}
                    className="border p-2.5"
                  >
                    <label className="mb-1 block font-bold text-[var(--cf-warning)]">
                      本次变更说明（必填 · 将记录至版本历史并广播系统事件）{' '}
                      <span className="text-[var(--cf-danger)]">*</span>
                    </label>
                    <input
                      type="text"
                      value={changeNoteInput}
                      onChange={(e) => {
                        setChangeNoteInput(e.target.value)
                        setChangeNoteError(false)
                      }}
                      placeholder="例如：根据客户网关安全审计要求，补充双向 TLS 握手指纹校验约束..."
                      className="h-[30px] w-full border border-[var(--cf-border-strong)] bg-white px-2.5 text-[12px]"
                    />
                    {changeNoteError && (
                      <span className="mt-1 block text-[11px] font-semibold text-[var(--cf-danger)]">
                        必须填写「本次变更说明」才能发布新版本章程。
                      </span>
                    )}
                  </div>

                  <div className="flex justify-end gap-2">
                    <CfButton
                      variant="secondary"
                      size="sm"
                      onClick={() => setIsRevisingCharter(false)}
                    >
                      取消
                    </CfButton>
                    <button
                      type="submit"
                      style={{
                        backgroundColor: 'var(--cf-primary)',
                        color: 'var(--cf-surface-card)',
                      }}
                      className="h-[28px] px-3 text-[12px] font-semibold"
                    >
                      保存并发布新版本 (v2.{charterHistory.length}.0)
                    </button>
                  </div>
                </form>
              ) : (
                <div className="divide-y divide-[var(--cf-border-subtle)] border border-[var(--cf-border-strong)] text-[12px]">
                  {[
                    { label: '§1 项目目标', val: charterGoal },
                    { label: '§2 交付范围', val: charterScope },
                    { label: '§3 非目标', val: charterNonGoals },
                    { label: '§4 硬性约束', val: charterConstraints },
                    { label: '§5 验收口径', val: charterAcceptance },
                  ].map((row) => (
                    <div key={row.label} className="grid grid-cols-12 px-3 py-2.5">
                      <div className="col-span-3 font-mono-tabular font-semibold text-[var(--cf-primary)]">
                        {row.label}
                      </div>
                      <div className="col-span-9 text-[13px] leading-[19px] text-[var(--cf-text-primary)]">
                        {row.val}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 右侧 5 列：版本历史（版本号、变更说明、时间） */}
            <div className="lg:col-span-5">
              <div className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)]">
                <div className="flex items-center justify-between border-b border-[var(--cf-border-strong)] px-3 py-2 text-[12px]">
                  <span className="font-bold text-[var(--cf-text-primary)]">
                    章程版本历史 ({charterHistory.length})
                  </span>
                  <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                    VERSION LEDGER
                  </span>
                </div>
                <div className="max-h-[280px] divide-y divide-[var(--cf-border-subtle)] overflow-y-auto bg-[var(--cf-surface-card)]">
                  {charterHistory.map((ver, idx) => (
                    <div key={ver.version} className="px-3 py-2 text-[12px]">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <span
                            style={{
                              backgroundColor:
                                idx === 0
                                  ? 'var(--cf-primary)'
                                  : 'var(--cf-surface-secondary)',
                              color:
                                idx === 0
                                  ? 'var(--cf-surface-card)'
                                  : 'var(--cf-text-primary)',
                              borderColor: 'var(--cf-border-strong)',
                            }}
                            className="border px-1.5 py-0.5 font-mono-tabular text-[10px] font-bold"
                          >
                            {ver.version}
                          </span>
                          <span className="text-[11px] font-medium text-[var(--cf-text-secondary)]">
                            修订人：{ver.author}
                          </span>
                        </div>
                        <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                          {ver.time}
                        </span>
                      </div>
                      <p className="mt-1 text-[12px] leading-[17px] text-[var(--cf-text-primary)]">
                        {ver.changeNote}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ===================================================================
            模块三：成员与角色（每行头像、姓名、账号、角色说明、角色下拉[仅发起人可改；自己的角色不可改]）
            非发起人看到的是只读的角色展示
           =================================================================== */}
        <section
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="border"
        >
          <div
            style={{
              backgroundColor: 'var(--cf-surface-secondary)',
              borderBottom: '1px solid var(--cf-border-strong)',
            }}
            className="flex flex-wrap items-center justify-between gap-2 px-4 py-2"
          >
            <h2 className="text-[14px] font-bold text-[var(--cf-text-primary)]">
              三、成员与角色（仅发起人可修改他人角色；自己的角色不可改）
            </h2>
            <span className="font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
              {isInitiator
                ? '当前为「发起人」视角：可下拉调整其他成员角色'
                : '当前为「非发起人」视角：角色列已切换为只读展示'}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-[12px]">
              <thead>
                <tr
                  style={{
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderBottom: '1px solid var(--cf-border-strong)',
                  }}
                  className="text-[11px] font-semibold text-[var(--cf-text-secondary)]"
                >
                  <th className="px-4 py-2">成员 (头像 & 姓名)</th>
                  <th className="px-4 py-2">账号</th>
                  <th className="px-4 py-2">该角色对应的事实层权限说明</th>
                  <th className="px-4 py-2 text-right">
                    角色配置 ({isInitiator ? '可编辑' : '只读展示'})
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--cf-border-subtle)]">
                {members.map((m) => (
                  <tr key={m.id} className="hover:bg-[var(--cf-surface-secondary)]/50">
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <SingleAvatar
                          item={{
                            id: m.id,
                            name: m.name,
                            short: m.short,
                            kind: 'human',
                          }}
                          size={24}
                        />
                        <span className="font-semibold text-[var(--cf-text-primary)]">
                          {m.name}
                        </span>
                        {m.isSelf && (
                          <span className="border border-[var(--cf-primary-border)] bg-[var(--cf-primary-tint)] px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold text-[var(--cf-primary)]">
                            当前用户 (本人)
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-2.5 font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                      {m.account}
                    </td>
                    <td className="px-4 py-2.5 text-[12px] text-[var(--cf-text-secondary)]">
                      {ROLE_PERMISSION_DESCRIPTIONS[m.role]}
                    </td>
                    <td className="px-4 py-2.5 text-right">
                      {!isInitiator ? (
                        /* 非发起人视角：只读角色展示 */
                        <div className="inline-flex items-center gap-1.5">
                          <RoleBadge role={m.role} />
                        </div>
                      ) : m.isSelf ? (
                        /* 发起人自己的角色不可改 */
                        <div className="inline-flex items-center gap-2">
                          <RoleBadge role={m.role} />
                          <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                            [本人不可改]
                          </span>
                        </div>
                      ) : (
                        /* 发起人可下拉修改他人角色 */
                        <select
                          value={m.role}
                          onChange={(e) =>
                            handleRoleChange(m.id, e.target.value as RoleType)
                          }
                          className="h-[26px] border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] px-2 text-[12px] font-semibold text-[var(--cf-primary)]"
                        >
                          <option value="owner">负责人</option>
                          <option value="reviewer">评审</option>
                          <option value="member">成员</option>
                          <option value="observer">观察员</option>
                        </select>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* ===================================================================
            模块四：数据与保留策略（六条说明卡片）
           =================================================================== */}
        <section
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="border"
        >
          <div
            style={{
              backgroundColor: 'var(--cf-surface-secondary)',
              borderBottom: '1px solid var(--cf-border-strong)',
            }}
            className="flex items-center justify-between px-4 py-2"
          >
            <h2 className="text-[14px] font-bold text-[var(--cf-text-primary)]">
              四、数据与保留策略（Data & Retention Policies · 6 项法定原则）
            </h2>
            <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
              GOVERNANCE & PRIVACY BOUNDARIES
            </span>
          </div>

          <div className="grid grid-cols-1 gap-3 p-4 sm:grid-cols-2 lg:grid-cols-3">
            {DATA_RETENTION_POLICIES.map((pol) => (
              <div
                key={pol.code}
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderColor: 'var(--cf-border-strong)',
                  borderLeft: '3px solid var(--cf-primary)',
                }}
                className="flex flex-col justify-between border p-3.5"
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                      {pol.code}
                    </span>
                    <span
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: 'var(--cf-border-strong)',
                      }}
                      className="border px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold text-[var(--cf-text-secondary)]"
                    >
                      {pol.badge}
                    </span>
                  </div>
                  <h3 className="mt-1.5 text-[13px] font-bold text-[var(--cf-text-primary)]">
                    {pol.title}
                  </h3>
                  <p className="mt-1 text-[12px] leading-[18px] text-[var(--cf-text-secondary)]">
                    {pol.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
