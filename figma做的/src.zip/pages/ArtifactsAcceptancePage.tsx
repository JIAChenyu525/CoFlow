import { useState } from 'react'
import {
  TaskStatusBadge,
  PriorityBadge,
  CfButton,
  RoleType,
} from '../design-system/components'
import { CoFlowTask } from '../data/mockTasks'

interface ArtifactsAcceptancePageProps {
  tasks: CoFlowTask[]
  currentRole: RoleType
  onGoToTaskAcceptance: (taskId: string) => void
}

interface MasterArtifactRow {
  id: string
  type: '评测报告' | '代码补丁' | '数据集快照' | '联调日志' | '设计文档'
  name: string
  location: string
  version: string
  sourceTaskId: string
  sourceTaskTitle: string
  submitter: string
  time: string
}

const EXTRA_ARTIFACTS: MasterArtifactRow[] = [
  {
    id: 'ART-M-01',
    type: '评测报告',
    name: 'recall_bench_v1.4.csv',
    location: 'artifacts/eval/recall_bench_v1.4.csv (#7b91e0)',
    version: 'v1.4.2-rc',
    sourceTaskId: 'TSK-108',
    sourceTaskTitle: '向量检索模块召回率评测与章程指标对齐',
    submitter: 'cursor-win-02 (陈默)',
    time: '2025-05-14 11:26',
  },
  {
    id: 'ART-M-02',
    type: '代码补丁',
    name: 'clean_multimodal.py',
    location: 'commit:4e82a19 (scripts/clean_multimodal.py)',
    version: 'v0.9.1',
    sourceTaskId: 'TSK-112',
    sourceTaskTitle: '多模态竞赛数据集清洗脚本与 OCR 损坏样本剔除',
    submitter: 'claude-code-01 (许嘉树)',
    time: '2025-05-14 15:40',
  },
  {
    id: 'ART-M-03',
    type: '代码补丁',
    name: 'vector_eval_runner.py',
    location: 'commit:8c31f04 (src/retrieval/vector_eval.py)',
    version: 'v1.4.0',
    sourceTaskId: 'TSK-108',
    sourceTaskTitle: '向量检索模块召回率评测与章程指标对齐',
    submitter: '陈默',
    time: '2025-05-12 17:45',
  },
  {
    id: 'ART-M-04',
    type: '数据集快照',
    name: 'ground_truth_2400.jsonl',
    location: 'data/ground_truth_2400.jsonl (#9a4c12)',
    version: 'v1.0.0',
    sourceTaskId: 'TSK-105',
    sourceTaskTitle: '2,400 条脱敏工业问答评测集构建与哈希封存',
    submitter: '周舟',
    time: '2025-05-11 17:10',
  },
  {
    id: 'ART-M-05',
    type: '设计文档',
    name: 'CHR-v2.4-signed.md',
    location: 'docs/charter/CHR-v2.4.md (#1a90f2)',
    version: 'v2.4.0',
    sourceTaskId: 'TSK-104',
    sourceTaskTitle: '项目总章程 v2.4 检索精度基线与安全边界条款锁定',
    submitter: '林知夏',
    time: '2025-05-10 16:30',
  },
  {
    id: 'ART-M-06',
    type: '联调日志',
    name: 'bm25_sparse_index_build.log',
    location: 'artifacts/logs/bm25_build_20250509.log (#3d01e8)',
    version: 'v1.1.0',
    sourceTaskId: 'TSK-105',
    sourceTaskTitle: '2,400 条脱敏工业问答评测集构建与哈希封存',
    submitter: 'cursor-win-02 (陈默)',
    time: '2025-05-09 20:18',
  },
]

const SECOND_PENDING_TASK = {
  id: 'TSK-118',
  title: '重排器 Cross-Encoder Top-30 截断窗口延迟压测与显存审计',
  priority: 'P1' as const,
  reworkRound: 0,
  assigneeName: '陈默',
  waitDays: 2,
  acceptanceCriteria: [
    '1. 16 并发下 P99 响应时间 ≤ 150ms（实测 142ms）',
    '2. 峰值显存占用 ≤ 6.5GB，无 OOM 抖动',
    '3. 提交压测原始火焰图与吞吐量 CSV',
  ],
  artifacts: [
    {
      id: 'ART-118-01',
      type: '评测报告' as const,
      name: 'rerank_top30_latency_16c.csv',
      location: 'artifacts/eval/rerank_top30_latency.csv (#c902a1)',
      version: 'v1.0.2',
    },
    {
      id: 'ART-118-02',
      type: '联调日志' as const,
      name: 'gpu_mem_profile_4090.json',
      location: 'artifacts/logs/gpu_mem_profile.json (#51b8e2)',
      version: 'v1.0.0',
    },
  ],
}

export function ArtifactsAcceptancePage({
  tasks,
  onGoToTaskAcceptance,
}: ArtifactsAcceptancePageProps) {
  // 三种空状态独立开关：没有待验收 / 没有已完成 / 没有产物
  const [emptyPending, setEmptyPending] = useState(false)
  const [emptyCompleted, setEmptyCompleted] = useState(false)
  const [emptyArtifacts, setEmptyArtifacts] = useState(false)
  const [typeFilter, setTypeFilter] = useState<string>('all')

  // 待验收任务列表（结合状态中的 pending_accept 任务 + 补充演示卡，确保列表可扫读性）
  const realPendingTasks = tasks.filter((t) => t.status === 'pending_accept')
  const pendingCards = emptyPending
    ? []
    : [
        ...realPendingTasks.map((t) => ({
          id: t.id,
          title: t.title,
          priority: t.priority,
          reworkRound: t.reworkRound,
          assigneeName: t.assigneeName || '陈默',
          waitDays: 6,
          acceptanceCriteria: t.acceptanceCriteria,
          artifacts: t.artifacts.map((a) => ({
            id: a.id,
            type: a.type,
            name: a.name,
            location: a.location,
            version: a.version,
          })),
        })),
        SECOND_PENDING_TASK,
      ]

  // 已完成任务列表（任务名、产物数、验收次数、最后验收时间）
  const completedTasks = emptyCompleted
    ? []
    : [
        {
          id: 'TSK-104',
          title: '项目总章程 v2.4 检索精度基线与安全边界条款锁定',
          artifactCount: 2,
          acceptanceCount: 1,
          lastAcceptedAt: '2025-05-10 17:55',
          reviewer: '陈默',
        },
        {
          id: 'TSK-105',
          title: '2,400 条脱敏工业问答评测集构建与哈希封存',
          artifactCount: 3,
          acceptanceCount: 2,
          lastAcceptedAt: '2025-05-11 19:20',
          reviewer: '林知夏',
        },
        {
          id: 'TSK-101',
          title: 'BM25 稀疏检索分词词典与行业停用词表封存',
          artifactCount: 2,
          acceptanceCount: 1,
          lastAcceptedAt: '2025-05-09 16:08',
          reviewer: '周舟',
        },
      ]

  // 产物总清单
  const allArtifacts = emptyArtifacts
    ? []
    : typeFilter === 'all'
      ? EXTRA_ARTIFACTS
      : EXTRA_ARTIFACTS.filter((a) => a.type === typeFilter)

  const typeBadgeStyle = (type: MasterArtifactRow['type']) => {
    switch (type) {
      case '评测报告':
        return {
          backgroundColor: 'var(--cf-primary-tint)',
          color: 'var(--cf-primary)',
          borderColor: 'var(--cf-primary-border)',
        }
      case '代码补丁':
        return {
          backgroundColor: 'var(--cf-info-bg)',
          color: 'var(--cf-info)',
          borderColor: 'var(--cf-info-border)',
        }
      case '数据集快照':
        return {
          backgroundColor: 'var(--cf-warning-bg)',
          color: 'var(--cf-warning)',
          borderColor: 'var(--cf-warning-border)',
        }
      case '联调日志':
        return {
          backgroundColor: 'var(--cf-surface-secondary)',
          color: 'var(--cf-text-secondary)',
          borderColor: 'var(--cf-border-strong)',
        }
      case '设计文档':
        return {
          backgroundColor: 'var(--cf-success-bg)',
          color: 'var(--cf-success)',
          borderColor: 'var(--cf-success-border)',
        }
    }
  }

  return (
    <div className="flex h-full w-full flex-col overflow-y-auto select-text">
      {/* =====================================================================
          顶部说明栏 + 三种空状态独立切换器
         ===================================================================== */}
      <div
        style={{
          backgroundColor: 'var(--cf-surface-secondary)',
          borderBottom: '1px solid var(--cf-border-strong)',
        }}
        className="flex shrink-0 flex-wrap items-center justify-between gap-2 px-6 py-2"
      >
        <div className="flex items-center gap-2">
          <span
            style={{
              backgroundColor: 'var(--cf-warning)',
              color: 'var(--cf-surface-card)',
            }}
            className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-bold"
          >
            EVIDENCE & ACCEPTANCE
          </span>
          <h1 className="text-[14px] font-bold text-[var(--cf-text-primary)]">
            二、产物与验收（三栏对账核验 · 已完成验收台账 · 全项目产物清单）
          </h1>
        </div>

        {/* 三种空状态验证开关 */}
        <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
          <span className="text-[var(--cf-text-tertiary)]">空状态验证:</span>
          <button
            type="button"
            onClick={() => setEmptyPending((v) => !v)}
            style={{
              backgroundColor: emptyPending
                ? 'var(--cf-warning)'
                : 'var(--cf-surface-card)',
              color: emptyPending
                ? 'var(--cf-surface-card)'
                : 'var(--cf-text-secondary)',
              borderColor: 'var(--cf-border-strong)',
            }}
            className="h-[22px] border px-2 font-medium"
          >
            {emptyPending ? '✓ 已开启：没有待验收' : '模拟：没有待验收'}
          </button>

          <button
            type="button"
            onClick={() => setEmptyCompleted((v) => !v)}
            style={{
              backgroundColor: emptyCompleted
                ? 'var(--cf-primary)'
                : 'var(--cf-surface-card)',
              color: emptyCompleted
                ? 'var(--cf-surface-card)'
                : 'var(--cf-text-secondary)',
              borderColor: 'var(--cf-border-strong)',
            }}
            className="h-[22px] border px-2 font-medium"
          >
            {emptyCompleted ? '✓ 已开启：没有已完成' : '模拟：没有已完成'}
          </button>

          <button
            type="button"
            onClick={() => setEmptyArtifacts((v) => !v)}
            style={{
              backgroundColor: emptyArtifacts
                ? 'var(--cf-danger)'
                : 'var(--cf-surface-card)',
              color: emptyArtifacts
                ? 'var(--cf-surface-card)'
                : 'var(--cf-text-secondary)',
              borderColor: 'var(--cf-border-strong)',
            }}
            className="h-[22px] border px-2 font-medium"
          >
            {emptyArtifacts ? '✓ 已开启：没有产物' : '模拟：没有产物'}
          </button>
        </div>
      </div>

      <div className="mx-auto w-full max-w-[1380px] space-y-6 px-6 py-5">
        {/* ===================================================================
            第一区：待验收区（每个任务一张卡，内部三栏：标准 | 证据 | 结论）
           =================================================================== */}
        <section>
          <div className="mb-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h2 className="text-[15px] font-bold text-[var(--cf-text-primary)]">
                1. 待验收区（Pending Acceptance · 内部三栏横向对账：标准 / 证据 / 结论）
              </h2>
              <span
                style={{
                  backgroundColor: 'var(--cf-warning-bg)',
                  color: 'var(--cf-warning)',
                  borderColor: 'var(--cf-warning)',
                }}
                className="border px-1.5 py-0.5 font-mono-tabular text-[11px] font-bold"
              >
                {pendingCards.length} 项待核验
              </span>
            </div>
            <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
              左看标准 · 中查产物路径 · 右下结论
            </span>
          </div>

          {pendingCards.length === 0 ? (
            <div
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-border-strong)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="flex items-center justify-between border border-dashed px-5 py-6 text-[12px]"
            >
              <div>
                <div className="font-bold text-[var(--cf-text-primary)]">
                  当前没有待验收任务
                </div>
                <div className="mt-0.5 text-[var(--cf-text-tertiary)]">
                  所有提测任务均已完成人工核验。当成员或本地连接器提交产物至「待验收」时，将自动在此生成三栏核验单。
                </div>
              </div>
              <CfButton
                variant="secondary"
                size="xs"
                onClick={() => setEmptyPending(false)}
              >
                恢复待验收示例
              </CfButton>
            </div>
          ) : (
            <div className="space-y-3">
              {pendingCards.map((item) => (
                <div
                  key={item.id}
                  style={{
                    backgroundColor: 'var(--cf-surface-card)',
                    borderColor: 'var(--cf-warning)',
                    borderLeftWidth: '4px',
                    boxShadow: 'var(--cf-shadow-card)',
                    borderRadius: 'var(--cf-radius-container)',
                  }}
                  className="overflow-hidden border"
                >
                  {/* 卡片顶栏：任务编号 + 标题 + 优先级 + 返工轮次 + 提交人 */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-secondary)',
                      borderBottom: '1px solid var(--cf-border-strong)',
                    }}
                    className="flex flex-wrap items-center justify-between gap-2 px-4 py-2"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <TaskStatusBadge status="pending_accept" size="compact" />
                      <span className="font-mono-tabular text-[12px] font-bold text-[var(--cf-primary)]">
                        {item.id}
                      </span>
                      <PriorityBadge level={item.priority} showLabel={false} />
                      {item.reworkRound > 0 && (
                        <span className="border border-[var(--cf-warning)] bg-[var(--cf-warning-bg)] px-1.5 py-0.2 font-mono-tabular text-[10px] font-bold text-[var(--cf-warning)]">
                          R{item.reworkRound}
                        </span>
                      )}
                      <span className="text-[13px] font-bold text-[var(--cf-text-primary)]">
                        {item.title}
                      </span>
                    </div>
                    <span className="font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                      负责人：{item.assigneeName} · 已等待验收 {item.waitDays} 天
                    </span>
                  </div>

                  {/* 卡片内部三栏：标准 (4列) | 证据 (5列) | 结论 (3列) */}
                  <div className="grid grid-cols-1 divide-y divide-[var(--cf-border-subtle)] lg:grid-cols-12 lg:divide-x lg:divide-y-0 text-[12px]">
                    {/* 第一栏：标准（逐条验收条件，编号列出） */}
                    <div className="p-3.5 lg:col-span-5">
                      <div className="mb-1.5 flex items-center justify-between text-[11px] font-bold text-[var(--cf-primary)]">
                        <span>一、标准（逐条验收条件）</span>
                        <span className="font-mono-tabular">
                          共 {item.acceptanceCriteria.length} 条
                        </span>
                      </div>
                      <ol className="space-y-1.5 text-[12px] leading-[18px] text-[var(--cf-text-primary)]">
                        {item.acceptanceCriteria.map((crit, idx) => (
                          <li
                            key={idx}
                            className="flex items-start gap-1.5 border-l-2 border-[var(--cf-primary-border)] pl-2"
                          >
                            <span className="font-mono-tabular shrink-0 text-[11px] font-bold text-[var(--cf-primary)]">
                              [{idx + 1}]
                            </span>
                            <span>{crit.replace(/^\d+\.\s*/, '')}</span>
                          </li>
                        ))}
                      </ol>
                    </div>

                    {/* 第二栏：证据（产物列表：类型标签、名称、位置、版本） */}
                    <div className="p-3.5 lg:col-span-5 bg-[var(--cf-surface-secondary)]/35">
                      <div className="mb-1.5 flex items-center justify-between text-[11px] font-bold text-[var(--cf-text-primary)]">
                        <span>二、证据（已提交产物列表）</span>
                        <span className="font-mono-tabular text-[var(--cf-text-tertiary)]">
                          {item.artifacts.length} 份凭证
                        </span>
                      </div>
                      <div className="space-y-2">
                        {item.artifacts.map((art) => (
                          <div
                            key={art.id}
                            style={{
                              backgroundColor: 'var(--cf-surface-card)',
                              borderColor: 'var(--cf-border-subtle)',
                            }}
                            className="border p-2"
                          >
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-1.5 min-w-0">
                                <span
                                  style={typeBadgeStyle(art.type)}
                                  className="shrink-0 border px-1.5 py-0.5 text-[10px] font-semibold"
                                >
                                  {art.type}
                                </span>
                                <span className="truncate font-mono-tabular text-[12px] font-bold text-[var(--cf-text-primary)]">
                                  {art.name}
                                </span>
                              </div>
                              <span className="font-mono-tabular shrink-0 border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] px-1.5 py-0.2 text-[10px] font-semibold">
                                {art.version}
                              </span>
                            </div>
                            <div className="mt-1 truncate font-mono-tabular text-[11px] text-[var(--cf-primary)]">
                              位置：{art.location}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* 第三栏：结论（显示"尚未验收" + 「去验收」按钮） */}
                    <div className="flex flex-col items-center justify-center gap-2.5 p-3.5 text-center lg:col-span-2 bg-[var(--cf-warning-bg)]/40">
                      <div className="text-[11px] font-semibold text-[var(--cf-text-tertiary)]">
                        三、结论
                      </div>
                      <span
                        style={{
                          backgroundColor: 'var(--cf-warning-bg)',
                          borderColor: 'var(--cf-warning)',
                          color: 'var(--cf-warning)',
                        }}
                        className="border border-dashed px-2.5 py-1 font-mono-tabular text-[12px] font-bold"
                      >
                        尚未验收
                      </span>
                      <CfButton
                        variant="primary"
                        size="sm"
                        onClick={() => onGoToTaskAcceptance('TSK-108')}
                      >
                        去验收 →
                      </CfButton>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* ===================================================================
            第二区：已完成区（任务名、产物数、验收次数、最后验收时间）
           =================================================================== */}
        <section>
          <div className="mb-2.5 flex items-center justify-between">
            <h2 className="text-[15px] font-bold text-[var(--cf-text-primary)]">
              2. 已完成区（已锁定验收结论的任务台账）
            </h2>
            <span className="font-mono-tabular text-[11px] text-[var(--cf-success)]">
              共 {completedTasks.length} 项已完成验收
            </span>
          </div>

          {completedTasks.length === 0 ? (
            <div
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-border-strong)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="flex items-center justify-between border border-dashed px-5 py-5 text-[12px]"
            >
              <span className="text-[var(--cf-text-tertiary)]">
                当前没有已完成的验收任务记录。
              </span>
              <CfButton
                variant="secondary"
                size="xs"
                onClick={() => setEmptyCompleted(false)}
              >
                恢复已完成示例
              </CfButton>
            </div>
          ) : (
            <div
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-border-strong)',
                boxShadow: 'var(--cf-shadow-card)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="overflow-hidden border"
            >
              <div className="divide-y divide-[var(--cf-border-subtle)]">
                {completedTasks.map((ct) => (
                  <div
                    key={ct.id}
                    onClick={() => onGoToTaskAcceptance('TSK-104')}
                    className="flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 text-[12px] hover:bg-[var(--cf-surface-secondary)] cursor-pointer"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <TaskStatusBadge status="done" size="compact" />
                      <span className="font-mono-tabular font-bold text-[var(--cf-primary)]">
                        {ct.id}
                      </span>
                      <span className="truncate font-semibold text-[var(--cf-text-primary)]">
                        {ct.title}
                      </span>
                    </div>

                    <div className="flex items-center gap-4 font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                      <span>
                        产物数：<strong className="text-[var(--cf-text-primary)]">{ct.artifactCount}</strong>
                      </span>
                      <span>
                        验收次数：<strong className="text-[var(--cf-text-primary)]">{ct.acceptanceCount} 次</strong>
                      </span>
                      <span className="text-[var(--cf-text-tertiary)]">
                        最后验收时间：{ct.lastAcceptedAt}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>

        {/* ===================================================================
            第三区：产物清单（表格：类型、名称、位置[等宽]、版本、来源任务、提交人、时间）
           =================================================================== */}
        <section>
          <div className="mb-2.5 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <h2 className="text-[15px] font-bold text-[var(--cf-text-primary)]">
                3. 产物清单（Master Artifact Ledger）
              </h2>
              <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                共 {allArtifacts.length} 份已登记产物
              </span>
            </div>

            {/* 类型快速扫读筛选 */}
            <div className="flex items-center gap-1 text-[11px]">
              {['all', '评测报告', '代码补丁', '数据集快照', '设计文档', '联调日志'].map(
                (t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTypeFilter(t)}
                    style={{
                      backgroundColor:
                        typeFilter === t
                          ? 'var(--cf-primary)'
                          : 'var(--cf-surface-card)',
                      color:
                        typeFilter === t
                          ? 'var(--cf-surface-card)'
                          : 'var(--cf-text-secondary)',
                      borderColor: 'var(--cf-border-strong)',
                    }}
                    className="h-[22px] border px-2 font-medium"
                  >
                    {t === 'all' ? '全部类型' : t}
                  </button>
                )
              )}
            </div>
          </div>

          {allArtifacts.length === 0 ? (
            <div
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-border-strong)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="flex items-center justify-between border border-dashed px-5 py-6 text-[12px]"
            >
              <span className="text-[var(--cf-text-tertiary)]">
                当前项目没有任何已登记的产物记录。
              </span>
              <CfButton
                variant="secondary"
                size="xs"
                onClick={() => {
                  setEmptyArtifacts(false)
                  setTypeFilter('all')
                }}
              >
                恢复产物清单示例
              </CfButton>
            </div>
          ) : (
            <div
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-border-strong)',
                boxShadow: 'var(--cf-shadow-card)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="overflow-x-auto border"
            >
              <table className="w-full border-collapse text-left text-[12px]">
                <thead>
                  <tr
                    style={{
                      backgroundColor: 'var(--cf-surface-secondary)',
                      borderBottom: '1px solid var(--cf-border-strong)',
                    }}
                    className="text-[11px] font-semibold text-[var(--cf-text-secondary)]"
                  >
                    <th className="w-24 px-3 py-2">类型</th>
                    <th className="px-3 py-2">名称</th>
                    <th className="px-3 py-2">位置 (等宽 · 提交号 / 路径 / 哈希)</th>
                    <th className="w-24 px-3 py-2">版本</th>
                    <th className="px-3 py-2">来源任务</th>
                    <th className="w-36 px-3 py-2">提交人</th>
                    <th className="w-36 px-3 py-2 text-right">时间</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--cf-border-subtle)]">
                  {allArtifacts.map((row) => (
                    <tr
                      key={row.id}
                      className="transition-colors hover:bg-[var(--cf-surface-secondary)]"
                    >
                      <td className="px-3 py-2">
                        <span
                          style={typeBadgeStyle(row.type)}
                          className="inline-block border px-1.5 py-0.5 text-[10px] font-semibold"
                        >
                          {row.type}
                        </span>
                      </td>
                      <td className="px-3 py-2 font-mono-tabular font-bold text-[var(--cf-text-primary)]">
                        {row.name}
                      </td>
                      <td className="px-3 py-2 font-mono-tabular text-[11px] text-[var(--cf-primary)]">
                        {row.location}
                      </td>
                      <td className="px-3 py-2">
                        <span className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] px-1.5 py-0.5 font-mono-tabular text-[11px] font-semibold">
                          {row.version}
                        </span>
                      </td>
                      <td className="px-3 py-2">
                        <button
                          type="button"
                          onClick={() => onGoToTaskAcceptance(row.sourceTaskId)}
                          className="flex items-center gap-1.5 text-left hover:underline"
                        >
                          <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                            {row.sourceTaskId}
                          </span>
                          <span className="max-w-[180px] truncate text-[11px] text-[var(--cf-text-secondary)]">
                            {row.sourceTaskTitle}
                          </span>
                        </button>
                      </td>
                      <td className="px-3 py-2 text-[11px] text-[var(--cf-text-secondary)]">
                        {row.submitter}
                      </td>
                      <td className="px-3 py-2 text-right font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                        {row.time}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </div>
  )
}
