import React, { useState } from 'react'
import {
  TaskStatusBadge,
  PriorityBadge,
  CfButton,
  SingleAvatar,
  TaskStatus,
  PriorityLevel,
  RoleType,
} from '../design-system/components'
import { CoFlowTask } from '../data/mockTasks'

interface TaskBoardPageProps {
  tasks: CoFlowTask[]
  currentRole: RoleType
  onSelectTask: (taskId: string) => void
  onCreateTask: (newTask: CoFlowTask) => void
  defaultOpenCreateModal?: boolean
}

const MAIN_COLUMNS: {
  status: TaskStatus
  label: string
  emptyHint: string
}[] = [
  {
    status: 'clarify',
    label: '待澄清',
    emptyHint: '当前无待澄清任务。缺输入材料或缺验收标准的新建任务会自动停留在此列。',
  },
  {
    status: 'unclaimed',
    label: '待认领',
    emptyHint: '当前无待认领任务。已补齐输入与验收标准、但尚未指定负责人的任务会在此等待认领。',
  },
  {
    status: 'ready',
    label: '已就绪',
    emptyHint: '当前无已就绪任务。已指定负责人且前置条件齐备的任务会进入此列等待开工或派发 Agent。',
  },
  {
    status: 'in_progress',
    label: '进行中',
    emptyHint: '当前无进行中任务。成员开工或本地 Agent 领取租约后任务流转至此。',
  },
  {
    status: 'pending_accept',
    label: '待验收',
    emptyHint: '当前无待验收任务。已提交证据产物并申请人工核验的任务会在此等待评审结论。',
  },
  {
    status: 'done',
    label: '已完成',
    emptyHint: '当前无已完成任务。经评审签批通过的任务将锁定归档至此。',
  },
]

export function TaskBoardPage({
  tasks,
  currentRole,
  onSelectTask,
  onCreateTask,
  defaultOpenCreateModal = false,
}: TaskBoardPageProps) {
  const [boardPreset, setBoardPreset] = useState<'normal' | 'single_empty_col' | 'all_empty'>(
    'normal'
  )
  const [bypassFilter, setBypassFilter] = useState<'all' | 'blocked' | 'paused' | 'cancelled'>(
    'all'
  )
  const [showCreateModal, setShowCreateModal] = useState(defaultOpenCreateModal)

  // 新建任务表单 11 个字段状态
  const [formTitle, setFormTitle] = useState('')
  const [formAssignee, setFormAssignee] = useState('陈默')
  const [formPriority, setFormPriority] = useState<PriorityLevel>('P1')
  const [formWeight, setFormWeight] = useState(5)
  const [formMilestone, setFormMilestone] = useState('M2 · 混合检索与重排核心联调')
  const [formDueDate, setFormDueDate] = useState('2025-05-20')
  const [formDesc, setFormDesc] = useState('')
  const [formInputs, setFormInputs] = useState('data/ground_truth_2400.jsonl')
  const [formScope, setFormScope] = useState('src/retrieval/reranker_batch.py')
  const [formNonScope, setFormNonScope] = useState('不改动底层向量索引存储格式')
  const [formCriteria, setFormCriteria] = useState(
    '1. 批处理吞吐量 ≥ 120 QPS\n2. 附带可复现基准测试 CSV 报告'
  )

  const isObserver = currentRole === 'observer'

  // 根据状态演示预设过滤任务
  const effectiveTasks =
    boardPreset === 'all_empty'
      ? []
      : boardPreset === 'single_empty_col'
        ? tasks.filter((t) => t.status !== 'unclaimed')
        : tasks

  const bypassTasks = effectiveTasks.filter(
    (t) =>
      (t.status === 'blocked' || t.status === 'paused' || t.status === 'cancelled') &&
      (bypassFilter === 'all' || t.status === bypassFilter)
  )

  // 计算新建任务将落入的初始状态（实时规则驱动提示）
  const hasInputs = formInputs.trim().length > 0
  const hasCriteria = formCriteria.trim().length > 0
  const hasAssignee = formAssignee.trim().length > 0
  const predictedInitialStatus: TaskStatus =
    !hasInputs || !hasCriteria ? 'clarify' : !hasAssignee ? 'unclaimed' : 'ready'

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formTitle.trim()) return

    const newTask: CoFlowTask = {
      id: `TSK-${122 + tasks.length}`,
      title: formTitle.trim(),
      status: predictedInitialStatus,
      priority: formPriority,
      reworkRound: 0,
      dueDate: formDueDate,
      assigneeName: hasAssignee ? formAssignee : null,
      assigneeShort: hasAssignee ? formAssignee.slice(0, 1) : null,
      reviewerName: '周舟',
      milestone: formMilestone,
      weight: Number(formWeight) || 3,
      definitionVersion: 1,
      createdAt: '2025-05-14 17:00',
      updatedAt: '2025-05-14 17:00',
      projectName: '多智能体企业知识库混合检索系统',
      description: formDesc.trim() || '新建协作任务定义。',
      inputMaterials: hasInputs
        ? formInputs
            .split('\n')
            .map((s) => s.trim())
            .filter(Boolean)
        : [],
      workScope: formScope
        .split('\n')
        .map((s) => s.trim())
        .filter(Boolean),
      nonWorkScope: formNonScope
        .split('\n')
        .map((s) => s.trim())
        .filter(Boolean),
      acceptanceCriteria: hasCriteria
        ? formCriteria
            .split('\n')
            .map((s) => s.trim())
            .filter(Boolean)
        : [],
      artifacts: [],
      acceptanceRecords: [],
      dependencies: [],
      currentLease: null,
      allowedWritePaths: ['src/retrieval/**', 'artifacts/eval/**'],
      forbiddenPaths: ['.env*', 'certs/private/**'],
    }

    onCreateTask(newTask)
    setShowCreateModal(false)
    setFormTitle('')
    if (boardPreset === 'all_empty') setBoardPreset('normal')
  }

  return (
    <div className="flex h-full w-full flex-col overflow-hidden select-text">
      {/* =====================================================================
          顶部规则说明栏 + 状态预设 + 右上「＋ 新建任务」
         ===================================================================== */}
      <div
        style={{
          backgroundColor: 'var(--cf-surface-secondary)',
          borderBottom: '1px solid var(--cf-border-strong)',
        }}
        className="flex shrink-0 flex-wrap items-center justify-between gap-3 px-4 py-2"
      >
        <div className="flex flex-wrap items-center gap-2.5">
          <span
            style={{
              backgroundColor: 'var(--cf-primary)',
              color: 'var(--cf-surface-card)',
            }}
            className="px-1.5 py-0.5 font-mono-tabular text-[11px] font-semibold"
          >
            状态流转铁律
          </span>
          <p className="text-[13px] font-semibold text-[var(--cf-text-primary)]">
            状态由规则驱动：待澄清 → 待认领 → 已就绪 → 进行中 → 待验收 → 已完成，不能跳级。
          </p>
          <span className="hidden text-[11px] text-[var(--cf-text-tertiary)] xl:inline">
            （点击任意任务卡可进入「二、任务详情」执行状态机流转或派发 Agent）
          </span>
        </div>

        <div className="flex items-center gap-2.5">
          {/* 看板空状态验证切换器 */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
            }}
            className="flex items-center border p-0.5 text-[11px]"
          >
            <span className="px-1.5 text-[var(--cf-text-tertiary)]">看板状态演示:</span>
            {[
              { id: 'normal', label: '全量任务态' },
              { id: 'single_empty_col', label: '单列空状态(待认领为空)' },
              { id: 'all_empty', label: '全局空状态' },
            ].map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setBoardPreset(p.id as typeof boardPreset)}
                style={{
                  backgroundColor:
                    boardPreset === p.id ? 'var(--cf-primary)' : 'transparent',
                  color:
                    boardPreset === p.id
                      ? 'var(--cf-surface-card)'
                      : 'var(--cf-text-secondary)',
                }}
                className="h-[22px] px-2 font-medium transition-colors"
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* 右上「＋ 新建任务」（观察员只读下不显示） */}
          {!isObserver ? (
            <CfButton
              variant="primary"
              size="sm"
              onClick={() => setShowCreateModal(true)}
            >
              ＋ 新建任务
            </CfButton>
          ) : (
            <span
              style={{
                backgroundColor: 'var(--cf-surface-tertiary)',
                borderColor: 'var(--cf-border-strong)',
                color: 'var(--cf-text-tertiary)',
              }}
              className="border px-2 py-1 font-mono-tabular text-[11px]"
            >
              观察员只读 · 隐藏新建入口
            </span>
          )}
        </div>
      </div>

      {/* =====================================================================
          全局空状态 vs 看板主体（六列主状态 + 底部旁路状态专区）
         ===================================================================== */}
      {effectiveTasks.length === 0 ? (
        <div className="flex flex-1 items-center justify-center p-8">
          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="flex max-w-md flex-col items-center border border-dashed p-8 text-center"
          >
            <div
              style={{
                backgroundColor: 'var(--cf-surface-secondary)',
                borderColor: 'var(--cf-border-strong)',
              }}
              className="mb-3 flex h-11 w-11 items-center justify-center border font-mono-tabular text-[16px] font-bold text-[var(--cf-primary)]"
            >
              0
            </div>
            <h3 className="text-[15px] font-semibold text-[var(--cf-text-primary)]">
              当前项目暂无拆解任务
            </h3>
            <p className="mt-1.5 text-[12px] leading-[18px] text-[var(--cf-text-secondary)]">
              任务是最小的协作与授权单元。请依据项目章程拆解任务并明确输入材料与验收标准。
            </p>
            <div className="mt-4 flex items-center gap-2">
              {!isObserver && (
                <CfButton
                  variant="primary"
                  size="sm"
                  onClick={() => setShowCreateModal(true)}
                >
                  ＋ 新建首个任务
                </CfButton>
              )}
              <CfButton
                variant="secondary"
                size="sm"
                onClick={() => setBoardPreset('normal')}
              >
                恢复示例任务数据
              </CfButton>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex flex-1 flex-col overflow-hidden px-4 py-3 gap-3">
          {/* -----------------------------------------------------------------
              六列主状态看板（待澄清 → 待认领 → 已就绪 → 进行中 → 待验收 → 已完成）
             ----------------------------------------------------------------- */}
          <div className="grid flex-1 grid-cols-6 gap-2.5 overflow-hidden">
            {MAIN_COLUMNS.map((col, colIdx) => {
              const colTasks = effectiveTasks.filter((t) => t.status === col.status)
              const totalWeight = colTasks.reduce((sum, t) => sum + t.weight, 0)

              return (
                <div
                  key={col.status}
                  style={{
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderColor: 'var(--cf-border-strong)',
                    borderRadius: 'var(--cf-radius-container)',
                  }}
                  className="flex h-full flex-col overflow-hidden border"
                >
                  {/* 列头：状态名（20px 徽标）+ 任务数量 */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderBottom: '1px solid var(--cf-border-strong)',
                    }}
                    className="flex shrink-0 items-center justify-between px-2.5 py-2"
                  >
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono-tabular text-[10px] font-semibold text-[var(--cf-text-tertiary)]">
                        0{colIdx + 1}
                      </span>
                      <TaskStatusBadge status={col.status} size="compact" />
                    </div>
                    <span
                      style={{
                        backgroundColor: 'var(--cf-surface-secondary)',
                        borderColor: 'var(--cf-border-strong)',
                      }}
                      className="border px-1.5 py-0.5 font-mono-tabular text-[11px] font-semibold text-[var(--cf-text-primary)]"
                    >
                      {colTasks.length} 项
                    </span>
                  </div>

                  {/* 列内任务卡列表（某列没有任务时显示一句专属提示） */}
                  <div className="flex-1 space-y-2 overflow-y-auto p-2">
                    {colTasks.length === 0 ? (
                      <div
                        style={{
                          backgroundColor: 'var(--cf-surface-card)',
                          borderColor: 'var(--cf-border-strong)',
                        }}
                        className="flex h-36 flex-col items-center justify-center border border-dashed p-3 text-center"
                      >
                        <p className="text-[11px] leading-[16px] text-[var(--cf-text-tertiary)]">
                          {col.emptyHint}
                        </p>
                      </div>
                    ) : (
                      colTasks.map((task) => (
                        <div
                          key={task.id}
                          onClick={() => onSelectTask(task.id)}
                          style={{
                            backgroundColor: 'var(--cf-surface-card)',
                            borderColor: 'var(--cf-border-strong)',
                            boxShadow: 'var(--cf-shadow-card)',
                            borderRadius: 'var(--cf-radius-container)',
                          }}
                          className="group cursor-pointer border p-2.5 transition-all hover:-translate-y-0.5 hover:border-[var(--cf-primary)]"
                        >
                          {/* 第一行：任务 ID + 优先级(P0-P3) + 返工轮次标记(如 R1) + 截止日期 */}
                          <div className="flex flex-wrap items-center justify-between gap-1">
                            <div className="flex items-center gap-1">
                              <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                                {task.id}
                              </span>
                              <PriorityBadge level={task.priority} showLabel={false} />
                              {task.reworkRound > 0 && (
                                <span
                                  style={{
                                    backgroundColor: 'var(--cf-warning-bg)',
                                    color: 'var(--cf-warning)',
                                    borderColor: 'var(--cf-warning)',
                                  }}
                                  title={`第 ${task.reworkRound} 轮返工`}
                                  className="border px-1 font-mono-tabular text-[10px] font-bold"
                                >
                                  R{task.reworkRound}
                                </span>
                              )}
                            </div>
                            <span
                              style={{
                                color: task.isOverdue
                                  ? 'var(--cf-danger)'
                                  : 'var(--cf-text-tertiary)',
                              }}
                              className="font-mono-tabular text-[10px] font-medium"
                            >
                              截止 {task.dueDate.slice(5)}
                            </span>
                          </div>

                          {/* 第二行：任务标题（最多两行 line-clamp-2，13px） */}
                          <h4 className="mt-1.5 line-clamp-2 text-[13px] font-semibold leading-[19px] text-[var(--cf-text-primary)] group-hover:text-[var(--cf-primary)]">
                            {task.title}
                          </h4>

                          {/* 缺输入或缺验收标准的待澄清原因小字 */}
                          {task.status === 'clarify' && (
                            <div
                              style={{
                                backgroundColor: 'var(--cf-warning-bg)',
                                borderColor: 'var(--cf-warning-border)',
                                color: 'var(--cf-warning)',
                              }}
                              className="mt-1.5 border-l-2 px-1.5 py-0.5 text-[10px] font-medium"
                            >
                              {task.inputMaterials.length === 0
                                ? '待补齐：缺少输入材料'
                                : '待补齐：缺少量化验收标准'}
                            </div>
                          )}

                          {/* 第三行底部台账：负责人头像 + 产物数 + 依赖数 + 权重 */}
                          <div
                            style={{ borderColor: 'var(--cf-border-subtle)' }}
                            className="mt-2 flex items-center justify-between border-t pt-1.5"
                          >
                            <div className="flex items-center gap-1.5">
                              {task.assigneeName ? (
                                <>
                                  <SingleAvatar
                                    item={{
                                      id: task.id,
                                      name: task.assigneeName,
                                      short: task.assigneeShort || '员',
                                      kind: 'human',
                                    }}
                                    size={20}
                                  />
                                  <span className="text-[11px] font-medium text-[var(--cf-text-secondary)]">
                                    {task.assigneeName}
                                  </span>
                                </>
                              ) : (
                                <span
                                  style={{
                                    borderColor: 'var(--cf-border-strong)',
                                    color: 'var(--cf-text-tertiary)',
                                  }}
                                  className="border border-dashed px-1.5 py-0.5 text-[10px]"
                                >
                                  未指派
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-1.5 font-mono-tabular text-[10px] text-[var(--cf-text-secondary)]">
                              <span title="产物数">产物 {task.artifacts.length}</span>
                              <span className="text-[var(--cf-border-strong)]">|</span>
                              <span title="前置依赖数">依赖 {task.dependencies.length}</span>
                              <span
                                style={{
                                  backgroundColor: 'var(--cf-surface-secondary)',
                                  borderColor: 'var(--cf-border-strong)',
                                  color: 'var(--cf-primary)',
                                }}
                                className="border px-1 py-0.2 font-semibold"
                                title="任务工作量权重"
                              >
                                权重 {task.weight}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  {/* 列底：权重合计 */}
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderTop: '1px solid var(--cf-border-strong)',
                    }}
                    className="flex shrink-0 items-center justify-between px-2.5 py-1.5 text-[11px]"
                  >
                    <span className="text-[var(--cf-text-tertiary)]">本列权重合计</span>
                    <span className="font-mono-tabular font-bold text-[var(--cf-primary)]">
                      {totalWeight}
                    </span>
                  </div>
                </div>
              )
            })}
          </div>

          {/* -----------------------------------------------------------------
              一条「旁路状态」区域（已阻塞 / 已暂停 / 已取消 单独列出，阻塞任务显示原因）
             ----------------------------------------------------------------- */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="shrink-0 border"
          >
            <div
              style={{
                backgroundColor: 'var(--cf-surface-secondary)',
                borderBottom: '1px solid var(--cf-border-strong)',
              }}
              className="flex flex-wrap items-center justify-between gap-2 px-3 py-1.5"
            >
              <div className="flex items-center gap-2">
                <span
                  style={{
                    backgroundColor: 'var(--cf-danger)',
                    color: 'var(--cf-surface-card)',
                  }}
                  className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold"
                >
                  旁路状态专区
                </span>
                <span className="text-[12px] font-semibold text-[var(--cf-text-primary)]">
                  已阻塞 / 已暂停 / 已取消任务（脱离常规流转列，阻塞任务强制公示阻塞原因与所需支持）
                </span>
              </div>

              <div className="flex items-center gap-1 text-[11px]">
                {[
                  { id: 'all', label: '全部旁路 (4)' },
                  { id: 'blocked', label: '已阻塞 (2)' },
                  { id: 'paused', label: '已暂停 (1)' },
                  { id: 'cancelled', label: '已取消 (1)' },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setBypassFilter(tab.id as typeof bypassFilter)}
                    style={{
                      backgroundColor:
                        bypassFilter === tab.id
                          ? 'var(--cf-primary)'
                          : 'var(--cf-surface-card)',
                      color:
                        bypassFilter === tab.id
                          ? 'var(--cf-surface-card)'
                          : 'var(--cf-text-secondary)',
                      borderColor: 'var(--cf-border-strong)',
                    }}
                    className="h-[20px] border px-2 font-medium"
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            {/* 旁路任务紧凑横排网格 */}
            <div className="grid grid-cols-1 divide-y divide-[var(--cf-border-subtle)] md:grid-cols-2 md:divide-x md:divide-y-0">
              {bypassTasks.map((bt) => (
                <div
                  key={bt.id}
                  onClick={() => onSelectTask(bt.id)}
                  style={{
                    backgroundColor:
                      bt.status === 'blocked'
                        ? 'var(--cf-danger-bg)'
                        : 'var(--cf-surface-card)',
                  }}
                  className="flex cursor-pointer items-center justify-between gap-3 px-3 py-2 transition-colors hover:bg-[var(--cf-surface-secondary)]"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <TaskStatusBadge status={bt.status} size="compact" />
                      <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                        {bt.id}
                      </span>
                      <PriorityBadge level={bt.priority} showLabel={false} />
                      {bt.reworkRound > 0 && (
                        <span className="border border-[var(--cf-warning)] bg-[var(--cf-warning-bg)] px-1 font-mono-tabular text-[10px] font-bold text-[var(--cf-warning)]">
                          R{bt.reworkRound}
                        </span>
                      )}
                      <span className="truncate text-[12px] font-semibold text-[var(--cf-text-primary)]">
                        {bt.title}
                      </span>
                    </div>

                    {/* 阻塞原因 / 暂停或取消原因 */}
                    <div className="mt-1 text-[11px] leading-[16px]">
                      {bt.status === 'blocked' && (
                        <span className="font-semibold text-[var(--cf-danger)]">
                          阻塞原因：{bt.blockerReason}
                        </span>
                      )}
                      {bt.status === 'paused' && (
                        <span className="text-[var(--cf-text-secondary)]">
                          暂停原因：{bt.pauseReason}
                        </span>
                      )}
                      {bt.status === 'cancelled' && (
                        <span className="text-[var(--cf-text-tertiary)]">
                          取消依据：{bt.cancelReason}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex shrink-0 items-center gap-2 font-mono-tabular text-[10px] text-[var(--cf-text-secondary)]">
                    {bt.assigneeName && <span>{bt.assigneeName}</span>}
                    <span className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] px-1.5 py-0.5 font-semibold">
                      权重 {bt.weight}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          「＋ 新建任务」弹窗（包含全部 11 个指定字段与标题规则说明）
         ===================================================================== */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 p-4">
          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-float)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="flex max-h-[88vh] w-full max-w-3xl flex-col overflow-hidden border select-text"
          >
            {/* 弹窗头部：写明核心规则 */}
            <div
              style={{
                backgroundColor: 'var(--cf-primary)',
                color: 'var(--cf-surface-card)',
              }}
              className="px-5 py-3"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-[15px] font-semibold">＋ 新建任务</h3>
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="font-mono-tabular text-[12px] text-[#E3F1F2] hover:text-white"
                >
                  关闭 [ESC]
                </button>
              </div>
              <p className="mt-1 text-[12px] font-medium text-[#A7F3D0]">
                任务是最小的协作与授权单元。缺输入或缺验收标准的任务会停在待澄清。
              </p>
            </div>

            <form
              onSubmit={handleCreateSubmit}
              className="flex-1 space-y-3.5 overflow-y-auto p-5 text-[12px]"
            >
              {/* 1. 任务名称 */}
              <div>
                <label className="mb-1 block font-semibold text-[var(--cf-text-primary)]">
                  1. 任务名称 <span className="text-[var(--cf-danger)]">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="例如：跨页财务表格滑窗切分召回率对比实验"
                  style={{
                    backgroundColor: 'var(--cf-surface-card)',
                    borderColor: 'var(--cf-border-strong)',
                  }}
                  className="h-[32px] w-full border px-2.5 text-[13px] outline-none focus:border-[var(--cf-primary)]"
                />
              </div>

              {/* 2-6. 负责人、优先级、权重、里程碑、截止日期 */}
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
                <div>
                  <label className="mb-1 block font-semibold text-[var(--cf-text-secondary)]">
                    2. 负责人
                  </label>
                  <select
                    value={formAssignee}
                    onChange={(e) => setFormAssignee(e.target.value)}
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                    }}
                    className="h-[30px] w-full border px-2 text-[12px]"
                  >
                    <option value="">（暂不指派 → 待认领）</option>
                    <option value="陈默">陈默 (负责人)</option>
                    <option value="苏哲">苏哲 (成员)</option>
                    <option value="许嘉树">许嘉树 (成员)</option>
                    <option value="林知夏">林知夏 (发起人)</option>
                  </select>
                </div>

                <div>
                  <label className="mb-1 block font-semibold text-[var(--cf-text-secondary)]">
                    3. 优先级
                  </label>
                  <select
                    value={formPriority}
                    onChange={(e) => setFormPriority(e.target.value as PriorityLevel)}
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                    }}
                    className="font-mono-tabular h-[30px] w-full border px-2 text-[12px]"
                  >
                    <option value="P0">P0 · 紧急阻断</option>
                    <option value="P1">P1 · 高优推进</option>
                    <option value="P2">P2 · 常规排期</option>
                    <option value="P3">P3 · 低优暂缓</option>
                  </select>
                </div>

                <div>
                  <label className="mb-1 block font-semibold text-[var(--cf-text-secondary)]">
                    4. 权重 (工作量)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={formWeight}
                    onChange={(e) => setFormWeight(Number(e.target.value))}
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                    }}
                    className="font-mono-tabular h-[30px] w-full border px-2 text-[12px]"
                  />
                </div>

                <div>
                  <label className="mb-1 block font-semibold text-[var(--cf-text-secondary)]">
                    5. 里程碑
                  </label>
                  <select
                    value={formMilestone}
                    onChange={(e) => setFormMilestone(e.target.value)}
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                    }}
                    className="h-[30px] w-full border px-2 text-[12px]"
                  >
                    <option value="M1 · 章程基线与评测集构建">M1 · 章程基线</option>
                    <option value="M2 · 混合检索与重排核心联调">M2 · 检索联调</option>
                    <option value="M3 · 企业实测接入与资质合规">M3 · 企业实测</option>
                    <option value="M4 · 竞赛答辩材料与终审路演">M4 · 竞赛路演</option>
                  </select>
                </div>

                <div>
                  <label className="mb-1 block font-semibold text-[var(--cf-text-secondary)]">
                    6. 截止日期
                  </label>
                  <input
                    type="date"
                    value={formDueDate}
                    onChange={(e) => setFormDueDate(e.target.value)}
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                    }}
                    className="font-mono-tabular h-[30px] w-full border px-2 text-[12px]"
                  />
                </div>
              </div>

              {/* 7. 任务说明 */}
              <div>
                <label className="mb-1 block font-semibold text-[var(--cf-text-secondary)]">
                  7. 任务说明
                </label>
                <textarea
                  rows={2}
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  placeholder="简述任务背景、目标及与项目章程的对应关系..."
                  style={{
                    backgroundColor: 'var(--cf-surface-card)',
                    borderColor: 'var(--cf-border-strong)',
                  }}
                  className="w-full border p-2 text-[12px] outline-none focus:border-[var(--cf-primary)]"
                />
              </div>

              {/* 8-10. 输入材料、工作范围、非工作范围 */}
              <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                <div>
                  <label className="mb-1 flex items-center justify-between font-semibold text-[var(--cf-text-primary)]">
                    <span>8. 输入材料（每行一项）</span>
                    {!hasInputs && (
                      <span className="text-[10px] text-[var(--cf-warning)]">
                        为空将停在待澄清
                      </span>
                    )}
                  </label>
                  <textarea
                    rows={3}
                    value={formInputs}
                    onChange={(e) => setFormInputs(e.target.value)}
                    placeholder="若留空，任务创建后将自动停在「待澄清」"
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: hasInputs
                        ? 'var(--cf-border-strong)'
                        : 'var(--cf-warning)',
                    }}
                    className="font-mono-tabular w-full border p-2 text-[11px] outline-none"
                  />
                </div>

                <div>
                  <label className="mb-1 block font-semibold text-[var(--cf-text-secondary)]">
                    9. 工作范围（允许修改的模块/路径）
                  </label>
                  <textarea
                    rows={3}
                    value={formScope}
                    onChange={(e) => setFormScope(e.target.value)}
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                    }}
                    className="font-mono-tabular w-full border p-2 text-[11px] outline-none"
                  />
                </div>

                <div>
                  <label className="mb-1 block font-semibold text-[var(--cf-text-secondary)]">
                    10. 非工作范围（明确越界禁区）
                  </label>
                  <textarea
                    rows={3}
                    value={formNonScope}
                    onChange={(e) => setFormNonScope(e.target.value)}
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                    }}
                    className="w-full border p-2 text-[12px] outline-none"
                  />
                </div>
              </div>

              {/* 11. 验收标准 */}
              <div>
                <label className="mb-1 flex items-center justify-between font-semibold text-[var(--cf-primary)]">
                  <span>11. 验收标准（逐条可核验口径，每行一条）</span>
                  {!hasCriteria && (
                    <span className="text-[11px] text-[var(--cf-warning)]">
                      缺少验收标准 → 保存后将停在「待澄清」
                    </span>
                  )}
                </label>
                <textarea
                  rows={3}
                  value={formCriteria}
                  onChange={(e) => setFormCriteria(e.target.value)}
                  placeholder="若留空，任务创建后将自动停在「待澄清」..."
                  style={{
                    backgroundColor: 'var(--cf-primary-tint)',
                    borderColor: hasCriteria
                      ? 'var(--cf-primary)'
                      : 'var(--cf-warning)',
                  }}
                  className="w-full border p-2 text-[12px] font-medium outline-none"
                />
              </div>

              {/* 底部规则判定预览与提交按钮 */}
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderColor: 'var(--cf-border-strong)',
                }}
                className="flex flex-wrap items-center justify-between gap-2 border p-2.5"
              >
                <div className="flex items-center gap-2 text-[12px]">
                  <span className="text-[var(--cf-text-secondary)]">
                    根据当前填写完整度，新建后自动落入：
                  </span>
                  <TaskStatusBadge status={predictedInitialStatus} size="compact" />
                </div>

                <div className="flex items-center gap-2">
                  <CfButton
                    variant="secondary"
                    size="sm"
                    onClick={() => setShowCreateModal(false)}
                  >
                    取消
                  </CfButton>
                  <button
                    type="submit"
                    style={{
                      backgroundColor: 'var(--cf-primary)',
                      color: 'var(--cf-surface-card)',
                      borderRadius: 'var(--cf-radius-control)',
                    }}
                    className="h-[28px] px-3 text-[12px] font-semibold"
                  >
                    创建任务并写入台账
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
