import { useState } from 'react'
import {
  TASK_STATUS_LIST,
  TaskStatusBadge,
  PriorityBadge,
  CfButton,
  InlineBanner,
} from '../design-system/components'

export type CanonicalPageKey =
  | 'p01_login'
  | 'p02_hall'
  | 'p03_wizard'
  | 'p04_workbench'
  | 'p05_board'
  | 'p06_new_task'
  | 'p07_detail'
  | 'p08_context'
  | 'p09_artifacts'
  | 'p10_decisions'
  | 'p11_agent'
  | 'p12_settings'
  | 'p13_weekly'
  | 'p14_protocol'
  | 'm_suite'
  | 'ds_tokens'
  | 'ds_components'

interface FinalAuditAndStatesPageProps {
  onOpenPageWithPreset: (target: {
    page: CanonicalPageKey
    role?: 'initiator' | 'member' | 'observer'
    note?: string
  }) => void
}

export function FinalAuditAndStatesPage({
  onOpenPageWithPreset,
}: FinalAuditAndStatesPageProps) {
  // 通用加载骨架屏切换：工作台骨架屏 vs 任务看板骨架屏
  const [skeletonDemoKind, setSkeletonDemoKind] = useState<'workbench' | 'board'>(
    'workbench'
  )
  // 表格组件变体：有数据 vs 空状态
  const [tableVariantDemo, setTableVariantDemo] = useState<'has_data' | 'empty'>(
    'has_data'
  )

  return (
    <div className="flex h-full w-full flex-col overflow-y-auto select-text">
      <div className="mx-auto w-full max-w-[1400px] space-y-6 px-6 py-5">
        {/* ===================================================================
            顶部总览头
           =================================================================== */}
        <div className="flex flex-wrap items-end justify-between gap-3 border-b border-[var(--cf-border-strong)] pb-3.5">
          <div>
            <div className="font-mono-tabular text-[11px] font-bold tracking-widest text-[var(--cf-text-tertiary)]">
              FINAL DELIVERY // STATE ARTBOARDS · COMPONENT VARIANTS · SELF-CHECK · MANIFEST
            </div>
            <h1
              style={{
                fontSize: 'var(--cf-t1-size)',
                lineHeight: 'var(--cf-t1-lh)',
              }}
              className="mt-0.5 font-bold text-[var(--cf-text-primary)]"
            >
              CoFlow 全量状态稿补齐、组件变体、自检报告与交付清单（01 登录 — 14 事件协议）
            </h1>
          </div>
          <span className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] px-2.5 py-1 font-mono-tabular text-[11px] font-semibold text-[var(--cf-text-secondary)]">
            14 桌面页 (1440×900) · 3 移动页 (390×844) · 1 组件库页 · 1 令牌页 · 22 个关键状态稿
          </span>
        </div>

        {/* ===================================================================
            第一部分：一、为指定页面各补 2–3 个状态稿（含通用加载骨架屏 1440×900 实例）
           =================================================================== */}
        <section
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="border p-5"
        >
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2 border-b border-[var(--cf-border-strong)] pb-2.5">
            <h2 className="text-[16px] font-bold text-[var(--cf-text-primary)]">
              一、核心页面状态稿补齐（每页 2–3 个关键状态稿 + 通用加载骨架屏）
            </h2>
            <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
              点击任意状态卡右上按钮可直接进入对应 1440×900 完整状态页
            </span>
          </div>

          {/* 1.1 七大业务页各 2–3 个状态稿对照网格 */}
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {/* 1) 项目大厅：3 个状态稿 */}
            <div className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] p-3.5">
              <div className="flex items-center justify-between border-b border-[var(--cf-border-strong)] pb-2">
                <span className="text-[14px] font-bold text-[var(--cf-text-primary)]">
                  1. 项目大厅（02 项目大厅 · 3 个状态稿）
                </span>
                <button
                  type="button"
                  onClick={() => onOpenPageWithPreset({ page: 'p02_hall' })}
                  className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)] hover:underline"
                >
                  打开页面 →
                </button>
              </div>
              <div className="mt-2.5 space-y-2 text-[12px]">
                <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[var(--cf-text-primary)]">
                      状态稿 A · 空状态（没有任何项目）
                    </span>
                    <span className="border border-[var(--cf-warning)] bg-[var(--cf-warning-bg)] px-1.5 py-0.2 font-mono-tabular text-[10px] font-bold text-[var(--cf-warning)]">
                      EMPTY HALL
                    </span>
                  </div>
                  <p className="mt-1 text-[11px] text-[var(--cf-text-secondary)]">
                    四个统计数字归零，展示虚线档案引导卡：「先建一个项目章程：目标、范围、非目标、约束、验收标准。没有这些，Agent 拿到的上下文只会是一堆聊天记录。」+「＋ 创建第一个项目」主按钮。
                  </p>
                </div>
                <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5">
                  <div className="font-bold text-[var(--cf-text-primary)]">
                    状态稿 B · 未完成上手引导态
                  </div>
                  <p className="mt-0.5 text-[11px] text-[var(--cf-text-secondary)]">
                    顶部琥珀色横幅常驻：「15 分钟跑通第一个闭环 · 建项目 → 连设备 → 授权目录 → 建任务 → 交付验收」+「开始 →」。
                  </p>
                </div>
                <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5">
                  <div className="font-bold text-[var(--cf-text-primary)]">
                    状态稿 C · 常态多项目运行态（含阻塞告警高亮）
                  </div>
                  <p className="mt-0.5 text-[11px] text-[var(--cf-text-secondary)]">
                    展示 4 个不同阶段（定义/开发/联调/验收/归档）项目卡 + 虚线「＋ 新建项目」入口卡，阻塞数 &gt; 0 的卡片三联计数槽自动染为朱砂浅红底。
                  </p>
                </div>
              </div>
            </div>

            {/* 2) 工作台：3 个状态稿 */}
            <div className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] p-3.5">
              <div className="flex items-center justify-between border-b border-[var(--cf-border-strong)] pb-2">
                <span className="text-[14px] font-bold text-[var(--cf-text-primary)]">
                  2. 工作台（04 项目工作台 · 3 个状态稿）
                </span>
                <button
                  type="button"
                  onClick={() =>
                    onOpenPageWithPreset({ page: 'p04_workbench', role: 'observer' })
                  }
                  className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)] hover:underline"
                >
                  打开观察员只读稿 →
                </button>
              </div>
              <div className="mt-2.5 space-y-2 text-[12px]">
                <div className="border border-[var(--cf-warning)] bg-[var(--cf-warning-bg)]/50 p-2.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[var(--cf-text-primary)]">
                      状态稿 A · 观察员只读版（核心必检状态）
                    </span>
                    <span className="bg-[var(--cf-warning)] px-1.5 py-0.2 font-mono-tabular text-[10px] font-bold text-white">
                      READ-ONLY OBSERVER
                    </span>
                  </div>
                  <p className="mt-1 text-[11px] text-[var(--cf-text-secondary)]">
                    1) 底部消息输入框彻底消失，替换为虚线只读说明框「当前身份只读（观察员视角）」；2) 右区待确认决策上的「确认并写入事实层」按钮彻底消失；3) 讨论消息悬停不再出现「+ 形成决策」按钮。
                  </p>
                </div>
                <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5">
                  <div className="font-bold text-[var(--cf-text-primary)]">
                    状态稿 B · 无风险 & 无待办清爽态
                  </div>
                  <p className="mt-0.5 text-[11px] text-[var(--cf-text-secondary)]">
                    右栏「1. 风险」整块自动隐藏不渲染；「2. 需要处理」显示：「没有待办。当前没有阻塞，也没有等结论的验收。」
                  </p>
                </div>
                <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5">
                  <div className="font-bold text-[var(--cf-text-primary)]">
                    状态稿 C · 空讨论流 & 无 Agent 端点引导态
                  </div>
                  <p className="mt-0.5 text-[11px] text-[var(--cf-text-secondary)]">
                    #general 消息区展示发起澄清/形成决策引导；右栏「6. Agent 端点」展示 `npx @coflow/connector` 命令行接入引导。
                  </p>
                </div>
              </div>
            </div>

            {/* 3) 任务看板：3 个状态稿 */}
            <div className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] p-3.5">
              <div className="flex items-center justify-between border-b border-[var(--cf-border-strong)] pb-2">
                <span className="text-[14px] font-bold text-[var(--cf-text-primary)]">
                  3. 任务看板（05 任务看板 · 3 个状态稿）
                </span>
                <button
                  type="button"
                  onClick={() => onOpenPageWithPreset({ page: 'p05_board' })}
                  className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)] hover:underline"
                >
                  打开页面 →
                </button>
              </div>
              <div className="mt-2.5 space-y-2 text-[12px]">
                <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[var(--cf-text-primary)]">
                      状态稿 A · 全空状态（一条任务都没有）
                    </span>
                    <span className="border border-[var(--cf-border-strong)] px-1.5 py-0.2 font-mono-tabular text-[10px] font-semibold">
                      0 TASKS
                    </span>
                  </div>
                  <p className="mt-1 text-[11px] text-[var(--cf-text-secondary)]">
                    隐藏六列空壳，居中呈现档案盒空状态卡：「当前项目暂无拆解任务。任务是最小的协作与授权单元。」+「＋ 新建首个任务」按钮。
                  </p>
                </div>
                <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5">
                  <div className="font-bold text-[var(--cf-text-primary)]">
                    状态稿 B · 单列为空状态（如「待认领」0 项）
                  </div>
                  <p className="mt-0.5 text-[11px] text-[var(--cf-text-secondary)]">
                    列内显示专属流转规则提示语，底部「本列权重合计」显示 `0`。
                  </p>
                </div>
                <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5">
                  <div className="font-bold text-[var(--cf-text-primary)]">
                    状态稿 C · 六列常规 + 底部旁路状态（已阻塞/已暂停/已取消）
                  </div>
                  <p className="mt-0.5 text-[11px] text-[var(--cf-text-secondary)]">
                    六列展示主状态任务与底部权重合计，下方独立横栏公示阻塞任务及其阻塞原因。
                  </p>
                </div>
              </div>
            </div>

            {/* 4) 任务详情：3 个状态稿 */}
            <div className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] p-3.5">
              <div className="flex items-center justify-between border-b border-[var(--cf-border-strong)] pb-2">
                <span className="text-[14px] font-bold text-[var(--cf-text-primary)]">
                  4. 任务详情（07 任务详情 · 3 个状态稿）
                </span>
                <button
                  type="button"
                  onClick={() =>
                    onOpenPageWithPreset({ page: 'p07_detail', role: 'member' })
                  }
                  className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)] hover:underline"
                >
                  打开无验收权稿 →
                </button>
              </div>
              <div className="mt-2.5 space-y-2 text-[12px]">
                <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[var(--cf-text-primary)]">
                      状态稿 A · 无权限版（成员/观察员视角：验收表单不出现）
                    </span>
                    <span className="border border-[var(--cf-primary)] bg-[var(--cf-primary-tint)] px-1.5 py-0.2 font-mono-tabular text-[10px] font-bold text-[var(--cf-primary)]">
                      NO-PERMISSION HIDDEN
                    </span>
                  </div>
                  <p className="mt-1 text-[11px] text-[var(--cf-text-secondary)]">
                    当非验收权角色（如「成员」或「观察员」）查看处于「待验收」的 TSK-108 时，右侧「给出人工验收结论」表单与「验收通过/退回」按钮直接不渲染（绝非置灰）。
                  </p>
                </div>
                <div className="border border-[var(--cf-danger)] bg-[var(--cf-danger-bg)]/50 p-2.5">
                  <div className="font-bold text-[var(--cf-danger)]">
                    状态稿 B · 版本冲突错误提示态
                  </div>
                  <p className="mt-0.5 text-[11px] text-[var(--cf-text-secondary)]">
                    编辑任务定义保存时若 base_version 过期，弹出朱砂红横幅：「[版本冲突告警] 任务已被他人修改，请刷新后重试」。
                  </p>
                </div>
                <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5">
                  <div className="font-bold text-[var(--cf-text-primary)]">
                    状态稿 C · 「已就绪」专属 Agent 派发评分卡态 (TSK-114)
                  </div>
                  <p className="mt-0.5 text-[11px] text-[var(--cf-text-secondary)]">
                    仅在任务处于「已就绪」时渲染派发卡，展示 `+25 可自动执行`、`−30 与执行中会话路径重叠` 等加减分推荐理由。
                  </p>
                </div>
              </div>
            </div>

            {/* 5) 上下文包：3 个状态稿 */}
            <div className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] p-3.5">
              <div className="flex items-center justify-between border-b border-[var(--cf-border-strong)] pb-2">
                <span className="text-[14px] font-bold text-[var(--cf-text-primary)]">
                  5. 上下文包预览（08 上下文包预览 · 3 个状态稿）
                </span>
                <button
                  type="button"
                  onClick={() => onOpenPageWithPreset({ page: 'p08_context' })}
                  className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)] hover:underline"
                >
                  打开页面 →
                </button>
              </div>
              <div className="mt-2.5 space-y-2 text-[12px]">
                <div className="border border-[var(--cf-danger)] bg-[var(--cf-danger-bg)]/50 p-2.5">
                  <div className="font-bold text-[var(--cf-danger)]">
                    状态稿 A · 超预算状态（L0/L1 超出 32,000 tok 上限）
                  </div>
                  <p className="mt-0.5 text-[11px] text-[var(--cf-text-secondary)]">
                    顶部与预算卡同步显示朱砂红阻断警告：「L0/L1 已超过预算，裁剪解决不了（L2 动态层已裁空仍超限）」。
                  </p>
                </div>
                <div className="border border-[var(--cf-warning)] bg-[var(--cf-warning-bg)]/50 p-2.5">
                  <div className="font-bold text-[var(--cf-warning)]">
                    状态稿 B · 未授权目录状态（READ-ONLY SANDBOX）
                  </div>
                  <p className="mt-0.5 text-[11px] text-[var(--cf-text-secondary)]">
                    L3 证据层允许修改路径为空，明确警告：「Agent 只能读，不能写」，且提示词标签变更为 `access_mode="READ_ONLY_LOCKED"`。
                  </p>
                </div>
                <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5">
                  <div className="font-bold text-[var(--cf-text-primary)]">
                    状态稿 C · 没有快照空状态
                  </div>
                  <p className="mt-0.5 text-[11px] text-[var(--cf-text-secondary)]">
                    快照列表为空，提示点击「＋ 保存为快照」固化将下发给 Agent 的上下文凭据。
                  </p>
                </div>
              </div>
            </div>

            {/* 6) Agent 连接 & 7) 周报：各 2–3 个状态稿 */}
            <div className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] p-3.5">
              <div className="flex items-center justify-between border-b border-[var(--cf-border-strong)] pb-2">
                <span className="text-[14px] font-bold text-[var(--cf-text-primary)]">
                  6. Agent 连接 & 7. 周报（共 5 个状态稿）
                </span>
                <div className="flex items-center gap-2 font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]">
                  <button
                    type="button"
                    onClick={() => onOpenPageWithPreset({ page: 'p11_agent' })}
                    className="hover:underline"
                  >
                    Agent连接 →
                  </button>
                  <span>|</span>
                  <button
                    type="button"
                    onClick={() => onOpenPageWithPreset({ page: 'p13_weekly' })}
                    className="hover:underline"
                  >
                    周报 →
                  </button>
                </div>
              </div>
              <div className="mt-2.5 space-y-2 text-[12px]">
                <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5">
                  <div className="font-bold text-[var(--cf-text-primary)]">
                    Agent 连接 · 状态稿 A：没有任何设备
                  </div>
                  <p className="mt-0.5 text-[11px] text-[var(--cf-text-secondary)]">
                    展示虚线引导卡：「没有设备也能用完整流程——产物可以用人工回传」。
                  </p>
                </div>
                <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5">
                  <div className="font-bold text-[var(--cf-text-primary)]">
                    Agent 连接 · 状态稿 B & C：配对码错误/已过期/已使用 + 保存目录失败
                  </div>
                  <p className="mt-0.5 text-[11px] text-[var(--cf-text-secondary)]">
                    配对码输入框变红并给出对应拦截原因；展开「授权目录」保存越界路径时提示连接器拒绝挂载。
                  </p>
                </div>
                <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5">
                  <div className="font-bold text-[var(--cf-text-primary)]">
                    周报 · 状态稿 A：本周无活动空状态
                  </div>
                  <p className="mt-0.5 text-[11px] text-[var(--cf-text-secondary)]">
                    展示：「这一周没有任何项目活动。要么还没开始，要么事情停在了别处。」+「前往 15 分钟上手 →」按钮。
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* -----------------------------------------------------------------
              1.2 通用：加载骨架屏（1440×900 工作台骨架屏 & 任务看板骨架屏 实寸呈现）
             ----------------------------------------------------------------- */}
          <div className="mt-5 border-t border-[var(--cf-border-strong)] pt-4">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="text-[14px] font-bold text-[var(--cf-text-primary)]">
                  8. 通用状态稿：加载骨架屏（Skeleton Screen · 保持「纸上实验室」台账分栏结构，杜绝白屏跳动）
                </h3>
                <p className="text-[11px] text-[var(--cf-text-tertiary)]">
                  采用 `--cf-surface-tertiary` (#E5E0D5) 与 `--cf-surface-secondary` (#F3EFE8) 脉冲色块，严格对齐三栏工作台与六列任务看板骨架：
                </p>
              </div>

              <div className="flex items-center border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] p-0.5 text-[11px]">
                <button
                  type="button"
                  onClick={() => setSkeletonDemoKind('workbench')}
                  style={{
                    backgroundColor:
                      skeletonDemoKind === 'workbench'
                        ? 'var(--cf-primary)'
                        : 'transparent',
                    color:
                      skeletonDemoKind === 'workbench'
                        ? 'var(--cf-surface-card)'
                        : 'var(--cf-text-secondary)',
                  }}
                  className="h-[24px] px-2.5 font-semibold"
                >
                  状态稿 A：工作台加载骨架屏
                </button>
                <button
                  type="button"
                  onClick={() => setSkeletonDemoKind('board')}
                  style={{
                    backgroundColor:
                      skeletonDemoKind === 'board'
                        ? 'var(--cf-primary)'
                        : 'transparent',
                    color:
                      skeletonDemoKind === 'board'
                        ? 'var(--cf-surface-card)'
                        : 'var(--cf-text-secondary)',
                  }}
                  className="h-[24px] px-2.5 font-semibold"
                >
                  状态稿 B：任务看板加载骨架屏
                </button>
              </div>
            </div>

            {skeletonDemoKind === 'workbench' ? (
              /* 工作台三栏加载骨架屏 */
              <div className="grid h-[270px] grid-cols-12 overflow-hidden border border-[var(--cf-border-strong)] bg-[var(--cf-surface-paper)]">
                {/* 左栏 A 方向骨架 */}
                <div className="col-span-3 space-y-2.5 border-r border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] p-3 animate-pulse">
                  <div className="h-4 w-28 bg-[var(--cf-surface-tertiary)]" />
                  <div className="space-y-1.5 border border-[var(--cf-border-subtle)] p-2">
                    <div className="h-3 w-full bg-[var(--cf-surface-tertiary)]" />
                    <div className="h-3 w-4/5 bg-[var(--cf-surface-secondary)]" />
                    <div className="h-3 w-3/4 bg-[var(--cf-surface-secondary)]" />
                  </div>
                  <div className="h-4 w-24 bg-[var(--cf-surface-tertiary)]" />
                  <div className="space-y-1.5 border border-[var(--cf-border-subtle)] p-2">
                    <div className="h-2.5 w-full bg-[var(--cf-surface-tertiary)]" />
                    <div className="h-2.5 w-5/6 bg-[var(--cf-surface-tertiary)]" />
                  </div>
                </div>

                {/* 中栏 B 讨论流骨架 */}
                <div className="col-span-4 flex flex-col justify-between border-r border-[var(--cf-border-strong)] bg-[var(--cf-surface-paper)] p-3 animate-pulse">
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between border-b border-[var(--cf-border-strong)] pb-2">
                      <div className="h-4 w-24 bg-[var(--cf-surface-tertiary)]" />
                      <div className="h-5 w-28 rounded-full bg-[var(--cf-surface-tertiary)]" />
                    </div>
                    <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5 space-y-1.5">
                      <div className="h-3 w-1/3 bg-[var(--cf-surface-tertiary)]" />
                      <div className="h-3 w-full bg-[var(--cf-surface-secondary)]" />
                    </div>
                    <div className="h-5 w-full bg-[var(--cf-surface-tertiary)]" />
                    <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5 space-y-1.5">
                      <div className="h-3 w-1/4 bg-[var(--cf-surface-tertiary)]" />
                      <div className="h-3 w-5/6 bg-[var(--cf-surface-secondary)]" />
                    </div>
                  </div>
                  <div className="h-9 w-full border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)]" />
                </div>

                {/* 右栏 C 要处理的事 7 模块骨架 */}
                <div className="col-span-5 space-y-2 bg-[var(--cf-surface-card)] p-3 animate-pulse">
                  <div className="h-4 w-40 bg-[var(--cf-surface-tertiary)]" />
                  <div className="h-12 w-full border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] p-2" />
                  <div className="h-14 w-full border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] p-2" />
                  <div className="grid grid-cols-2 gap-2">
                    <div className="h-16 border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)]" />
                    <div className="h-16 border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)]" />
                  </div>
                  <div className="h-6 w-full bg-[var(--cf-surface-tertiary)]" />
                </div>
              </div>
            ) : (
              /* 任务看板六列加载骨架屏 */
              <div className="grid h-[270px] grid-cols-6 gap-2.5 border border-[var(--cf-border-strong)] bg-[var(--cf-surface-paper)] p-3 animate-pulse">
                {[1, 2, 3, 4, 5, 6].map((col) => (
                  <div
                    key={col}
                    className="flex flex-col justify-between border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] p-2"
                  >
                    <div className="space-y-2">
                      <div className="flex justify-between border-b border-[var(--cf-border-strong)] pb-1.5">
                        <div className="h-4 w-14 bg-[var(--cf-surface-tertiary)]" />
                        <div className="h-4 w-6 bg-[var(--cf-surface-tertiary)]" />
                      </div>
                      <div className="space-y-1.5 border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2">
                        <div className="h-2.5 w-1/2 bg-[var(--cf-surface-tertiary)]" />
                        <div className="h-3 w-full bg-[var(--cf-surface-tertiary)]" />
                        <div className="h-2.5 w-2/3 bg-[var(--cf-surface-secondary)]" />
                      </div>
                      <div className="space-y-1.5 border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2">
                        <div className="h-2.5 w-1/3 bg-[var(--cf-surface-tertiary)]" />
                        <div className="h-3 w-4/5 bg-[var(--cf-surface-tertiary)]" />
                      </div>
                    </div>
                    <div className="h-3.5 w-full bg-[var(--cf-surface-tertiary)]" />
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* ===================================================================
            第二部分：二、组件变体补齐（按钮四态 / 输入四态 / 表格[有数据 vs 空] / 提示条四态）
           =================================================================== */}
        <section
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="border p-5"
        >
          <div className="mb-4 flex items-center justify-between border-b border-[var(--cf-border-strong)] pb-2.5">
            <h2 className="text-[16px] font-bold text-[var(--cf-text-primary)]">
              二、核心组件变体补齐核验（按钮 / 输入 / 表格[有数据 vs 空] / 提示条）
            </h2>
            <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
              ALL STATES COMPLETE
            </span>
          </div>

          <div className="space-y-4 text-[12px]">
            {/* 1) 按钮：默认 / 悬停 / 禁用 / 加载中 */}
            <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)] p-3">
              <div className="mb-2 font-bold text-[var(--cf-text-primary)]">
                1. 按钮四态（默认 / 悬停 / 禁用 / 加载中）
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <CfButton variant="primary" visualState="default">
                  默认 (Default)
                </CfButton>
                <CfButton variant="primary" visualState="hover">
                  悬停 (Hover)
                </CfButton>
                <CfButton variant="primary" visualState="disabled">
                  禁用 (Disabled)
                </CfButton>
                <CfButton variant="primary" visualState="loading">
                  加载中 (Loading)
                </CfButton>
              </div>
            </div>

            {/* 2) 输入：默认 / 聚焦 / 错误 / 禁用 */}
            <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)] p-3">
              <div className="mb-2 font-bold text-[var(--cf-text-primary)]">
                2. 输入框四态（默认 / 聚焦 / 错误 / 禁用）
              </div>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-4">
                <input
                  type="text"
                  readOnly
                  value="默认态 (1px --cf-border-strong)"
                  className="h-[30px] border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] px-2.5 text-[12px]"
                />
                <input
                  type="text"
                  readOnly
                  value="聚焦态 (--cf-primary + 2px 光晕)"
                  style={{
                    borderColor: 'var(--cf-primary)',
                    boxShadow: '0 0 0 2px var(--cf-primary-tint)',
                  }}
                  className="h-[30px] border bg-[var(--cf-surface-card)] px-2.5 text-[12px] font-medium"
                />
                <input
                  type="text"
                  readOnly
                  value="错误态 (--cf-danger 红框浅红底)"
                  style={{
                    borderColor: 'var(--cf-danger)',
                    backgroundColor: 'var(--cf-danger-bg)',
                    color: 'var(--cf-danger)',
                  }}
                  className="h-[30px] border px-2.5 text-[12px] font-medium"
                />
                <input
                  type="text"
                  disabled
                  value="禁用态 (--cf-surface-tertiary)"
                  style={{
                    borderColor: 'var(--cf-border-subtle)',
                    backgroundColor: 'var(--cf-surface-tertiary)',
                    color: 'var(--cf-text-muted)',
                  }}
                  className="h-[30px] cursor-not-allowed border px-2.5 text-[12px]"
                />
              </div>
            </div>

            {/* 3) 表格：有数据 / 空（切换对比） */}
            <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)] p-3">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-bold text-[var(--cf-text-primary)]">
                  3. 表格双态（有数据 vs 空状态变体）
                </span>
                <div className="flex items-center border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] p-0.5 text-[11px]">
                  <button
                    type="button"
                    onClick={() => setTableVariantDemo('has_data')}
                    style={{
                      backgroundColor:
                        tableVariantDemo === 'has_data'
                          ? 'var(--cf-primary)'
                          : 'transparent',
                      color:
                        tableVariantDemo === 'has_data'
                          ? 'var(--cf-surface-card)'
                          : 'var(--cf-text-secondary)',
                    }}
                    className="h-[22px] px-2 font-semibold"
                  >
                    有数据态
                  </button>
                  <button
                    type="button"
                    onClick={() => setTableVariantDemo('empty')}
                    style={{
                      backgroundColor:
                        tableVariantDemo === 'empty'
                          ? 'var(--cf-primary)'
                          : 'transparent',
                      color:
                        tableVariantDemo === 'empty'
                          ? 'var(--cf-surface-card)'
                          : 'var(--cf-text-secondary)',
                    }}
                    className="h-[22px] px-2 font-semibold"
                  >
                    空表格态 (Empty Table)
                  </button>
                </div>
              </div>

              <div className="overflow-hidden border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)]">
                <table className="w-full border-collapse text-left text-[12px]">
                  <thead>
                    <tr className="border-b border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                      <th className="px-3 py-1.5">任务 ID</th>
                      <th className="px-3 py-1.5">任务事实名称</th>
                      <th className="px-3 py-1.5">20px 状态</th>
                      <th className="px-3 py-1.5">优先级</th>
                      <th className="px-3 py-1.5 text-right">Token 消耗 (右对齐)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tableVariantDemo === 'has_data' ? (
                      <>
                        <tr className="border-b border-[var(--cf-border-subtle)] hover:bg-[var(--cf-surface-secondary)]">
                          <td className="px-3 py-1.5 font-mono-tabular font-bold text-[var(--cf-text-primary)]">
                            TSK-108
                          </td>
                          <td className="px-3 py-1.5 font-medium">
                            向量检索模块召回率评测与章程指标对齐
                          </td>
                          <td className="px-3 py-1.5">
                            <TaskStatusBadge status="pending_accept" size="compact" />
                          </td>
                          <td className="px-3 py-1.5">
                            <PriorityBadge level="P0" showLabel={false} />
                          </td>
                          <td className="px-3 py-1.5 text-right font-mono-tabular">
                            32,640
                          </td>
                        </tr>
                        <tr className="hover:bg-[var(--cf-surface-secondary)]">
                          <td className="px-3 py-1.5 font-mono-tabular font-bold text-[var(--cf-text-primary)]">
                            TSK-112
                          </td>
                          <td className="px-3 py-1.5 font-medium">
                            多模态竞赛数据集清洗脚本与异常样本剔除
                          </td>
                          <td className="px-3 py-1.5">
                            <TaskStatusBadge status="in_progress" size="compact" />
                          </td>
                          <td className="px-3 py-1.5">
                            <PriorityBadge level="P1" showLabel={false} />
                          </td>
                          <td className="px-3 py-1.5 text-right font-mono-tabular">
                            18,910
                          </td>
                        </tr>
                      </>
                    ) : (
                      <tr>
                        <td
                          colSpan={5}
                          className="px-4 py-7 text-center text-[12px] text-[var(--cf-text-tertiary)]"
                        >
                          当前筛选条件下暂无匹配的台账记录（表头结构保持稳定，不发生布局跳动）。
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 4) 提示条：信息 / 警告 / 危险 / 成功 */}
            <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)] p-3">
              <div className="mb-2 font-bold text-[var(--cf-text-primary)]">
                4. 提示条四态（信息 / 警告 / 危险 / 成功）
              </div>
              <div className="grid grid-cols-1 gap-2 md:grid-cols-2">
                <InlineBanner
                  tone="info"
                  title="信息提示条 (Info)"
                  description="上下文包快照已锁定，本地连接器可通过 MCP 拉取。"
                  code="INFO"
                />
                <InlineBanner
                  tone="warning"
                  title="警告提示条 (Warning)"
                  description="半自动端点缺少 --output-format，不能执行 coflow run。"
                  code="WARN"
                />
                <InlineBanner
                  tone="danger"
                  title="危险提示条 (Danger)"
                  description="L0/L1 已超过预算，裁剪解决不了。"
                  code="ERR"
                />
                <InlineBanner
                  tone="success"
                  title="成功提示条 (Success)"
                  description="人工验收通过，结论已写入项目事实层。"
                  code="PASS"
                />
              </div>
            </div>
          </div>
        </section>

        {/* ===================================================================
            第三部分：三、自检逐条核验面板（8 项硬指标对账）
           =================================================================== */}
        <section
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="border p-5"
        >
          <div className="mb-3.5 flex items-center justify-between border-b border-[var(--cf-border-strong)] pb-2.5">
            <h2 className="text-[16px] font-bold text-[var(--cf-text-primary)]">
              三、设计质量自检报告（8 条逐项核验与本轮修正记录）
            </h2>
            <div className="flex items-center gap-1.5">
              {TASK_STATUS_LIST.map((s) => (
                <TaskStatusBadge key={s.status} status={s.status} size="compact" />
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 md:grid-cols-2 text-[12px]">
            {[
              {
                q: '1. 六种任务状态 + 三种旁路状态，缩小到 20px 高时是否仍能区分？靠的是什么手段？',
                a: '完全可区分（见右上原尺寸 20px 九态实测条）。依靠四重编码：1) 边框形态（虚线框 vs 细实线框 vs 左 3px 加粗印章边 vs 旁路 0px 直角框）；2) 10×10px 纯几何 SVG 符号（菱形问号、虚线圆、双圈靶点、右向三角、盾形核验、方框对勾、八角截停、双竖暂停、斜杠终止圆）；3) 底色填充极性（空心纸白 vs 浅色底 vs 高对比实心绿/红满底 vs 45° 斜纹底）；4) 字形修饰（已取消带删除线）。',
              },
              {
                q: '2. 工作台右栏的风险、待办、执行中，有没有哪一块被简化掉了？',
                a: '零删减、零简化。04 项目工作台右栏从上到下完整保留全部 7 个模块：1. 风险（高/中/低三级 + 数量汇总）→ 2. 需要处理（待确认决策/待验收任务/阻塞任务）→ 3. 正在执行（Agent 会话+路径）→ 4. 已确认决策 → 5. 最新产物 → 6. Agent 端点 → 7. 最后同步时间。',
              },
              {
                q: '3. 观察员视角下，操作入口是消失还是变灰？',
                a: '已全部统一为「直接消失（不渲染 DOM）」而非变灰。本轮自检中发现「项目设置」的阶段应用按钮与「Agent 连接」的配对授权按钮在观察员下曾使用了 disabled 变灰态，已在本轮修正为 `!isObserver` 条件渲染，切换为观察员时所有写操作按钮与输入框彻底消失并展示只读说明。',
              },
              {
                q: '4. 有没有哪个页面把"每个字段一张大卡片"，导致信息密度被稀释？',
                a: '没有任何页面采用大卡片堆砌。所有多字段区域（如章程五条款、任务定义五要素、产物与验收三栏对账卡、事件协议 13 公共字段）均采用 1px 细线封闭台账格或紧凑键值对行，1440×900 一屏可承载 20+ 条核心状态信息。',
              },
              {
                q: '5. 主色是否只用在可交互元素与选中态，没有变成装饰？',
                a: '已严格收束。主色深墨青（#0F5257）仅用于主按钮、可点击链接/任务锚点、当前激活页签、选中卡片外框与活跃进度条；静态表头、常规卡片外框与非交互说明统一使用碳素墨黑（#1C1917）、深暖灰（#44403C）与分割线色（#C7C0B3）。',
              },
              {
                q: '6. 中文在 13px 时行高是否足够？',
                a: '充足。全局正文字号令牌 `--cf-t4-size: 13px` 搭配 `--cf-t4-lh: 20px`（行高比 1.54），长文阅读区提升至 20px–21px，在 Windows ClearType 渲染下上下行汉字之间留有 7px 呼吸间距，无任何笔画粘连。',
              },
              {
                q: '7. 有没有一处用了 emoji 当图标？',
                a: '零 Emoji。本轮自检通过正则扫描全库，将此前文案中残留的 `⏳`、`⛔`、`⚠`、`⚙`、`✎` 等在 Windows 下会被 Segoe UI Emoji 渲染为彩色表情的 Unicode 字符全部清除，100% 替换为纯手写几何 SVG 矢量图标与等宽方括号标签。',
              },
              {
                q: '8. 移动端是重排还是等比缩小？',
                a: '彻底的信息重排（非等比缩小）。移动端围绕「今天需要我做什么」将桌面端右栏拆解为工作台顶部可滑出的「今日待办 & 高风险」抽屉；任务看板重排为露出 1.5 列的横向滑动槽 + 顶部分段直达控件；任务详情将主操作固定于底栏并将次要操作收纳进「更多」底部弹出面板，且所有触控热区 ≥ 44×44px。',
              },
            ].map((item, idx) => (
              <div
                key={idx}
                className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)] p-3"
              >
                <div className="font-bold text-[var(--cf-text-primary)]">{item.q}</div>
                <p className="mt-1 leading-[18px] text-[var(--cf-text-secondary)]">
                  {item.a}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* ===================================================================
            第四部分：四、交付清单确认（严格按 01 登录、02 项目大厅 … 14 事件协议 规范命名，点击直达）
           =================================================================== */}
        <section
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="border p-5"
        >
          <div className="mb-3.5 flex items-center justify-between border-b border-[var(--cf-border-strong)] pb-2.5">
            <h2 className="text-[16px] font-bold text-[var(--cf-text-primary)]">
              四、交付清单确认（命名规范：01 登录、02 项目大厅 … 14 事件协议 + 3 移动页 + 令牌与组件库）
            </h2>
            <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-success)]">
              [19/19 交付物全部就绪 · 点击卡片直达对应页面]
            </span>
          </div>

          {/* 14 个桌面页 (1440×900) */}
          <div className="mb-3 text-[12px] font-bold text-[var(--cf-text-secondary)]">
            A. 14 个桌面页（1440×900 · 点击任意编号直达）：
          </div>
          <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-7 text-[12px]">
            {(
              [
                { id: 'p01_login', code: '01 登录', sub: '邮箱验证码两步流' },
                { id: 'p02_hall', code: '02 项目大厅', sub: '4统计+项目卡+空态' },
                { id: 'p03_wizard', code: '03 新建项目向导', sub: '4模板+5步向导' },
                { id: 'p04_workbench', code: '04 项目工作台', sub: '方向+讨论+右7块' },
                { id: 'p05_board', code: '05 任务看板', sub: '6状态列+旁路专区' },
                { id: 'p06_new_task', code: '06 新建任务', sub: '11字段规则弹窗稿' },
                { id: 'p07_detail', code: '07 任务详情', sub: '状态机+派发+验收' },
                { id: 'p08_context', code: '08 上下文包预览', sub: 'L0-L3+预算+<data>' },
                { id: 'p09_artifacts', code: '09 产物与验收', sub: '三栏对账+产物总表' },
                { id: 'p10_decisions', code: '10 决策与时间线', sub: '决策演进+5类事件' },
                { id: 'p11_agent', code: '11 Agent 连接', sub: '配对码+两层授权' },
                { id: 'p12_settings', code: '12 项目设置', sub: '章程修订+保留策略' },
                { id: 'p13_weekly', code: '13 周报', sub: '6事实句+双七日图' },
                { id: 'p14_protocol', code: '14 事件协议', sub: '13字段+12事件+合同' },
              ] as { id: CanonicalPageKey; code: string; sub: string }[]
            ).map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => onOpenPageWithPreset({ page: item.id })}
                className="flex flex-col justify-between border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] p-2.5 text-left transition-colors hover:border-[var(--cf-primary)] hover:bg-[var(--cf-primary-tint)]/40"
              >
                <span className="font-mono-tabular text-[12px] font-bold text-[var(--cf-primary)]">
                  {item.code}
                </span>
                <span className="mt-1 text-[11px] text-[var(--cf-text-secondary)]">
                  {item.sub}
                </span>
              </button>
            ))}
          </div>

          {/* 3 个移动页 + 1 个组件库页 + 1 个设计令牌页 */}
          <div className="mt-4 mb-2 text-[12px] font-bold text-[var(--cf-text-secondary)]">
            B. 3 个移动页（390×844）+ 1 个设计令牌页 + 1 个组件库页：
          </div>
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-5 text-[12px]">
            {[
              {
                page: 'm_suite' as CanonicalPageKey,
                title: '移动页 01 · 工作台 (390×844)',
                sub: '顶部滑出今日待办 + 消息流',
              },
              {
                page: 'm_suite' as CanonicalPageKey,
                title: '移动页 02 · 任务看板 (390×844)',
                sub: '露出 1.5 列左右滑 + 分段直达',
              },
              {
                page: 'm_suite' as CanonicalPageKey,
                title: '移动页 03 · 任务详情 (390×844)',
                sub: '底部主动作 + 更多 Action Sheet',
              },
              {
                page: 'ds_tokens' as CanonicalPageKey,
                title: '设计令牌页 (Design Tokens)',
                sub: '四级表面/文字/语义色/7级字号',
              },
              {
                page: 'ds_components' as CanonicalPageKey,
                title: '组件库页 (Component Library)',
                sub: '20px 九态徽标 + 13 类完整组件',
              },
            ].map((m, i) => (
              <button
                key={i}
                type="button"
                onClick={() => onOpenPageWithPreset({ page: m.page })}
                className="flex flex-col justify-between border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] p-2.5 text-left hover:border-[var(--cf-primary)] hover:bg-[var(--cf-primary-tint)]/40"
              >
                <span className="font-bold text-[var(--cf-primary)]">{m.title}</span>
                <span className="mt-1 text-[11px] text-[var(--cf-text-secondary)]">
                  {m.sub}
                </span>
              </button>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
