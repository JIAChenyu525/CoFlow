import { useState } from 'react'
import { CfButton } from '../design-system/components'

interface WeeklyReportPageProps {
  onOpenOnboarding: () => void
}

const DAILY_CREATED_SERIES = [
  { date: '11-06 (五)', value: 2 },
  { date: '11-07 (六)', value: 0 },
  { date: '11-08 (日)', value: 1 },
  { date: '11-09 (一)', value: 1 },
  { date: '11-10 (二)', value: 0 },
  { date: '11-11 (三)', value: 1 },
  { date: '11-12 (四)', value: 0 },
]

const DAILY_ACCEPTED_SERIES = [
  { date: '11-06 (五)', value: 0 },
  { date: '11-07 (六)', value: 0 },
  { date: '11-08 (日)', value: 0 },
  { date: '11-09 (一)', value: 1 },
  { date: '11-10 (二)', value: 0 },
  { date: '11-11 (三)', value: 0 },
  { date: '11-12 (四)', value: 1 },
]

const PROJECT_WEEKLY_ROWS = [
  {
    code: 'ZX',
    name: '多智能体企业知识库混合检索系统',
    created: 5,
    completed: 2,
    returned: 0,
    completionRate: '40.0%',
  },
  {
    code: 'MCP2',
    name: '跨平台本地 AI 连接器沙箱与目录授权网关 (上周结转)',
    created: 0,
    completed: 0,
    returned: 0,
    completionRate: '—',
  },
]

const AGENT_FAILURE_BREAKDOWN = [
  { reason: '超时 (Timeout)', count: 0, note: '会话租约 120 分钟内未回传产物' },
  {
    reason: '越界修改 (Out-of-Scope Write)',
    count: 0,
    note: '触碰 L3 白名单以外或禁止访问的路径被拦截',
  },
  {
    reason: '输出无法解析 (Malformed Output)',
    count: 0,
    note: '回传补丁缺少 SHA-1 校验清单或 JSON 损坏',
  },
  {
    reason: 'Agent 报错 (Process Non-Zero Exit)',
    count: 0,
    note: '本地工具进程异常退出或模型调用中断',
  },
]

export function WeeklyReportPage({ onOpenOnboarding }: WeeklyReportPageProps) {
  const [noActivityDemo, setNoActivityDemo] = useState(false)

  const maxDailyValue = 3

  return (
    <div className="flex h-full w-full flex-col overflow-y-auto select-text">
      {/* =====================================================================
          顶部说明与空状态切换栏
         ===================================================================== */}
      <div
        style={{
          backgroundColor: 'var(--cf-surface-secondary)',
          borderBottom: '1px solid var(--cf-border-strong)',
        }}
        className="flex shrink-0 flex-wrap items-center justify-between gap-2 px-6 py-2"
      >
        <div className="flex items-center gap-2">
          <span
            style={{
              backgroundColor: 'var(--cf-primary)',
              color: 'var(--cf-surface-card)',
            }}
            className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-bold"
          >
            WEEKLY FACT LEDGER
          </span>
          <span className="text-[13px] font-bold text-[var(--cf-text-primary)]">
            二、周报（只统计已经发生的事实，不做预测）
          </span>
        </div>

        <div className="flex items-center gap-2.5 text-[11px]">
          <button
            type="button"
            onClick={() => setNoActivityDemo((v) => !v)}
            style={{
              backgroundColor: noActivityDemo
                ? 'var(--cf-primary)'
                : 'var(--cf-surface-card)',
              color: noActivityDemo
                ? 'var(--cf-surface-card)'
                : 'var(--cf-text-secondary)',
              borderColor: 'var(--cf-border-strong)',
            }}
            className="h-[22px] border px-2 font-medium"
          >
            {noActivityDemo
              ? '✓ 已开启：完全没有活动态'
              : '模拟：完全没有活动时的空状态'}
          </button>

          {/* 右上「15 分钟上手」入口 */}
          <CfButton variant="primary" size="xs" onClick={onOpenOnboarding}>
            15 分钟上手 →
          </CfButton>
        </div>
      </div>

      <div className="mx-auto w-full max-w-[1360px] space-y-5 px-6 py-5">
        {/* ===================================================================
            1. 页头：标题 + 日期区间 (2026-11-06 → 2026-11-12) + 一句「只统计已经发生的事实，不做预测」+ 右上「15 分钟上手」
           =================================================================== */}
        <div className="flex flex-wrap items-end justify-between gap-3 border-b border-[var(--cf-border-strong)] pb-3.5">
          <div>
            <div className="flex flex-wrap items-center gap-2.5">
              <h1
                style={{
                  fontSize: 'var(--cf-t1-size)',
                  lineHeight: 'var(--cf-t1-lh)',
                }}
                className="font-bold text-[var(--cf-text-primary)]"
              >
                周报 · 这一周发生了什么
              </h1>
              <span
                style={{
                  backgroundColor: 'var(--cf-primary-tint)',
                  borderColor: 'var(--cf-primary)',
                  color: 'var(--cf-primary)',
                }}
                className="border px-2.5 py-0.5 font-mono-tabular text-[12px] font-bold"
              >
                2026-11-06 → 2026-11-12
              </span>
            </div>
            <p className="mt-1 text-[13px] font-medium text-[var(--cf-text-secondary)]">
              只统计已经发生的事实，不做预测。
            </p>
          </div>

          <button
            type="button"
            onClick={onOpenOnboarding}
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-primary)',
              color: 'var(--cf-primary)',
            }}
            className="h-[30px] border px-3 text-[12px] font-semibold hover:bg-[var(--cf-primary)] hover:text-white transition-colors"
          >
            15 分钟上手 →
          </button>
        </div>

        {/* ===================================================================
            状态分支：完全没有活动时 vs 正常周报数据
           =================================================================== */}
        {noActivityDemo ? (
          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="flex flex-col items-center justify-center border border-dashed px-6 py-14 text-center"
          >
            <div
              style={{
                backgroundColor: 'var(--cf-surface-secondary)',
                borderColor: 'var(--cf-border-strong)',
              }}
              className="mb-3 flex h-12 w-12 items-center justify-center border font-mono-tabular text-[16px] font-bold text-[var(--cf-text-tertiary)]"
            >
              0
            </div>
            <p className="max-w-lg text-[15px] font-bold leading-[24px] text-[var(--cf-text-primary)]">
              这一周没有任何项目活动。要么还没开始，要么事情停在了别处。
            </p>
            <p className="mt-1.5 text-[12px] text-[var(--cf-text-tertiary)]">
              周报仅汇总已写入事件总线的任务流转、产物提交与人工验收结论。
            </p>
            <div className="mt-4 flex items-center gap-3">
              <CfButton variant="primary" size="default" onClick={onOpenOnboarding}>
                前往「15 分钟上手」跑通首个闭环 →
              </CfButton>
              <CfButton
                variant="secondary"
                size="default"
                onClick={() => setNoActivityDemo(false)}
              >
                恢复本周事实数据
              </CfButton>
            </div>
          </div>
        ) : (
          <>
            {/* ===============================================================
                2. 叙述区：6 条由数字生成的事实句
               =============================================================== */}
            <section
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-primary)',
                borderLeftWidth: '4px',
                boxShadow: 'var(--cf-shadow-card)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="border p-4"
            >
              <div className="mb-2 flex items-center justify-between border-b border-[var(--cf-border-subtle)] pb-1.5">
                <span className="text-[12px] font-bold text-[var(--cf-primary)]">
                  本周事实摘要（由事件台账自动合成）
                </span>
                <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                  DETERMINISTIC NARRATIVE · 6 FACTS
                </span>
              </div>

              <ul className="grid grid-cols-1 gap-x-6 gap-y-2 text-[13px] leading-[20px] text-[var(--cf-text-primary)] md:grid-cols-2">
                <li className="flex items-baseline gap-2">
                  <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                    [01]
                  </span>
                  <span>
                    本周在 <strong className="font-mono-tabular font-bold">1</strong> 个项目里新建{' '}
                    <strong className="font-mono-tabular font-bold">5</strong> 个任务、完成{' '}
                    <strong className="font-mono-tabular font-bold text-[var(--cf-success)]">
                      2
                    </strong>{' '}
                    个。
                  </span>
                </li>
                <li className="flex items-baseline gap-2">
                  <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                    [02]
                  </span>
                  <span>
                    验收 <strong className="font-mono-tabular font-bold">2</strong> 次，全部通过。
                  </span>
                </li>
                <li className="flex items-baseline gap-2">
                  <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                    [03]
                  </span>
                  <span>
                    Agent 会话 <strong className="font-mono-tabular font-bold">3</strong> 次：提交{' '}
                    <strong className="font-mono-tabular font-bold">3</strong>、失败{' '}
                    <strong className="font-mono-tabular font-bold">0</strong>、进行中{' '}
                    <strong className="font-mono-tabular font-bold">0</strong>。
                  </span>
                </li>
                <li className="flex items-baseline gap-2">
                  <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                    [04]
                  </span>
                  <span>
                    从建任务到通过验收，周期中位数{' '}
                    <strong className="font-mono-tabular font-bold text-[var(--cf-primary)]">
                      3.7
                    </strong>{' '}
                    天。
                  </span>
                </li>
                <li className="flex items-baseline gap-2">
                  <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                    [05]
                  </span>
                  <span>
                    上下文包平均{' '}
                    <strong className="font-mono-tabular font-bold text-[var(--cf-primary)]">
                      869
                    </strong>{' '}
                    tokens（最大 <strong className="font-mono-tabular font-bold">899</strong>
                    ）。这是每次派发的固定成本。
                  </span>
                </li>
                <li className="flex items-baseline gap-2">
                  <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-danger)]">
                    [06]
                  </span>
                  <span className="font-semibold text-[var(--cf-danger)]">
                    仍有 <strong className="font-mono-tabular font-bold">1</strong> 个任务处于阻塞。
                  </span>
                </li>
              </ul>
            </section>

            {/* ===============================================================
                3. 五个指标：完成、新建、通过率（含"共 N 次验收"）、Agent 会话（含失败数）、上下文成本（平均 tokens）
               =============================================================== */}
            <section className="grid grid-cols-2 gap-3 sm:grid-cols-5">
              {[
                {
                  label: '完成',
                  val: '2',
                  sub: '本周通过人工验收',
                  color: 'var(--cf-success)',
                },
                {
                  label: '新建',
                  val: '5',
                  sub: '本周新增拆解任务',
                  color: 'var(--cf-text-primary)',
                },
                {
                  label: '通过率',
                  val: '100%',
                  sub: '共 2 次验收 (0 次退回)',
                  color: 'var(--cf-primary)',
                },
                {
                  label: 'Agent 会话',
                  val: '3',
                  sub: '提交 3 · 失败 0',
                  color: 'var(--cf-info)',
                },
                {
                  label: '上下文成本',
                  val: '869 tok',
                  sub: '平均 tokens (最大 899)',
                  color: 'var(--cf-warning)',
                },
              ].map((m) => (
                <div
                  key={m.label}
                  style={{
                    backgroundColor: 'var(--cf-surface-card)',
                    borderColor: 'var(--cf-border-strong)',
                    boxShadow: 'var(--cf-shadow-card)',
                    borderRadius: 'var(--cf-radius-container)',
                  }}
                  className="border p-3.5"
                >
                  <div className="text-[12px] font-semibold text-[var(--cf-text-secondary)]">
                    {m.label}
                  </div>
                  <div
                    style={{ color: m.color }}
                    className="mt-1 font-mono-tabular text-[22px] font-bold leading-none"
                  >
                    {m.val}
                  </div>
                  <div className="mt-1.5 font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                    {m.sub}
                  </div>
                </div>
              ))}
            </section>

            {/* ===============================================================
                4. 两张七日图表：每天新建的任务数、每天通过验收的任务数（同一度量按天展示，单系列）
               =============================================================== */}
            <section className="grid grid-cols-1 gap-4 md:grid-cols-2">
              {/* 左图：每天新建的任务数 */}
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-card)',
                  borderColor: 'var(--cf-border-strong)',
                  boxShadow: 'var(--cf-shadow-card)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="border p-4"
              >
                <div className="mb-3 flex items-center justify-between border-b border-[var(--cf-border-subtle)] pb-2">
                  <span className="text-[13px] font-bold text-[var(--cf-text-primary)]">
                    七日趋势 A · 每天新建的任务数（单系列）
                  </span>
                  <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]">
                    合计 5 项
                  </span>
                </div>

                <div className="grid h-36 grid-cols-7 items-end gap-2 pt-4">
                  {DAILY_CREATED_SERIES.map((d) => {
                    const barHeightPct = Math.round((d.value / maxDailyValue) * 100)
                    return (
                      <div
                        key={d.date}
                        className="flex h-full flex-col items-center justify-end gap-1"
                      >
                        <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                          {d.value}
                        </span>
                        <div className="flex h-24 w-full items-end bg-[var(--cf-surface-secondary)] p-1">
                          <div
                            style={{
                              height: d.value === 0 ? '3px' : `${barHeightPct}%`,
                              backgroundColor:
                                d.value === 0
                                  ? 'var(--cf-border-strong)'
                                  : 'var(--cf-primary)',
                            }}
                            className="w-full transition-all"
                          />
                        </div>
                        <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                          {d.date}
                        </span>
                      </div>
                    )
                  })}
                </div>
              </div>

              {/* 右图：每天通过验收的任务数 */}
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-card)',
                  borderColor: 'var(--cf-border-strong)',
                  boxShadow: 'var(--cf-shadow-card)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="border p-4"
              >
                <div className="mb-3 flex items-center justify-between border-b border-[var(--cf-border-subtle)] pb-2">
                  <span className="text-[13px] font-bold text-[var(--cf-text-primary)]">
                    七日趋势 B · 每天通过验收的任务数（单系列）
                  </span>
                  <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-success)]">
                    合计 2 项
                  </span>
                </div>

                <div className="grid h-36 grid-cols-7 items-end gap-2 pt-4">
                  {DAILY_ACCEPTED_SERIES.map((d) => {
                    const barHeightPct = Math.round((d.value / maxDailyValue) * 100)
                    return (
                      <div
                        key={d.date}
                        className="flex h-full flex-col items-center justify-end gap-1"
                      >
                        <span className="font-mono-tabular text-[11px] font-bold text-[var(--cf-success)]">
                          {d.value}
                        </span>
                        <div className="flex h-24 w-full items-end bg-[var(--cf-surface-secondary)] p-1">
                          <div
                            style={{
                              height: d.value === 0 ? '3px' : `${barHeightPct}%`,
                              backgroundColor:
                                d.value === 0
                                  ? 'var(--cf-border-strong)'
                                  : 'var(--cf-success)',
                            }}
                            className="w-full transition-all"
                          />
                        </div>
                        <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                          {d.date}
                        </span>
                      </div>
                    )
                  })}
                </div>
              </div>
            </section>

            {/* ===============================================================
                5. 按项目表格：项目、新建、完成、退回、完成率
               =============================================================== */}
            <section
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-border-strong)',
                boxShadow: 'var(--cf-shadow-card)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="overflow-hidden border"
            >
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderBottom: '1px solid var(--cf-border-strong)',
                }}
                className="flex items-center justify-between px-4 py-2"
              >
                <span className="text-[13px] font-bold text-[var(--cf-text-primary)]">
                  按项目统计表（项目 / 新建 / 完成 / 退回 / 完成率）
                </span>
                <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                  PROJECT BREAKDOWN
                </span>
              </div>

              <table className="w-full border-collapse text-left text-[12px]">
                <thead>
                  <tr
                    style={{
                      backgroundColor: 'var(--cf-surface-secondary)',
                      borderBottom: '1px solid var(--cf-border-subtle)',
                    }}
                    className="text-[11px] font-semibold text-[var(--cf-text-secondary)]"
                  >
                    <th className="px-4 py-2">项目</th>
                    <th className="px-4 py-2 text-right">新建</th>
                    <th className="px-4 py-2 text-right">完成</th>
                    <th className="px-4 py-2 text-right">退回</th>
                    <th className="px-4 py-2 text-right">完成率</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--cf-border-subtle)]">
                  {PROJECT_WEEKLY_ROWS.map((row) => (
                    <tr key={row.code} className="hover:bg-[var(--cf-surface-secondary)]">
                      <td className="px-4 py-2.5">
                        <span className="mr-2 bg-[var(--cf-primary)] px-1.5 py-0.5 font-mono-tabular text-[10px] font-bold text-white">
                          {row.code}
                        </span>
                        <span className="font-semibold text-[var(--cf-text-primary)]">
                          {row.name}
                        </span>
                      </td>
                      <td className="px-4 py-2.5 text-right font-mono-tabular font-semibold">
                        {row.created}
                      </td>
                      <td className="px-4 py-2.5 text-right font-mono-tabular font-semibold text-[var(--cf-success)]">
                        {row.completed}
                      </td>
                      <td className="px-4 py-2.5 text-right font-mono-tabular">
                        {row.returned}
                      </td>
                      <td className="px-4 py-2.5 text-right font-mono-tabular font-bold text-[var(--cf-primary)]">
                        {row.completionRate}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>

            {/* ===============================================================
                6. 两张小卡：卡住的地方（阻塞任务 + 所需支持）、Agent 失败原因（超时 / 越界修改 / 输出无法解析 / Agent 报错）
               =============================================================== */}
            <section className="grid grid-cols-1 gap-4 md:grid-cols-2">
              {/* 左小卡：卡住的地方（阻塞任务 + 所需支持） */}
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-card)',
                  borderColor: 'var(--cf-danger)',
                  borderLeftWidth: '4px',
                  boxShadow: 'var(--cf-shadow-card)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="border p-4"
              >
                <div className="mb-2.5 flex items-center justify-between border-b border-[var(--cf-border-subtle)] pb-2">
                  <span className="text-[13px] font-bold text-[var(--cf-danger)]">
                    卡住的地方（阻塞任务 + 所需支持）
                  </span>
                  <span className="bg-[var(--cf-danger)] px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold text-white">
                    1 项未解除
                  </span>
                </div>

                <div
                  style={{
                    backgroundColor: 'var(--cf-danger-bg)',
                    borderColor: 'var(--cf-danger-border)',
                  }}
                  className="border p-3 text-[12px]"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono-tabular font-bold text-[var(--cf-danger)]">
                      [TSK-109] 企业实测政务云网关接口联调
                    </span>
                    <span className="font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                      已阻塞 5 天 · 许嘉树
                    </span>
                  </div>
                  <div className="mt-1.5 border-t border-[var(--cf-danger-border)] pt-1.5 font-semibold text-[var(--cf-text-primary)]">
                    所需支持：加盖公章的企业营业执照副本扫描件 + 沙箱网关白名单授权函
                  </div>
                </div>
              </div>

              {/* 右小卡：Agent 失败原因（超时 / 越界修改 / 输出无法解析 / Agent 报错） */}
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-card)',
                  borderColor: 'var(--cf-border-strong)',
                  boxShadow: 'var(--cf-shadow-card)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="border p-4"
              >
                <div className="mb-2.5 flex items-center justify-between border-b border-[var(--cf-border-subtle)] pb-2">
                  <span className="text-[13px] font-bold text-[var(--cf-text-primary)]">
                    Agent 失败原因分类审计
                  </span>
                  <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-success)]">
                    本周合计失败 0 次
                  </span>
                </div>

                <div className="divide-y divide-[var(--cf-border-subtle)] text-[12px]">
                  {AGENT_FAILURE_BREAKDOWN.map((item) => (
                    <div
                      key={item.reason}
                      className="flex items-center justify-between py-1.5"
                    >
                      <div>
                        <span className="font-semibold text-[var(--cf-text-primary)]">
                          {item.reason}
                        </span>
                        <span className="ml-2 text-[11px] text-[var(--cf-text-tertiary)]">
                          {item.note}
                        </span>
                      </div>
                      <span className="font-mono-tabular font-bold text-[var(--cf-text-secondary)]">
                        {item.count}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          </>
        )}
      </div>
    </div>
  )
}
