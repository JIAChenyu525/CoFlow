import { useState } from 'react'
import { CfButton, ThinProgressBar } from '../design-system/components'

interface OnboardingPageProps {
  onNavigateTo: (
    page:
      | 'new_project_wizard'
      | 'agent_connect'
      | 'task_board'
      | 'artifacts_acceptance'
      | 'weekly_report'
  ) => void
}

interface OnboardingStepSpec {
  step: number
  title: string
  duration: string
  description: string
  whyText: string
  command?: string
  probeSource: string
  probePassEvidence: string
  probeWaitEvidence: string
  actionLabel: string
  targetPage:
    | 'new_project_wizard'
    | 'agent_connect'
    | 'task_board'
    | 'artifacts_acceptance'
}

const ONBOARDING_STEPS: OnboardingStepSpec[] = [
  {
    step: 1,
    title: '建一个项目',
    duration: '3 分钟',
    description:
      '通过向导确立项目章程（目标、交付范围、非目标、硬性约束、验收标准）并初始化第一批任务。',
    whyText:
      '为什么：没有章程划定边界与验收标准，Agent 拿到的上下文只会是一堆散乱的聊天记录。',
    probeSource: 'SELECT count(*) FROM projects WHERE charter_version IS NOT NULL',
    probePassEvidence: '系统探针已确认：检测到项目 [ZX] 与已锁定章程 CHR-v2.4 (2025-05-06 09:15)',
    probeWaitEvidence: '系统探针等待中：当前账号下尚未查询到已发布章程的项目记录',
    actionLabel: '去新建项目 →',
    targetPage: 'new_project_wizard',
  },
  {
    step: 2,
    title: '连接一台设备',
    duration: '3 分钟',
    description:
      '在你的电脑终端运行连接器登录命令，获取 8 位配对码并在「Agent 连接」页完成设备绑定。',
    whyText:
      '为什么：把本地 AI 工具安全绑定到你的账号，平台无需触碰你的模型 API Key 即可派发任务。',
    command: 'npx coflow-connector login',
    probeSource: 'SELECT count(*) FROM devices WHERE status = "ONLINE"',
    probePassEvidence:
      '系统探针已确认：设备 CHENMO-WIN11-WORKSTATION 已配对在线 (心跳延迟 14ms)',
    probeWaitEvidence:
      '系统探针未检出：当前账号下 online_devices = 0（需在终端运行命令并输入配对码）',
    actionLabel: '去配对设备 →',
    targetPage: 'agent_connect',
  },
  {
    step: 3,
    title: '给端点授权目录',
    duration: '2 分钟',
    description:
      '在已接入的 Agent 端点上配置允许修改的相对路径白名单（如 src/retrieval/**, artifacts/eval/**）。',
    whyText:
      '为什么：未授权可写目录时 Agent 只能读不能写；明确目录沙箱才能防止 AI 越界改坏无关模块。',
    probeSource: 'SELECT allowed_dirs FROM agent_endpoints WHERE length(allowed_dirs) > 0',
    probePassEvidence:
      '系统探针已确认：端点 cursor-win-02 已挂载 3 条可写目录白名单规则',
    probeWaitEvidence: '系统探针未检出：尚无端点配置非空的可写目录白名单 (allowed_dirs = [])',
    actionLabel: '去授权目录 →',
    targetPage: 'agent_connect',
  },
  {
    step: 4,
    title: '有一个「已就绪」的任务',
    duration: '3 分钟',
    description:
      '在任务看板中补齐任务的「输入材料」「验收标准」并指定「负责人」，使状态机推进至「已就绪」。',
    whyText:
      '为什么：缺输入或缺验收标准的任务会被规则锁在「待澄清」，只有「已就绪」的任务才会出现 Agent 派发卡。',
    probeSource: 'SELECT id FROM tasks WHERE status IN ("READY","IN_PROGRESS","PENDING_ACCEPT","DONE")',
    probePassEvidence:
      '系统探针已确认：检测到任务 TSK-114 已满足完整定义契约并进入「已就绪」状态',
    probeWaitEvidence:
      '系统探针未检出：当前所有任务仍停留在「待澄清」或「待认领」，尚无「已就绪」任务',
    actionLabel: '去任务看板 →',
    targetPage: 'task_board',
  },
  {
    step: 5,
    title: '跑通一次完整交付',
    duration: '4 分钟',
    description:
      '由本地连接器拉取上下文包执行任务、回传带哈希的证据产物，并由评审人完成一次人工验收通过。',
    whyText:
      '为什么：聊天与代码生成都只是过程，唯有带证据的产物经人工签批通过，才算真正写入项目事实层。',
    command: 'coflow pull --task TSK-114   # 或使用自动模式：coflow run --task TSK-114',
    probeSource: 'SELECT count(*) FROM acceptance_records WHERE conclusion = "APPROVED"',
    probePassEvidence:
      '系统探针已确认：任务 TSK-104 / TSK-105 已回传产物哈希并完成人工签批入库',
    probeWaitEvidence:
      '系统探针未检出：尚无完成「连接器回传产物 → 人工验收通过」全链路闭环的记录',
    actionLabel: '去产物与验收 →',
    targetPage: 'artifacts_acceptance',
  },
]

const STUCK_TROUBLESHOOTING = [
  {
    code: 'FAQ-01',
    title: '连接器连不上',
    solution: '先跑 coflow doctor，它会告诉你缺什么能力',
    detail: '自动检测本地 Node 版本、MCP 端口占用以及 CLI 是否支持 --print / --output-format。',
  },
  {
    code: 'FAQ-02',
    title: '任务移不到「已就绪」',
    solution: '说明输入材料或验收标准还空着',
    detail: '状态机严格拦截缺项任务：需在任务详情补齐输入材料、验收标准并指定负责人。',
  },
  {
    code: 'FAQ-03',
    title: '派发按钮不出现',
    solution: '任务必须先是「已就绪」，且项目里要有可用端点',
    detail: '非「已就绪」状态不渲染派发卡；若项目尚未绑定在线设备，请先执行第 2 步连接设备。',
  },
]

export function OnboardingPage({ onNavigateTo }: OnboardingPageProps) {
  // 系统真实数据判定的完成步数模拟：
  // 'step1_done' (1/5，展示顶部「下一步 · 连接一台设备 · 约 3 分钟 · 去配对」引导条)
  // 'step3_done' (3/5，如题面示例 3/5)
  // 'all_done' (5/5，展示顶部绿色「闭环已经跑通」+「看这一周发生了什么」按钮)
  const [systemProgressMode, setSystemProgressMode] = useState<
    'step1_done' | 'step3_done' | 'all_done'
  >('step1_done')
  const [copiedStep, setCopiedStep] = useState<number | null>(null)

  const completedCount =
    systemProgressMode === 'step1_done'
      ? 1
      : systemProgressMode === 'step3_done'
        ? 3
        : 5
  const progressPct = Math.round((completedCount / 5) * 100)
  const isAllDone = completedCount === 5

  const handleCopyCmd = (stepNum: number, cmd: string) => {
    navigator.clipboard?.writeText(cmd)
    setCopiedStep(stepNum)
    setTimeout(() => setCopiedStep(null), 1800)
  }

  return (
    <div className="flex h-full w-full flex-col overflow-y-auto select-text">
      {/* =====================================================================
          顶部状态验证控制栏（切换后台系统探针判定的完成进度：1/5 未完成态 | 3/5 进行中 | 5/5 全部完成态）
         ===================================================================== */}
      <div
        style={{
          backgroundColor: 'var(--cf-surface-secondary)',
          borderBottom: '1px solid var(--cf-border-strong)',
        }}
        className="flex shrink-0 flex-wrap items-center justify-between gap-2 px-6 py-2 text-[11px]"
      >
        <div className="flex items-center gap-2">
          <span
            style={{
              backgroundColor: 'var(--cf-primary)',
              color: 'var(--cf-surface-card)',
            }}
            className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-bold"
          >
            SYSTEM-DRIVEN ONBOARDING
          </span>
          <span className="font-bold text-[var(--cf-text-primary)]">
            三、上手（15 分钟跑通第一个闭环 · 状态由系统真实数据探针只读判定，不可手点打勾）
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <span className="text-[var(--cf-text-tertiary)]">切换系统数据进度状态:</span>
          {[
            { id: 'step1_done', label: '未完成态 (1/5 · 下一步连接设备)' },
            { id: 'step3_done', label: '进行中态 (3/5 示例进度)' },
            { id: 'all_done', label: '全部完成态 (5/5 · 闭环已经跑通)' },
          ].map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() =>
                setSystemProgressMode(m.id as typeof systemProgressMode)
              }
              style={{
                backgroundColor:
                  systemProgressMode === m.id
                    ? 'var(--cf-primary)'
                    : 'var(--cf-surface-card)',
                color:
                  systemProgressMode === m.id
                    ? 'var(--cf-surface-card)'
                    : 'var(--cf-text-secondary)',
                borderColor: 'var(--cf-border-strong)',
              }}
              className="h-[22px] border px-2 font-medium"
            >
              {m.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mx-auto w-full max-w-[1220px] space-y-5 px-6 py-5">
        {/* ===================================================================
            1. 顶部动态状态横幅：
               - 完成态：显示绿色完成提示「闭环已经跑通」+ 一段说明 + 「看这一周发生了什么」按钮
               - 未完成态：顶部一条「下一步 · 连接一台设备 · 约 3 分钟 · 去配对」引导条
           =================================================================== */}
        {isAllDone ? (
          <div
            style={{
              backgroundColor: 'var(--cf-success-bg)',
              borderColor: 'var(--cf-success)',
              borderLeftWidth: '5px',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="flex flex-wrap items-center justify-between gap-4 border p-4"
          >
            <div>
              <div className="flex items-center gap-2">
                <span
                  style={{
                    backgroundColor: 'var(--cf-success)',
                    color: 'var(--cf-surface-card)',
                  }}
                  className="px-2 py-0.5 font-mono-tabular text-[11px] font-bold"
                >
                  ✓ CLOSED LOOP VERIFIED
                </span>
                <h2 className="text-[16px] font-bold text-[var(--cf-success)]">
                  闭环已经跑通
                </h2>
              </div>
              <p className="mt-1 text-[13px] text-[var(--cf-text-primary)]">
                系统已在事件台账中检测到完整的「立项章程 → 设备配对 → 目录沙箱授权 → 任务就绪 → 产物验收通过」全链路事实记录。
              </p>
            </div>

            <CfButton
              variant="primary"
              size="default"
              onClick={() => onNavigateTo('weekly_report')}
            >
              看这一周发生了什么 →
            </CfButton>
          </div>
        ) : (
          <div
            style={{
              backgroundColor: 'var(--cf-warning-bg)',
              borderColor: 'var(--cf-warning)',
              borderLeftWidth: '5px',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="flex flex-wrap items-center justify-between gap-3 border px-4 py-3"
          >
            <div className="flex items-center gap-2.5 text-[13px]">
              <span
                style={{
                  backgroundColor: 'var(--cf-warning)',
                  color: 'var(--cf-surface-card)',
                }}
                className="px-2 py-0.5 font-mono-tabular text-[11px] font-bold"
              >
                NEXT ACTION
              </span>
              <span className="font-bold text-[var(--cf-text-primary)]">
                {systemProgressMode === 'step1_done'
                  ? '下一步 · 连接一台设备 · 约 3 分钟'
                  : '下一步 · 有一个「已就绪」的任务 · 约 3 分钟'}
              </span>
            </div>

            <button
              type="button"
              onClick={() =>
                onNavigateTo(
                  systemProgressMode === 'step1_done'
                    ? 'agent_connect'
                    : 'task_board'
                )
              }
              style={{
                backgroundColor: 'var(--cf-primary)',
                color: 'var(--cf-surface-card)',
              }}
              className="h-[28px] px-3 text-[12px] font-semibold hover:bg-[var(--cf-primary-deep)]"
            >
              {systemProgressMode === 'step1_done' ? '去配对 →' : '去任务看板 →'}
            </button>
          </div>
        )}

        {/* ===================================================================
            2. 页头：标题 + 说明「五步。每步的完成状态来自系统真实数据，不是教程里的打勾。」+ 进度 (3 / 5) + 进度条
           =================================================================== */}
        <div
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="border p-4"
        >
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <h1
                style={{
                  fontSize: 'var(--cf-t1-size)',
                  lineHeight: 'var(--cf-t1-lh)',
                }}
                className="font-bold text-[var(--cf-text-primary)]"
              >
                15 分钟跑通第一个闭环
              </h1>
              <p className="mt-1 text-[13px] font-medium text-[var(--cf-text-secondary)]">
                五步。每步的完成状态来自系统真实数据，不是教程里的打勾。
              </p>
            </div>

            <div className="flex items-center gap-3">
              <span
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderColor: 'var(--cf-border-strong)',
                }}
                className="border px-2.5 py-1 font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]"
              >
                状态源：只读数据库探针 (READ-ONLY SYSTEM PROBE)
              </span>
              <span className="font-mono-tabular text-[20px] font-bold text-[var(--cf-primary)]">
                {completedCount} / 5
              </span>
            </div>
          </div>

          <div className="mt-3">
            <ThinProgressBar percent={progressPct} />
          </div>
        </div>

        {/* ===================================================================
            3. 五个步骤卡
               每张包含：序号圆圈（完成显示 ✓ 且标题划掉）、标题、时长标签、说明、「为什么：……」弱化文字、命令行代码块+复制按钮、动作按钮
               并且突出「系统真实数据探针判定，不可手点勾选」的视觉特征
           =================================================================== */}
        <div className="space-y-3">
          {ONBOARDING_STEPS.map((item) => {
            const isStepDone = item.step <= completedCount
            const isNextActive = item.step === completedCount + 1

            return (
              <div
                key={item.step}
                style={{
                  backgroundColor: isStepDone
                    ? 'var(--cf-surface-secondary)'
                    : 'var(--cf-surface-card)',
                  borderColor: isNextActive
                    ? 'var(--cf-primary)'
                    : isStepDone
                      ? 'var(--cf-success-border)'
                      : 'var(--cf-border-strong)',
                  borderLeftWidth: isNextActive || isStepDone ? '4px' : '1px',
                  borderLeftColor: isStepDone
                    ? 'var(--cf-success)'
                    : isNextActive
                      ? 'var(--cf-primary)'
                      : 'var(--cf-border-strong)',
                  boxShadow: isNextActive ? 'var(--cf-shadow-card)' : 'none',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="border p-4 transition-all"
              >
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="flex min-w-0 flex-1 items-start gap-3.5">
                    {/* 序号圆圈（完成显示 ✓，非手动复选框，鼠标悬停显示 cursor-default 与系统锁定提示） */}
                    <div
                      title="此状态由系统自动查询事实库判定，不可手动勾选"
                      style={{
                        backgroundColor: isStepDone
                          ? 'var(--cf-success)'
                          : isNextActive
                            ? 'var(--cf-primary)'
                            : 'var(--cf-surface-tertiary)',
                        color:
                          isStepDone || isNextActive
                            ? 'var(--cf-surface-card)'
                            : 'var(--cf-text-secondary)',
                        borderColor: isStepDone
                          ? 'var(--cf-success)'
                          : 'var(--cf-border-strong)',
                      }}
                      className="mt-0.5 flex h-7 w-7 shrink-0 cursor-default items-center justify-center rounded-full border font-mono-tabular text-[13px] font-bold select-none"
                    >
                      {isStepDone ? '✓' : item.step}
                    </div>

                    <div className="min-w-0 flex-1 space-y-1.5">
                      {/* 顶行：标题（完成时划掉 line-through） + 时长标签（如 3 分钟） + 系统数据探针锁标 */}
                      <div className="flex flex-wrap items-center gap-2">
                        <h3
                          className={`text-[15px] font-bold ${
                            isStepDone
                              ? 'line-through text-[var(--cf-text-secondary)]'
                              : 'text-[var(--cf-text-primary)]'
                          }`}
                        >
                          {item.title}
                        </h3>

                        <span
                          style={{
                            backgroundColor: 'var(--cf-surface-card)',
                            borderColor: 'var(--cf-border-strong)',
                          }}
                          className="border px-2 py-0.5 font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]"
                        >
                          {item.duration}
                        </span>

                        {/* 明确标识：系统真实数据自动判定，非人工勾选 */}
                        <span
                          style={{
                            backgroundColor: isStepDone
                              ? 'var(--cf-success-bg)'
                              : 'var(--cf-surface-tertiary)',
                            color: isStepDone
                              ? 'var(--cf-success)'
                              : 'var(--cf-text-tertiary)',
                            borderColor: isStepDone
                              ? 'var(--cf-success-border)'
                              : 'var(--cf-border-strong)',
                          }}
                          className="inline-flex items-center gap-1 border px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold"
                        >
                          <span>
                            {isStepDone
                              ? '[系统数据已核验 · AUTO-VERIFIED]'
                              : '[待系统数据触发 · AUTO-DETECT]'}
                          </span>
                        </span>
                      </div>

                      {/* 说明 */}
                      <p className="text-[13px] leading-[19px] text-[var(--cf-text-primary)]">
                        {item.description}
                      </p>

                      {/* 「为什么：……」一行弱化文字 */}
                      <p className="text-[12px] text-[var(--cf-text-tertiary)]">
                        {item.whyText}
                      </p>

                      {/* 命令行代码块 + 复制按钮 */}
                      {item.command && (
                        <div
                          style={{
                            backgroundColor: '#14181F',
                            borderColor: 'var(--cf-border-strong)',
                            borderRadius: 'var(--cf-radius-control)',
                          }}
                          className="mt-2 flex items-center justify-between gap-2 border px-3 py-1.5 text-[#E6EDF3]"
                        >
                          <code className="font-mono-tabular text-[12px] text-[#A7F3D0]">
                            $ {item.command}
                          </code>
                          <button
                            type="button"
                            onClick={() => handleCopyCmd(item.step, item.command!)}
                            className="shrink-0 border border-[#30363D] bg-[#21262D] px-2 py-0.5 font-mono-tabular text-[11px] text-[#E6EDF3] hover:bg-[#30363D]"
                          >
                            {copiedStep === item.step ? '✓ 已复制' : '复制命令'}
                          </button>
                        </div>
                      )}

                      {/* 系统探针真实数据判定凭据（强化“不是我自己勾的”视觉可信度） */}
                      <div
                        style={{
                          backgroundColor: 'var(--cf-surface-card)',
                          borderColor: 'var(--cf-border-subtle)',
                        }}
                        className="mt-1.5 flex flex-wrap items-center justify-between gap-2 border px-2.5 py-1 font-mono-tabular text-[11px]"
                      >
                        <span
                          style={{
                            color: isStepDone
                              ? 'var(--cf-success)'
                              : 'var(--cf-text-tertiary)',
                          }}
                          className="font-medium"
                        >
                          {isStepDone ? item.probePassEvidence : item.probeWaitEvidence}
                        </span>
                        <span className="text-[10px] text-[var(--cf-text-muted)]">
                          PROBE: {item.probeSource}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* 右侧动作按钮 */}
                  <div className="shrink-0">
                    <CfButton
                      variant={isNextActive ? 'primary' : 'secondary'}
                      size="sm"
                      onClick={() => onNavigateTo(item.targetPage)}
                    >
                      {item.actionLabel}
                    </CfButton>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* ===================================================================
            4. 底部「如果卡住了」三条排障卡
           =================================================================== */}
        <footer
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="border p-4"
        >
          <div className="mb-3 flex items-center justify-between border-b border-[var(--cf-border-subtle)] pb-2">
            <span className="text-[14px] font-bold text-[var(--cf-text-primary)]">
              如果卡住了（常见阻断排障指南）
            </span>
            <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
              TROUBLESHOOTING · 3 RULES
            </span>
          </div>

          <div className="grid grid-cols-1 gap-3 md:grid-cols-3 text-[12px]">
            {STUCK_TROUBLESHOOTING.map((faq) => (
              <div
                key={faq.code}
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderColor: 'var(--cf-border-strong)',
                  borderLeft: '3px solid var(--cf-warning)',
                }}
                className="border p-3"
              >
                <div className="font-mono-tabular text-[10px] font-bold text-[var(--cf-warning)]">
                  {faq.code}
                </div>
                <div className="mt-0.5 text-[13px] font-bold text-[var(--cf-text-primary)]">
                  {faq.title}：{faq.solution}
                </div>
                <p className="mt-1 text-[11px] leading-[17px] text-[var(--cf-text-secondary)]">
                  {faq.detail}
                </p>
              </div>
            ))}
          </div>
        </footer>
      </div>
    </div>
  )
}
