import React, { useState } from 'react'
import {
  TaskStatusBadge,
  PriorityBadge,
  CapabilityBadge,
  CfButton,
  SingleAvatar,
  KeyValueTag,
  TaskStatus,
  RoleType,
} from '../design-system/components'
import {
  CoFlowTask,
  DISPATCH_CANDIDATES,
  TaskArtifactItem,
  TaskAcceptanceRecord,
} from '../data/mockTasks'

interface TaskDetailPageProps {
  tasks: CoFlowTask[]
  selectedTaskId: string
  currentRole: RoleType
  onSelectTask: (taskId: string) => void
  onUpdateTask: (updated: CoFlowTask) => void
  onNavigateToBoard: () => void
  onNavigateToContextPack: (taskId: string) => void
}

export function TaskDetailPage({
  tasks,
  selectedTaskId,
  currentRole,
  onSelectTask,
  onUpdateTask,
  onNavigateToBoard,
  onNavigateToContextPack,
}: TaskDetailPageProps) {
  const task = tasks.find((t) => t.id === selectedTaskId) || tasks[0]

  // 权限判定（严格遵守：无权限的动作直接不出现，而不是变灰！）
  const isObserver = currentRole === 'observer'
  const hasAcceptancePower =
    currentRole === 'initiator' ||
    currentRole === 'owner' ||
    currentRole === 'reviewer'
  const canCancelTask = currentRole === 'initiator' || currentRole === 'owner'

  // 编辑任务定义状态 + 冲突模拟
  const [isEditingDef, setIsEditingDef] = useState(false)
  const [simulateConflict, setSimulateConflict] = useState(false)
  const [conflictAlert, setConflictAlert] = useState<string | null>(null)
  const [editDesc, setEditDesc] = useState(task.description)
  const [editInputs, setEditInputs] = useState(task.inputMaterials.join('\n'))
  const [editScope, setEditScope] = useState(task.workScope.join('\n'))
  const [editNonScope, setEditNonScope] = useState(task.nonWorkScope.join('\n'))
  const [editCriteria, setEditCriteria] = useState(task.acceptanceCriteria.join('\n'))

  // 状态机面板输入
  const [transitionNote, setTransitionNote] = useState('')
  const [noArtifactExplanation, setNoArtifactExplanation] = useState('')
  const [quickAssignee, setQuickAssignee] = useState(task.assigneeName || '陈默')
  const [showBlockerForm, setShowBlockerForm] = useState(false)
  const [blockerReasonInput, setBlockerReasonInput] = useState('')
  const [blockerNeedInput, setBlockerNeedInput] = useState('')
  const [ruleErrorMsg, setRuleErrorMsg] = useState<string | null>(null)

  // 验收结论表单（仅待验收 + 有验收权时显示）
  const [acceptConclusion, setAcceptConclusion] = useState<'通过' | '补充材料' | '退回'>('通过')
  const [criterionChecks, setCriterionChecks] = useState<Record<number, boolean>>({
    0: true,
    1: true,
    2: true,
  })
  const [acceptComment, setAcceptComment] = useState('')

  // 提交产物表单
  const [artType, setArtType] = useState<TaskArtifactItem['type']>('评测报告')
  const [artName, setArtName] = useState('')
  const [artLocation, setArtLocation] = useState('')
  const [artVersion, setArtVersion] = useState('v1.4.3')
  const [submitWithAcceptance, setSubmitWithAcceptance] = useState(true)

  // 派发卡片状态（仅任务处于「已就绪」时出现）
  const [selectedEndpointId, setSelectedEndpointId] = useState(DISPATCH_CANDIDATES[0].id)
  const [noEndpointsDemo, setNoEndpointsDemo] = useState(false)

  // 切换任务时同步编辑器的默认值
  const handleSwitchTask = (newTaskId: string) => {
    const target = tasks.find((t) => t.id === newTaskId)
    if (target) {
      setEditDesc(target.description)
      setEditInputs(target.inputMaterials.join('\n'))
      setEditScope(target.workScope.join('\n'))
      setEditNonScope(target.nonWorkScope.join('\n'))
      setEditCriteria(target.acceptanceCriteria.join('\n'))
      setIsEditingDef(false)
      setConflictAlert(null)
      setRuleErrorMsg(null)
      setShowBlockerForm(false)
    }
    onSelectTask(newTaskId)
  }

  // 保存任务定义（版本号 +1；冲突时提示"任务已被他人修改，请刷新后重试"）
  const handleSaveDefinition = () => {
    if (simulateConflict) {
      setConflictAlert('任务已被他人修改，请刷新后重试')
      return
    }

    const updatedInputs = editInputs
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean)
    const updatedCriteria = editCriteria
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean)

    onUpdateTask({
      ...task,
      description: editDesc.trim(),
      inputMaterials: updatedInputs,
      workScope: editScope
        .split('\n')
        .map((s) => s.trim())
        .filter(Boolean),
      nonWorkScope: editNonScope
        .split('\n')
        .map((s) => s.trim())
        .filter(Boolean),
      acceptanceCriteria: updatedCriteria,
      definitionVersion: task.definitionVersion + 1,
      updatedAt: '2025-05-14 17:10',
    })
    setIsEditingDef(false)
    setConflictAlert(null)
  }

  // 状态机动作执行
  const executeTransition = (nextStatus: TaskStatus) => {
    setRuleErrorMsg(null)

    // 规则 1：待澄清 → 待认领（需已填输入与验收标准）
    if (task.status === 'clarify' && nextStatus === 'unclaimed') {
      if (task.inputMaterials.length === 0 || task.acceptanceCriteria.length === 0) {
        setRuleErrorMsg(
          '流转拦截：待澄清 → 待认领 需已填写「输入材料」与「验收标准」，请先在左侧点击「编辑任务定义」补齐。'
        )
        return
      }
    }

    // 规则 2：待认领 → 已就绪（需已指定负责人）
    if (task.status === 'unclaimed' && nextStatus === 'ready') {
      const finalAssignee = task.assigneeName || quickAssignee.trim()
      if (!finalAssignee) {
        setRuleErrorMsg('流转拦截：待认领 → 已就绪 必须指定任务负责人。')
        return
      }
      onUpdateTask({
        ...task,
        status: 'ready',
        assigneeName: finalAssignee,
        assigneeShort: finalAssignee.slice(0, 1),
        updatedAt: '2025-05-14 17:12',
      })
      setTransitionNote('')
      return
    }

    // 规则 4：进行中 → 待验收（需至少一项产物，或填写无产物说明）
    if (task.status === 'in_progress' && nextStatus === 'pending_accept') {
      if (task.artifacts.length === 0 && !noArtifactExplanation.trim()) {
        setRuleErrorMsg(
          '流转拦截：进行中 → 待验收 需至少提交一项证据产物，或在下方填写「无产物说明」。'
        )
        return
      }
    }

    // 规则 7：已完成 → 重新打开（产生新的返工轮次 +1）
    if (task.status === 'done') {
      onUpdateTask({
        ...task,
        status: nextStatus,
        reworkRound: task.reworkRound + 1,
        updatedAt: '2025-05-14 17:15',
      })
      setTransitionNote('')
      return
    }

    onUpdateTask({
      ...task,
      status: nextStatus,
      updatedAt: '2025-05-14 17:15',
    })
    setTransitionNote('')
  }

  // 标记阻塞（必须填原因与所需支持）
  const handleConfirmBlocker = () => {
    if (!blockerReasonInput.trim() || !blockerNeedInput.trim()) {
      setRuleErrorMsg('标记阻塞必须同时填写「阻塞原因」与「所需支持」。')
      return
    }
    onUpdateTask({
      ...task,
      status: 'blocked',
      blockerReason: blockerReasonInput.trim(),
      blockerNeed: blockerNeedInput.trim(),
      updatedAt: '2025-05-14 17:16',
    })
    setShowBlockerForm(false)
    setBlockerReasonInput('')
    setBlockerNeedInput('')
    setRuleErrorMsg(null)
  }

  // 提交验收结论（通过 / 补充材料 / 退回）
  const handleSubmitAcceptance = (e: React.FormEvent) => {
    e.preventDefault()
    if (!hasAcceptancePower || isObserver) return

    const reviewerMap: Record<RoleType, string> = {
      initiator: '林知夏',
      owner: '陈默',
      reviewer: '周舟',
      member: '苏哲',
      observer: '顾言',
    }

    const newRecord: TaskAcceptanceRecord = {
      id: `ACC-${task.id.slice(4)}-R${task.reworkRound}-${task.acceptanceRecords.length + 1}`,
      conclusion: acceptConclusion,
      reviewer: reviewerMap[currentRole],
      time: '2025-05-14 17:18',
      itemResults: task.acceptanceCriteria.map((c, idx) => ({
        criterion: c,
        passed: criterionChecks[idx] ?? true,
      })),
      comment:
        acceptComment.trim() ||
        (acceptConclusion === '通过'
          ? '全部指标核验通过，准予写入项目当前事实层。'
          : '请按逐条结论补齐证据后重新提测。'),
    }

    const nextStatus: TaskStatus =
      acceptConclusion === '通过' ? 'done' : 'in_progress'
    const nextRework =
      acceptConclusion === '退回' ? task.reworkRound + 1 : task.reworkRound

    onUpdateTask({
      ...task,
      status: nextStatus,
      reworkRound: nextRework,
      acceptanceRecords: [newRecord, ...task.acceptanceRecords],
      updatedAt: '2025-05-14 17:18',
    })
    setAcceptComment('')
  }

  // 提交新产物
  const handleSubmitArtifact = (e: React.FormEvent) => {
    e.preventDefault()
    if (isObserver || !artName.trim() || !artLocation.trim()) return

    const newArt: TaskArtifactItem = {
      id: `ART-${Date.now().toString().slice(-4)}`,
      type: artType,
      name: artName.trim(),
      location: artLocation.trim(),
      version: artVersion.trim() || 'v1.0.0',
      submitter: task.assigneeName || '陈默',
      time: '2025-05-14 17:20',
    }

    const shouldAdvanceToAccept =
      submitWithAcceptance &&
      (task.status === 'in_progress' || task.status === 'ready')

    onUpdateTask({
      ...task,
      artifacts: [newArt, ...task.artifacts],
      status: shouldAdvanceToAccept ? 'pending_accept' : task.status,
      updatedAt: '2025-05-14 17:20',
    })
    setArtName('')
    setArtLocation('')
  }

  // 派发给 Agent（生成「待领取」租约，但注意：派发不等于开工，连接器领取后才进入进行中！）
  const handleDispatchToAgent = () => {
    const candidate = DISPATCH_CANDIDATES.find((c) => c.id === selectedEndpointId)
    if (!candidate || isObserver) return

    onUpdateTask({
      ...task,
      currentLease: {
        status: '待领取',
        endpointName: `${candidate.toolName} (${candidate.ownerName})`,
        contextId: `CTX-${task.id.slice(4)}-v${task.definitionVersion} (#8f3a9c)`,
        expiresAt: '2025-05-14 19:30:00 (2h 租约有效期)',
      },
      updatedAt: '2025-05-14 17:22',
    })
  }

  return (
    <div className="flex h-full w-full flex-col overflow-hidden select-text">
      {/* =====================================================================
          顶部任务快速切换导航条（方便一键检验不同状态任务在详情页的专属面板）
         ===================================================================== */}
      <div
        style={{
          backgroundColor: 'var(--cf-surface-secondary)',
          borderBottom: '1px solid var(--cf-border-strong)',
        }}
        className="flex shrink-0 flex-wrap items-center justify-between gap-2 px-4 py-1.5"
      >
        <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
          <span className="font-semibold text-[var(--cf-text-secondary)]">
            快速切换不同状态任务样例：
          </span>
          {[
            { id: 'TSK-114', note: '已就绪 (含 Agent 派发卡片)' },
            { id: 'TSK-108', note: '待验收 (含验收结论面板 & R1)' },
            { id: 'TSK-112', note: '进行中 (含当前租约)' },
            { id: 'TSK-119', note: '待澄清 (缺输入材料)' },
            { id: 'TSK-117', note: '待认领 (未指派负责人)' },
            { id: 'TSK-104', note: '已完成 (可重新打开产生返工轮次)' },
            { id: 'TSK-109', note: '已阻塞 (旁路)' },
          ].map((item) => {
            const isCurrent = task.id === item.id
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSwitchTask(item.id)}
                style={{
                  backgroundColor: isCurrent
                    ? 'var(--cf-primary)'
                    : 'var(--cf-surface-card)',
                  color: isCurrent
                    ? 'var(--cf-surface-card)'
                    : 'var(--cf-text-secondary)',
                  borderColor: isCurrent
                    ? 'var(--cf-primary)'
                    : 'var(--cf-border-strong)',
                }}
                className="h-[22px] border px-2 font-medium transition-colors"
              >
                <span className="font-mono-tabular font-semibold">{item.id}</span> ·{' '}
                {item.note}
              </button>
            )
          })}
        </div>

        <button
          type="button"
          onClick={() => onNavigateToContextPack(task.id)}
          style={{
            backgroundColor: 'var(--cf-primary-tint)',
            borderColor: 'var(--cf-primary)',
            color: 'var(--cf-primary)',
          }}
          className="h-[22px] border px-2.5 font-mono-tabular text-[11px] font-semibold hover:bg-[var(--cf-primary)] hover:text-white"
        >
          查看本任务「三、上下文包预览」→
        </button>
      </div>

      {/* =====================================================================
          主内容区：左主区 (7 列宽 · 全部事实) + 右侧区 (5 列宽 · 状态机与操作)
         ===================================================================== */}
      <div className="mx-auto grid flex-1 w-full max-w-[1440px] grid-cols-12 overflow-hidden">
        {/* ===================================================================
            左侧主区 (7 列宽)：
            1. 面包屑 → 标题 + 状态徽标 + 优先级 + 里程碑 + 返工轮次
            2. 元信息行：负责人、验收人、截止日期、权重
            3. 任务定义卡 + 编辑任务定义（保存版本号+1，并发冲突告警）
            4. 产物与证据列表
            5. 验收记录列表
           =================================================================== */}
        <div
          style={{
            backgroundColor: 'var(--cf-surface-paper)',
            borderRight: '1px solid var(--cf-border-strong)',
          }}
          className="col-span-7 h-full space-y-4 overflow-y-auto p-4"
        >
          {/* 1 & 2. 面包屑 + 标题头 + 元信息行 */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="border p-4"
          >
            {/* 面包屑 */}
            <div className="flex items-center justify-between text-[11px] text-[var(--cf-text-tertiary)]">
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={onNavigateToBoard}
                  className="font-medium text-[var(--cf-primary)] hover:underline"
                >
                  任务看板
                </button>
                <span>/</span>
                <span>{task.milestone}</span>
                <span>/</span>
                <span className="font-mono-tabular font-semibold text-[var(--cf-text-primary)]">
                  {task.id}
                </span>
              </div>
              <span className="font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                定义版本 v{task.definitionVersion}
              </span>
            </div>

            {/* 标题 + 状态徽标 + 优先级 + 里程碑 + 返工轮次 */}
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <TaskStatusBadge status={task.status} size="default" />
              <PriorityBadge level={task.priority} showLabel={true} />
              <span
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderColor: 'var(--cf-border-strong)',
                }}
                className="border px-2 py-0.5 text-[11px] font-medium text-[var(--cf-text-secondary)]"
              >
                {task.milestone}
              </span>
              <span
                style={{
                  backgroundColor:
                    task.reworkRound > 0
                      ? 'var(--cf-warning-bg)'
                      : 'var(--cf-surface-secondary)',
                  color:
                    task.reworkRound > 0
                      ? 'var(--cf-warning)'
                      : 'var(--cf-text-tertiary)',
                  borderColor:
                    task.reworkRound > 0
                      ? 'var(--cf-warning)'
                      : 'var(--cf-border-strong)',
                }}
                className="border px-2 py-0.5 font-mono-tabular text-[11px] font-bold"
              >
                返工轮次: R{task.reworkRound}
              </span>
            </div>

            <h1
              style={{
                fontSize: 'var(--cf-t2-size)',
                lineHeight: 'var(--cf-t2-lh)',
              }}
              className="mt-2 font-semibold text-[var(--cf-text-primary)]"
            >
              {task.title}
            </h1>

            {/* 元信息行：负责人、验收人、截止日期、权重 */}
            <div
              style={{
                backgroundColor: 'var(--cf-surface-secondary)',
                borderColor: 'var(--cf-border-subtle)',
              }}
              className="mt-3 grid grid-cols-2 gap-2 border p-2.5 sm:grid-cols-4"
            >
              <div>
                <div className="text-[10px] text-[var(--cf-text-tertiary)]">负责人</div>
                <div className="mt-0.5 flex items-center gap-1.5 text-[12px] font-semibold">
                  {task.assigneeName ? (
                    <>
                      <SingleAvatar
                        item={{
                          id: task.id,
                          name: task.assigneeName,
                          short: task.assigneeShort || '员',
                          kind: 'human',
                        }}
                        size={18}
                      />
                      <span>{task.assigneeName}</span>
                    </>
                  ) : (
                    <span className="text-[var(--cf-warning)]">未指派 (待认领)</span>
                  )}
                </div>
              </div>

              <div>
                <div className="text-[10px] text-[var(--cf-text-tertiary)]">验收人</div>
                <div className="mt-0.5 text-[12px] font-semibold text-[var(--cf-text-primary)]">
                  {task.reviewerName} (评审)
                </div>
              </div>

              <div>
                <div className="text-[10px] text-[var(--cf-text-tertiary)]">截止日期</div>
                <div
                  style={{
                    color: task.isOverdue
                      ? 'var(--cf-danger)'
                      : 'var(--cf-text-primary)',
                  }}
                  className="mt-0.5 font-mono-tabular text-[12px] font-semibold"
                >
                  {task.dueDate} {task.isOverdue ? '(已逾期)' : ''}
                </div>
              </div>

              <div>
                <div className="text-[10px] text-[var(--cf-text-tertiary)]">工作量权重</div>
                <div className="mt-0.5 font-mono-tabular text-[12px] font-bold text-[var(--cf-primary)]">
                  {task.weight} pt
                </div>
              </div>
            </div>
          </div>

          {/* 3. 任务定义卡（说明、输入材料、工作范围、非工作范围、突出显示的验收标准 + 编辑入口） */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="border"
          >
            <div
              style={{
                backgroundColor: 'var(--cf-surface-secondary)',
                borderBottom: '1px solid var(--cf-border-strong)',
              }}
              className="flex flex-wrap items-center justify-between gap-2 px-3.5 py-2"
            >
              <div className="flex items-center gap-2">
                <span className="text-[13px] font-semibold text-[var(--cf-text-primary)]">
                  任务定义卡（事实契约 · v{task.definitionVersion}）
                </span>
                <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                  将作为 L1 不可裁剪层注入 Agent 上下文包
                </span>
              </div>

              {/* 「编辑任务定义」入口（观察员只读下不出现） */}
              {!isObserver && (
                <div className="flex items-center gap-2">
                  {isEditingDef && (
                    <label className="flex cursor-pointer items-center gap-1 text-[11px] text-[var(--cf-danger)]">
                      <input
                        type="checkbox"
                        checked={simulateConflict}
                        onChange={(e) => setSimulateConflict(e.target.checked)}
                        className="h-3 w-3 accent-[#B91C1C]"
                      />
                      <span>模拟他人并发修改冲突</span>
                    </label>
                  )}
                  <CfButton
                    variant={isEditingDef ? 'ghost' : 'secondary'}
                    size="xs"
                    onClick={() => {
                      setIsEditingDef((v) => !v)
                      setConflictAlert(null)
                    }}
                  >
                    {isEditingDef ? '取消编辑' : '编辑任务定义'}
                  </CfButton>
                </div>
              )}
            </div>

            {/* 冲突提示横幅 */}
            {conflictAlert && (
              <div
                style={{
                  backgroundColor: 'var(--cf-danger-bg)',
                  borderBottom: '1px solid var(--cf-danger)',
                  color: 'var(--cf-danger)',
                }}
                className="flex items-center justify-between px-3.5 py-2 text-[12px] font-semibold"
              >
                <span>[版本冲突告警] {conflictAlert}</span>
                <button
                  type="button"
                  onClick={() => {
                    setSimulateConflict(false)
                    setConflictAlert(null)
                  }}
                  className="underline text-[11px]"
                >
                  刷新拉取最新版本并解除冲突
                </button>
              </div>
            )}

            {isEditingDef ? (
              <div className="space-y-3 p-3.5 text-[12px]">
                <div>
                  <label className="mb-1 block font-semibold">任务说明</label>
                  <textarea
                    rows={2}
                    value={editDesc}
                    onChange={(e) => setEditDesc(e.target.value)}
                    className="w-full border border-[var(--cf-border-strong)] p-2 text-[13px]"
                  />
                </div>
                <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                  <div>
                    <label className="mb-1 block font-semibold">输入材料（每行一项）</label>
                    <textarea
                      rows={3}
                      value={editInputs}
                      onChange={(e) => setEditInputs(e.target.value)}
                      className="font-mono-tabular w-full border border-[var(--cf-border-strong)] p-2 text-[11px]"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block font-semibold">工作范围（每行一项）</label>
                    <textarea
                      rows={3}
                      value={editScope}
                      onChange={(e) => setEditScope(e.target.value)}
                      className="font-mono-tabular w-full border border-[var(--cf-border-strong)] p-2 text-[11px]"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block font-semibold">非工作范围（每行一项）</label>
                    <textarea
                      rows={3}
                      value={editNonScope}
                      onChange={(e) => setEditNonScope(e.target.value)}
                      className="w-full border border-[var(--cf-border-strong)] p-2 text-[12px]"
                    />
                  </div>
                </div>
                <div>
                  <label className="mb-1 block font-semibold text-[var(--cf-primary)]">
                    验收标准（每行一条）
                  </label>
                  <textarea
                    rows={3}
                    value={editCriteria}
                    onChange={(e) => setEditCriteria(e.target.value)}
                    className="w-full border border-[var(--cf-primary)] bg-[var(--cf-primary-tint)]/40 p-2 text-[12px] font-medium"
                  />
                </div>
                <div className="flex items-center justify-between border-t border-[var(--cf-border-subtle)] pt-2.5">
                  <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                    保存后版本号将从 v{task.definitionVersion} 升级至 v{task.definitionVersion + 1}
                  </span>
                  <CfButton variant="primary" size="sm" onClick={handleSaveDefinition}>
                    保存修改 (版本 +1)
                  </CfButton>
                </div>
              </div>
            ) : (
              <div className="space-y-3 p-3.5 text-[13px]">
                {/* 说明 */}
                <div>
                  <div className="text-[11px] font-semibold text-[var(--cf-text-tertiary)]">
                    任务说明
                  </div>
                  <p className="mt-0.5 leading-[20px] text-[var(--cf-text-primary)]">
                    {task.description}
                  </p>
                </div>

                {/* 输入材料 + 工作范围 + 非工作范围 三格台账 */}
                <div className="grid grid-cols-1 gap-2.5 md:grid-cols-3 text-[12px]">
                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-secondary)',
                      borderColor: 'var(--cf-border-subtle)',
                    }}
                    className="border p-2.5"
                  >
                    <div className="font-semibold text-[var(--cf-text-secondary)]">
                      输入材料 ({task.inputMaterials.length})
                    </div>
                    {task.inputMaterials.length === 0 ? (
                      <p className="mt-1 text-[11px] font-semibold text-[var(--cf-warning)]">
                        [缺项] 尚未填写输入材料（任务锁定在待澄清）
                      </p>
                    ) : (
                      <ul className="mt-1 space-y-1 font-mono-tabular text-[11px] text-[var(--cf-text-primary)]">
                        {task.inputMaterials.map((inp, idx) => (
                          <li key={idx} className="break-all">
                            • {inp}
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>

                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-secondary)',
                      borderColor: 'var(--cf-border-subtle)',
                    }}
                    className="border p-2.5"
                  >
                    <div className="font-semibold text-[var(--cf-text-secondary)]">
                      工作范围 (In-Scope)
                    </div>
                    <ul className="mt-1 space-y-1 font-mono-tabular text-[11px] text-[var(--cf-text-primary)]">
                      {task.workScope.map((ws, idx) => (
                        <li key={idx}>• {ws}</li>
                      ))}
                    </ul>
                  </div>

                  <div
                    style={{
                      backgroundColor: 'var(--cf-surface-secondary)',
                      borderColor: 'var(--cf-border-subtle)',
                    }}
                    className="border p-2.5"
                  >
                    <div className="font-semibold text-[var(--cf-text-secondary)]">
                      非工作范围 (Out-of-Scope)
                    </div>
                    <ul className="mt-1 space-y-1 text-[11px] text-[var(--cf-text-tertiary)]">
                      {task.nonWorkScope.map((nws, idx) => (
                        <li key={idx}>✕ {nws}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* 验收标准（突出显示：深墨青左印章粗边 + 档案绿/琥珀底色强调框） */}
                <div
                  style={{
                    backgroundColor: 'var(--cf-primary-tint)',
                    borderColor: 'var(--cf-primary)',
                    borderLeftWidth: '4px',
                  }}
                  className="border p-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[12px] font-bold text-[var(--cf-primary)]">
                      ★ 验收标准（人工签批与产物核验法定准绳）
                    </span>
                    <span className="font-mono-tabular text-[10px] font-semibold text-[var(--cf-primary)]">
                      ACCEPTANCE CRITERIA
                    </span>
                  </div>
                  {task.acceptanceCriteria.length === 0 ? (
                    <p className="mt-1.5 text-[12px] font-semibold text-[var(--cf-danger)]">
                      [缺项] 尚未定义验收标准！请点击右上「编辑任务定义」补齐后方可推进至待认领。
                    </p>
                  ) : (
                    <ul className="mt-1.5 space-y-1 text-[13px] font-medium text-[var(--cf-text-primary)]">
                      {task.acceptanceCriteria.map((crit, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="font-mono-tabular mt-0.5 text-[11px] font-bold text-[var(--cf-primary)]">
                            [C{i + 1}]
                          </span>
                          <span>{crit}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* 4. 产物与证据（列表：类型、名称、位置[提交号/路径/链接]、版本、提交人、时间） */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="border"
          >
            <div
              style={{
                backgroundColor: 'var(--cf-surface-secondary)',
                borderBottom: '1px solid var(--cf-border-strong)',
              }}
              className="flex items-center justify-between px-3.5 py-2"
            >
              <span className="text-[13px] font-semibold text-[var(--cf-text-primary)]">
                产物与证据 ({task.artifacts.length})
              </span>
              <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                带可复现位置与版本的交付物才计入事实
              </span>
            </div>

            {task.artifacts.length === 0 ? (
              <div className="p-4 text-center text-[12px] text-[var(--cf-text-tertiary)]">
                当前任务暂未提交任何产物证据。可在右侧「提交产物」面板登记交付物。
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-left text-[12px]">
                  <thead>
                    <tr
                      style={{
                        backgroundColor: 'var(--cf-surface-secondary)',
                        borderBottom: '1px solid var(--cf-border-subtle)',
                      }}
                      className="text-[11px] text-[var(--cf-text-secondary)]"
                    >
                      <th className="px-3 py-1.5">类型</th>
                      <th className="px-3 py-1.5">名称</th>
                      <th className="px-3 py-1.5">位置 (提交号 / 路径 / 链接)</th>
                      <th className="px-3 py-1.5">版本</th>
                      <th className="px-3 py-1.5">提交人</th>
                      <th className="px-3 py-1.5 text-right">时间</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[var(--cf-border-subtle)]">
                    {task.artifacts.map((art) => (
                      <tr key={art.id} className="hover:bg-[var(--cf-surface-secondary)]">
                        <td className="px-3 py-2">
                          <span className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] px-1.5 py-0.5 text-[11px]">
                            {art.type}
                          </span>
                        </td>
                        <td className="px-3 py-2 font-mono-tabular font-semibold text-[var(--cf-text-primary)]">
                          {art.name}
                        </td>
                        <td className="px-3 py-2 font-mono-tabular text-[11px] text-[var(--cf-primary)]">
                          {art.location}
                        </td>
                        <td className="px-3 py-2 font-mono-tabular text-[11px] font-semibold">
                          {art.version}
                        </td>
                        <td className="px-3 py-2 text-[var(--cf-text-secondary)]">
                          {art.submitter}
                        </td>
                        <td className="px-3 py-2 text-right font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                          {art.time}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* 5. 验收记录（结论[通过/退回/补充材料]、评审人、逐条结论、意见、时间） */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="border"
          >
            <div
              style={{
                backgroundColor: 'var(--cf-surface-secondary)',
                borderBottom: '1px solid var(--cf-border-strong)',
              }}
              className="flex items-center justify-between px-3.5 py-2"
            >
              <span className="text-[13px] font-semibold text-[var(--cf-text-primary)]">
                验收记录 ({task.acceptanceRecords.length})
              </span>
              <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                人工给出的验收结论历史
              </span>
            </div>

            {task.acceptanceRecords.length === 0 ? (
              <div className="p-4 text-center text-[12px] text-[var(--cf-text-tertiary)]">
                暂无人工验收记录。
              </div>
            ) : (
              <div className="divide-y divide-[var(--cf-border-subtle)]">
                {task.acceptanceRecords.map((rec) => {
                  const badgeStyle =
                    rec.conclusion === '通过'
                      ? { bg: 'var(--cf-success)', color: 'white' }
                      : rec.conclusion === '退回'
                        ? { bg: 'var(--cf-danger)', color: 'white' }
                        : { bg: 'var(--cf-warning)', color: 'white' }

                  return (
                    <div key={rec.id} className="p-3.5 text-[12px]">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span
                            style={{
                              backgroundColor: badgeStyle.bg,
                              color: badgeStyle.color,
                            }}
                            className="px-2 py-0.5 text-[11px] font-semibold"
                          >
                            结论：{rec.conclusion}
                          </span>
                          <span className="font-semibold text-[var(--cf-text-primary)]">
                            评审人：{rec.reviewer}
                          </span>
                          <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                            [{rec.id}]
                          </span>
                        </div>
                        <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                          {rec.time}
                        </span>
                      </div>

                      {/* 逐条结论 */}
                      <div className="mt-2 space-y-1 border-l-2 border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] px-2.5 py-1.5 text-[11px]">
                        <div className="font-semibold text-[var(--cf-text-secondary)]">
                          逐条验收核对结论：
                        </div>
                        {rec.itemResults.map((ir, idx) => (
                          <div key={idx} className="flex items-center justify-between gap-2">
                            <span className="truncate">{ir.criterion}</span>
                            <span
                              style={{
                                color: ir.passed
                                  ? 'var(--cf-success)'
                                  : 'var(--cf-danger)',
                              }}
                              className="font-mono-tabular shrink-0 font-semibold"
                            >
                              {ir.passed ? '✓ 达标' : '✕ 未达标'}
                            </span>
                          </div>
                        ))}
                      </div>

                      {/* 评审意见 */}
                      <p className="mt-2 text-[12px] leading-[18px] text-[var(--cf-text-primary)]">
                        <strong>评审意见：</strong>
                        {rec.comment}
                      </p>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </div>

        {/* ===================================================================
            右侧操作与状态侧区 (5 列宽 · 高密度模块化组织)：
            1. 状态机面板（严格按状态与权限显示动作，无权限动作直接不出现）
            2. 验收结论面板（仅「待验收」且当前用户有验收权时出现）
            3. 派发卡片（仅任务处于「已就绪」时出现！带评分与加减分推荐理由）
            4. 当前租约（若有）
            5. 提交产物面板
            6. 前置依赖 & 元信息
           =================================================================== */}
        <aside
          style={{
            backgroundColor: 'var(--cf-surface-card)',
          }}
          className="col-span-5 h-full space-y-3 overflow-y-auto p-3.5"
        >
          {/* 观察员只读提示横幅 */}
          {isObserver && (
            <div
              style={{
                backgroundColor: 'var(--cf-warning-bg)',
                borderColor: 'var(--cf-warning)',
                borderLeftWidth: '4px',
              }}
              className="border p-2.5 text-[12px]"
            >
              <div className="font-semibold text-[var(--cf-warning)]">
                当前身份只读（观察员视角）
              </div>
              <div className="mt-0.5 text-[11px] text-[var(--cf-text-secondary)]">
                所有状态流转按钮、编辑入口、产物提交与验收签批控件均已按权限规则隐藏。
              </div>
            </div>
          )}

          {/* ---------------------------------------------------------------
              侧区 1：状态机面板（当前状态 + 变更说明输入 + 可执行动作按钮）
             --------------------------------------------------------------- */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="border"
          >
            <div
              style={{
                backgroundColor: 'var(--cf-surface-secondary)',
                borderBottom: '1px solid var(--cf-border-strong)',
              }}
              className="flex items-center justify-between px-3 py-1.5"
            >
              <span className="text-[12px] font-bold text-[var(--cf-text-primary)]">
                1. 状态机面板 (State Machine)
              </span>
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-[var(--cf-text-tertiary)]">当前状态:</span>
                <TaskStatusBadge status={task.status} size="compact" />
              </div>
            </div>

            <div className="space-y-2.5 p-3 text-[12px]">
              {ruleErrorMsg && (
                <div
                  style={{
                    backgroundColor: 'var(--cf-danger-bg)',
                    borderColor: 'var(--cf-danger)',
                    color: 'var(--cf-danger)',
                  }}
                  className="border p-2 text-[11px] font-semibold"
                >
                  {ruleErrorMsg}
                </div>
              )}

              {!isObserver ? (
                <>
                  {/* 变更说明输入 */}
                  <div>
                    <input
                      type="text"
                      value={transitionNote}
                      onChange={(e) => setTransitionNote(e.target.value)}
                      placeholder="输入状态变更说明或交接备注（选填）..."
                      style={{
                        backgroundColor: 'var(--cf-surface-secondary)',
                        borderColor: 'var(--cf-border-strong)',
                      }}
                      className="h-[28px] w-full border px-2 text-[12px] outline-none focus:border-[var(--cf-primary)]"
                    />
                  </div>

                  {/* 待认领状态下快速指派负责人 */}
                  {task.status === 'unclaimed' && !task.assigneeName && (
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-[var(--cf-text-secondary)]">
                        指定负责人以流转至已就绪：
                      </span>
                      <select
                        value={quickAssignee}
                        onChange={(e) => setQuickAssignee(e.target.value)}
                        className="h-[24px] border border-[var(--cf-border-strong)] bg-white px-2 text-[11px]"
                      >
                        <option value="陈默">陈默</option>
                        <option value="苏哲">苏哲</option>
                        <option value="许嘉树">许嘉树</option>
                      </select>
                    </div>
                  )}

                  {/* 进行中无产物时填写无产物说明 */}
                  {task.status === 'in_progress' && task.artifacts.length === 0 && (
                    <div>
                      <input
                        type="text"
                        value={noArtifactExplanation}
                        onChange={(e) => setNoArtifactExplanation(e.target.value)}
                        placeholder="当前无产物，若直接提测请在此填写「无产物说明」..."
                        className="h-[26px] w-full border border-[var(--cf-warning)] bg-[var(--cf-warning-bg)] px-2 text-[11px]"
                      />
                    </div>
                  )}

                  {/* 可执行动作按钮（严格按当前状态与角色权限渲染，无权限直接不出现！） */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                    {task.status === 'clarify' && (
                      <CfButton
                        variant="primary"
                        size="sm"
                        onClick={() => executeTransition('unclaimed')}
                      >
                        流转至：待认领 →
                      </CfButton>
                    )}

                    {task.status === 'unclaimed' && (
                      <CfButton
                        variant="primary"
                        size="sm"
                        onClick={() => executeTransition('ready')}
                      >
                        认领并流转至：已就绪 →
                      </CfButton>
                    )}

                    {task.status === 'ready' && (
                      <CfButton
                        variant="primary"
                        size="sm"
                        onClick={() => executeTransition('in_progress')}
                      >
                        开始执行：进行中 →
                      </CfButton>
                    )}

                    {task.status === 'in_progress' && (
                      <CfButton
                        variant="primary"
                        size="sm"
                        onClick={() => executeTransition('pending_accept')}
                      >
                        提交人工验收：待验收 →
                      </CfButton>
                    )}

                    {/* 待验收 → 已完成 / 退回进行中（只有带验收权的角色能看到并操作！） */}
                    {task.status === 'pending_accept' && hasAcceptancePower && (
                      <>
                        <CfButton
                          variant="primary"
                          size="sm"
                          onClick={() => executeTransition('done')}
                        >
                          验收通过 → 已完成
                        </CfButton>
                        <CfButton
                          variant="danger"
                          size="sm"
                          onClick={() => executeTransition('in_progress')}
                        >
                          退回进行中
                        </CfButton>
                      </>
                    )}

                    {/* 已完成可「重新打开」（产生新的返工轮次 R+1） */}
                    {task.status === 'done' && (
                      <CfButton
                        variant="secondary"
                        size="sm"
                        onClick={() => executeTransition('in_progress')}
                      >
                        重新打开任务 (产生 R{task.reworkRound + 1} 返工轮次)
                      </CfButton>
                    )}

                    {/* 旁路状态恢复 */}
                    {(task.status === 'blocked' || task.status === 'paused') && (
                      <CfButton
                        variant="primary"
                        size="sm"
                        onClick={() => executeTransition('in_progress')}
                      >
                        解除旁路并恢复进行中
                      </CfButton>
                    )}

                    {/* 任意状态可「标记阻塞」或「取消」 */}
                    {task.status !== 'cancelled' && task.status !== 'blocked' && (
                      <CfButton
                        variant="secondary"
                        size="xs"
                        onClick={() => setShowBlockerForm((v) => !v)}
                      >
                        标记阻塞
                      </CfButton>
                    )}

                    {task.status !== 'cancelled' && canCancelTask && (
                      <CfButton
                        variant="ghost"
                        size="xs"
                        onClick={() => executeTransition('cancelled')}
                      >
                        取消任务
                      </CfButton>
                    )}
                  </div>

                  {/* 标记阻塞必填表单（原因 + 所需支持） */}
                  {showBlockerForm && (
                    <div
                      style={{
                        backgroundColor: 'var(--cf-danger-bg)',
                        borderColor: 'var(--cf-danger)',
                      }}
                      className="mt-2 space-y-2 border p-2.5"
                    >
                      <div className="text-[11px] font-semibold text-[var(--cf-danger)]">
                        标记为「已阻塞」（必须填写阻塞原因与所需支持）：
                      </div>
                      <input
                        type="text"
                        value={blockerReasonInput}
                        onChange={(e) => setBlockerReasonInput(e.target.value)}
                        placeholder="必填：阻塞原因（例如：第三方网关证书未下发）"
                        className="h-[26px] w-full border border-[var(--cf-danger-border)] bg-white px-2 text-[11px]"
                      />
                      <input
                        type="text"
                        value={blockerNeedInput}
                        onChange={(e) => setBlockerNeedInput(e.target.value)}
                        placeholder="必填：需要什么支持（例如：需要企业营业执照扫描件）"
                        className="h-[26px] w-full border border-[var(--cf-danger-border)] bg-white px-2 text-[11px]"
                      />
                      <div className="flex justify-end gap-1.5">
                        <CfButton
                          variant="secondary"
                          size="xs"
                          onClick={() => setShowBlockerForm(false)}
                        >
                          取消
                        </CfButton>
                        <CfButton
                          variant="danger"
                          size="xs"
                          onClick={handleConfirmBlocker}
                        >
                          确认标记阻塞
                        </CfButton>
                      </div>
                    </div>
                  )}
                </>
              ) : (
                <div className="text-[11px] text-[var(--cf-text-tertiary)]">
                  观察员只读身份下不显示任何状态流转按钮。
                </div>
              )}
            </div>
          </div>

          {/* ---------------------------------------------------------------
              侧区 2：验收结论面板（仅「待验收」且当前用户有验收权时出现！）
             --------------------------------------------------------------- */}
          {task.status === 'pending_accept' && hasAcceptancePower && !isObserver && (
            <form
              onSubmit={handleSubmitAcceptance}
              style={{
                backgroundColor: 'var(--cf-warning-bg)',
                borderColor: 'var(--cf-warning)',
                boxShadow: 'var(--cf-shadow-card)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="border-2 p-3 text-[12px]"
            >
              <div className="mb-2 flex items-center justify-between border-b border-[var(--cf-warning-border)] pb-1.5">
                <span className="font-bold text-[var(--cf-warning)]">
                  2. 给出人工验收结论（评审裁决权专属）
                </span>
                <span className="font-mono-tabular text-[10px] text-[var(--cf-warning)]">
                  ROLE: {currentRole.toUpperCase()}
                </span>
              </div>

              {/* 通过 / 补充材料 / 退回 三选一 */}
              <div className="mb-2.5 grid grid-cols-3 gap-1.5">
                {(['通过', '补充材料', '退回'] as const).map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setAcceptConclusion(opt)}
                    style={{
                      backgroundColor:
                        acceptConclusion === opt
                          ? opt === '通过'
                            ? 'var(--cf-success)'
                            : opt === '退回'
                              ? 'var(--cf-danger)'
                              : 'var(--cf-warning)'
                          : 'var(--cf-surface-card)',
                      color:
                        acceptConclusion === opt
                          ? 'var(--cf-surface-card)'
                          : 'var(--cf-text-primary)',
                      borderColor: 'var(--cf-border-strong)',
                    }}
                    className="h-[26px] border font-semibold transition-colors"
                  >
                    {opt}
                  </button>
                ))}
              </div>

              {/* 逐条对照结论 */}
              <div className="mb-2.5 space-y-1 border border-[var(--cf-warning-border)] bg-[var(--cf-surface-card)] p-2">
                <div className="text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                  逐条验收标准对照核验：
                </div>
                {task.acceptanceCriteria.map((crit, idx) => (
                  <label
                    key={idx}
                    className="flex cursor-pointer items-start gap-2 text-[11px]"
                  >
                    <input
                      type="checkbox"
                      checked={criterionChecks[idx] ?? true}
                      onChange={(e) =>
                        setCriterionChecks((prev) => ({
                          ...prev,
                          [idx]: e.target.checked,
                        }))
                      }
                      className="mt-0.5 h-3.5 w-3.5 accent-[#0F5257]"
                    />
                    <span className="leading-[16px]">{crit}</span>
                  </label>
                ))}
              </div>

              {/* 补充意见 + 提交 */}
              <textarea
                rows={2}
                value={acceptComment}
                onChange={(e) => setAcceptComment(e.target.value)}
                placeholder="输入人工验收核验意见（如证据哈希核对结果、缺失材料明细）..."
                className="mb-2 w-full border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] p-2 text-[12px]"
              />
              <div className="flex justify-end">
                <button
                  type="submit"
                  style={{
                    backgroundColor: 'var(--cf-primary)',
                    color: 'var(--cf-surface-card)',
                  }}
                  className="h-[28px] px-3 text-[12px] font-semibold"
                >
                  提交验收结论并写入事实层
                </button>
              </div>
            </form>
          )}

          {/* ---------------------------------------------------------------
              侧区 3：派发卡片（仅当任务处于「已就绪」时出现！非已就绪绝不渲染）
             --------------------------------------------------------------- */}
          {task.status === 'ready' && !isObserver && (
            <div
              style={{
                backgroundColor: 'var(--cf-primary-tint)',
                borderColor: 'var(--cf-primary)',
                boxShadow: 'var(--cf-shadow-card)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="border-2 p-3 text-[12px]"
            >
              <div className="mb-2 flex items-center justify-between border-b border-[var(--cf-primary-border)] pb-1.5">
                <div className="flex items-center gap-1.5">
                  <span
                    style={{
                      backgroundColor: 'var(--cf-primary)',
                      color: 'var(--cf-surface-card)',
                    }}
                    className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold"
                  >
                    已就绪专属
                  </span>
                  <span className="font-bold text-[var(--cf-primary)]">
                    派发给本地 Agent 端点
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setNoEndpointsDemo((v) => !v)}
                  className="font-mono-tabular text-[10px] text-[var(--cf-primary)] underline"
                >
                  {noEndpointsDemo ? '[恢复可用端点]' : '[模拟无可用端点]'}
                </button>
              </div>

              {noEndpointsDemo ? (
                <div
                  style={{
                    backgroundColor: 'var(--cf-surface-card)',
                    borderColor: 'var(--cf-border-strong)',
                  }}
                  className="border p-3 text-center"
                >
                  <div className="font-semibold text-[var(--cf-text-primary)]">
                    当前项目暂无可用的本地 Agent 端点
                  </div>
                  <p className="mt-1 text-[11px] text-[var(--cf-text-secondary)]">
                    请前往工作台「Agent 连接」面板运行本地连接器绑定工具后再派发。
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {DISPATCH_CANDIDATES.map((cand) => {
                    const isSelected = selectedEndpointId === cand.id
                    return (
                      <div
                        key={cand.id}
                        onClick={() => setSelectedEndpointId(cand.id)}
                        style={{
                          backgroundColor: 'var(--cf-surface-card)',
                          borderColor: isSelected
                            ? 'var(--cf-primary)'
                            : 'var(--cf-border-strong)',
                          borderLeftWidth: isSelected ? '4px' : '1px',
                        }}
                        className="cursor-pointer border p-2 transition-colors"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <input
                              type="radio"
                              checked={isSelected}
                              onChange={() => setSelectedEndpointId(cand.id)}
                              className="accent-[#0F5257]"
                            />
                            <span className="font-mono-tabular font-semibold text-[var(--cf-text-primary)]">
                              {cand.toolName}
                            </span>
                            <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                              {cand.version}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <CapabilityBadge level={cand.capability} />
                            <span
                              style={{
                                backgroundColor: cand.recommended
                                  ? 'var(--cf-success-bg)'
                                  : 'var(--cf-surface-secondary)',
                                color: cand.recommended
                                  ? 'var(--cf-success)'
                                  : 'var(--cf-text-secondary)',
                                borderColor: cand.recommended
                                  ? 'var(--cf-success-border)'
                                  : 'var(--cf-border-strong)',
                              }}
                              className="border px-1.5 py-0.5 font-mono-tabular text-[11px] font-bold"
                            >
                              评分 {cand.totalScore}
                            </span>
                          </div>
                        </div>

                        <div className="mt-1 pl-4 text-[11px] text-[var(--cf-text-secondary)]">
                          归属人：{cand.ownerName}
                        </div>

                        {/* 推荐理由与加减分明细 */}
                        <div className="mt-1.5 flex flex-wrap gap-1 pl-4">
                          {cand.reasons.map((r, i) => (
                            <span
                              key={i}
                              style={{
                                backgroundColor: r.positive
                                  ? 'var(--cf-success-bg)'
                                  : 'var(--cf-danger-bg)',
                                color: r.positive
                                  ? 'var(--cf-success)'
                                  : 'var(--cf-danger)',
                                borderColor: r.positive
                                  ? 'var(--cf-success-border)'
                                  : 'var(--cf-danger-border)',
                              }}
                              className="border px-1.5 py-0.5 font-mono-tabular text-[10px] font-medium"
                            >
                              <strong>{r.delta}</strong> {r.text}
                            </span>
                          ))}
                        </div>
                      </div>
                    )
                  })}

                  <div className="pt-1">
                    <button
                      type="button"
                      onClick={handleDispatchToAgent}
                      style={{
                        backgroundColor: 'var(--cf-primary)',
                        color: 'var(--cf-surface-card)',
                      }}
                      className="h-[30px] w-full font-semibold hover:bg-[var(--cf-primary-deep)]"
                    >
                      派发给 Agent
                    </button>
                    <p className="mt-1.5 text-[11px] leading-[16px] text-[var(--cf-primary-deep)]">
                      <strong>说明：</strong>
                      派发不等于开工。连接器领取后任务才进入进行中，且只能提交到待验收。
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ---------------------------------------------------------------
              侧区 4：当前租约（若有：状态[待领取/已接受/执行中]、上下文编号、过期时间）
             --------------------------------------------------------------- */}
          {task.currentLease && (
            <div
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-primary)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="border p-3 text-[12px]"
            >
              <div className="mb-1.5 flex items-center justify-between">
                <span className="font-bold text-[var(--cf-text-primary)]">
                  当前 Agent 租约 (Active Lease)
                </span>
                <span
                  style={{
                    backgroundColor: 'var(--cf-primary)',
                    color: 'var(--cf-surface-card)',
                  }}
                  className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold"
                >
                  状态：{task.currentLease.status}
                </span>
              </div>
              <div className="space-y-1 font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                <div>绑定端点：{task.currentLease.endpointName}</div>
                <div>
                  上下文编号：
                  <strong className="text-[var(--cf-primary)]">
                    {task.currentLease.contextId}
                  </strong>
                </div>
                <div>过期时间：{task.currentLease.expiresAt}</div>
              </div>
            </div>
          )}

          {/* ---------------------------------------------------------------
              侧区 5：提交产物（类型、名称、位置、版本、是否同时提交验收）
             --------------------------------------------------------------- */}
          {!isObserver && (
            <form
              onSubmit={handleSubmitArtifact}
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-border-strong)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="border p-3 text-[12px]"
            >
              <div className="mb-2 font-bold text-[var(--cf-text-primary)]">
                提交产物与证据 (Submit Artifact)
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="mb-0.5 block text-[11px] text-[var(--cf-text-secondary)]">
                    产物类型
                  </label>
                  <select
                    value={artType}
                    onChange={(e) =>
                      setArtType(e.target.value as TaskArtifactItem['type'])
                    }
                    className="h-[26px] w-full border border-[var(--cf-border-strong)] bg-white px-2 text-[11px]"
                  >
                    <option value="评测报告">评测报告</option>
                    <option value="代码补丁">代码补丁</option>
                    <option value="数据集快照">数据集快照</option>
                    <option value="联调日志">联调日志</option>
                    <option value="设计文档">设计文档</option>
                  </select>
                </div>
                <div>
                  <label className="mb-0.5 block text-[11px] text-[var(--cf-text-secondary)]">
                    版本号
                  </label>
                  <input
                    type="text"
                    value={artVersion}
                    onChange={(e) => setArtVersion(e.target.value)}
                    className="font-mono-tabular h-[26px] w-full border border-[var(--cf-border-strong)] px-2 text-[11px]"
                  />
                </div>
              </div>

              <div className="mt-2">
                <label className="mb-0.5 block text-[11px] text-[var(--cf-text-secondary)]">
                  产物名称
                </label>
                <input
                  type="text"
                  value={artName}
                  onChange={(e) => setArtName(e.target.value)}
                  placeholder="例如：hybrid_pareto_v1.csv"
                  className="font-mono-tabular h-[26px] w-full border border-[var(--cf-border-strong)] px-2 text-[11px]"
                />
              </div>

              <div className="mt-2">
                <label className="mb-0.5 block text-[11px] text-[var(--cf-text-secondary)]">
                  位置（提交号 / 仓库路径 / 归档链接）
                </label>
                <input
                  type="text"
                  value={artLocation}
                  onChange={(e) => setArtLocation(e.target.value)}
                  placeholder="例如：artifacts/eval/hybrid_pareto_v1.csv (#c82f10)"
                  className="font-mono-tabular h-[26px] w-full border border-[var(--cf-border-strong)] px-2 text-[11px]"
                />
              </div>

              <div className="mt-2 flex items-center justify-between pt-1">
                <label className="flex cursor-pointer items-center gap-1.5 text-[11px]">
                  <input
                    type="checkbox"
                    checked={submitWithAcceptance}
                    onChange={(e) => setSubmitWithAcceptance(e.target.checked)}
                    className="h-3.5 w-3.5 accent-[#0F5257]"
                  />
                  <span>同时将任务提交至「待验收」</span>
                </label>
                <CfButton variant="primary" size="xs" onClick={() => {}}>
                  <span onClick={handleSubmitArtifact}>登记产物</span>
                </CfButton>
              </div>
            </form>
          )}

          {/* ---------------------------------------------------------------
              侧区 6：前置依赖（状态 + 标题） & 任务元信息
             --------------------------------------------------------------- */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="border p-3 text-[12px]"
          >
            <div className="mb-2 font-bold text-[var(--cf-text-primary)]">
              前置依赖 ({task.dependencies.length})
            </div>
            {task.dependencies.length === 0 ? (
              <div className="text-[11px] text-[var(--cf-text-tertiary)]">
                无前置依赖任务。
              </div>
            ) : (
              <div className="space-y-1.5">
                {task.dependencies.map((dep) => (
                  <div
                    key={dep.id}
                    onClick={() => handleSwitchTask(dep.id)}
                    className="flex cursor-pointer items-center justify-between gap-2 border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)] px-2 py-1 hover:border-[var(--cf-primary)]"
                  >
                    <div className="flex min-w-0 items-center gap-1.5">
                      <TaskStatusBadge status={dep.status} size="compact" />
                      <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]">
                        {dep.id}
                      </span>
                      <span className="truncate text-[11px] text-[var(--cf-text-primary)]">
                        {dep.title}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* 元信息：任务 ID、定义版本、返工轮次、创建/更新时间、所属项目 */}
            <div className="mt-3 border-t border-[var(--cf-border-subtle)] pt-2.5">
              <div className="mb-1.5 font-bold text-[var(--cf-text-primary)]">
                元信息 (Metadata)
              </div>
              <div className="flex flex-wrap gap-1.5">
                <KeyValueTag k="任务 ID" v={task.id} highlight />
                <KeyValueTag k="定义版本" v={`v${task.definitionVersion}`} />
                <KeyValueTag k="返工轮次" v={`R${task.reworkRound}`} />
                <KeyValueTag k="创建" v={task.createdAt} />
                <KeyValueTag k="更新" v={task.updatedAt} />
                <KeyValueTag k="所属项目" v={task.projectName} mono={false} />
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  )
}
