import { useState } from 'react'
import {
  CfButton,
  SingleAvatar,
  RoleType,
} from '../design-system/components'
import {
  PROJECT_TEMPLATES,
  ProjectTemplateSpec,
  INITIAL_MEMBER_ACCOUNTS,
  ProjectSummaryItem,
} from '../data/mockProjects'

interface NewProjectWizardPageProps {
  onCancel: () => void
  onProjectCreated: (newProject: ProjectSummaryItem) => void
}

const WIZARD_STEPS = [
  { step: 1, title: '第 1 步 · 基本信息', short: '基本信息' },
  { step: 2, title: '第 2 步 · 目标与范围', short: '目标与范围' },
  { step: 3, title: '第 3 步 · 验收标准', short: '验收标准' },
  { step: 4, title: '第 4 步 · 成员与角色', short: '成员与角色' },
  { step: 5, title: '第 5 步 · Agent 接入', short: 'Agent 接入' },
]

export function NewProjectWizardPage({
  onCancel,
  onProjectCreated,
}: NewProjectWizardPageProps) {
  const [currentStep, setCurrentStep] = useState<number>(1)
  const [selectedTemplateId, setSelectedTemplateId] =
    useState<ProjectTemplateSpec['id']>('software')

  // 第 1 步字段
  const defaultTpl = PROJECT_TEMPLATES[1]
  const [projectName, setProjectName] = useState(defaultTpl.defaultProjectName)
  const [projectCode, setProjectCode] = useState(defaultTpl.defaultCode)
  const [oneLiner, setOneLiner] = useState(defaultTpl.defaultOneLiner)

  // 第 2 步字段
  const [goal, setGoal] = useState(defaultTpl.goal)
  const [targetUsers, setTargetUsers] = useState(defaultTpl.targetUsers)
  const [scope, setScope] = useState(defaultTpl.scope)
  const [nonGoals, setNonGoals] = useState(defaultTpl.nonGoals)
  const [constraints, setConstraints] = useState(defaultTpl.constraints)

  // 第 3 步字段
  const [acceptanceCriteria, setAcceptanceCriteria] = useState(
    defaultTpl.acceptanceCriteria
  )
  const [firstMilestone, setFirstMilestone] = useState('M1 · 基础章程锁定与核心原型验证')

  // 第 4 步字段：可勾选成员列表与角色下拉（负责人 / 成员 / 评审 / 观察员）
  const [selectedMembers, setSelectedMembers] = useState<
    Record<string, { checked: boolean; role: Exclude<RoleType, 'initiator'> }>
  >({
    m2: { checked: true, role: 'owner' },
    m3: { checked: true, role: 'reviewer' },
    m4: { checked: true, role: 'member' },
    m5: { checked: false, role: 'member' },
    m6: { checked: true, role: 'observer' },
  })

  // 第 5 步状态：创建中 / 失败显示原因
  const [isCreating, setIsCreating] = useState(false)
  const [simulateError, setSimulateError] = useState(false)
  const [createErrorReason, setCreateErrorReason] = useState<string | null>(null)

  const currentTemplate =
    PROJECT_TEMPLATES.find((t) => t.id === selectedTemplateId) || PROJECT_TEMPLATES[0]

  // 选择模板时自动预填章程与任务清单（空白项目则清空，方便测试未填完不可点下一步）
  const handleSelectTemplate = (tpl: ProjectTemplateSpec) => {
    setSelectedTemplateId(tpl.id)
    setProjectName(tpl.defaultProjectName)
    setProjectCode(tpl.defaultCode)
    setOneLiner(tpl.defaultOneLiner)
    setGoal(tpl.goal)
    setTargetUsers(tpl.targetUsers)
    setScope(tpl.scope)
    setNonGoals(tpl.nonGoals)
    setConstraints(tpl.constraints)
    setAcceptanceCriteria(tpl.acceptanceCriteria)
  }

  // 各步骤表单完整度校验（决定「下一步」是否可点）
  const codeValid = /^[A-Z0-9]{2,6}$/.test(projectCode.trim())
  const isStep1Valid =
    projectName.trim().length > 0 && codeValid && oneLiner.trim().length > 0
  const isStep2Valid =
    goal.trim().length > 0 &&
    targetUsers.trim().length > 0 &&
    scope.trim().length > 0 &&
    nonGoals.trim().length > 0 &&
    constraints.trim().length > 0
  const isStep3Valid =
    acceptanceCriteria.trim().length > 0 &&
    (selectedTemplateId !== 'blank' || firstMilestone.trim().length > 0)
  const isStep4Valid = true // 发起人始终在列

  const canGoNext =
    (currentStep === 1 && isStep1Valid) ||
    (currentStep === 2 && isStep2Valid) ||
    (currentStep === 3 && isStep3Valid) ||
    (currentStep === 4 && isStep4Valid)

  // 提交创建项目
  const handleCreateProject = () => {
    setCreateErrorReason(null)
    setIsCreating(true)

    setTimeout(() => {
      setIsCreating(false)
      if (simulateError) {
        setCreateErrorReason(
          `创建失败：项目代号 [${projectCode}] 在当前组织台账中已存在冲突或事实层写入锁超时，请修改代号或取消「模拟创建失败」后重试。`
        )
        return
      }

      const checkedMembersList = INITIAL_MEMBER_ACCOUNTS.filter(
        (m) => m.isSelf || selectedMembers[m.id]?.checked
      ).map((m) => ({
        id: m.id,
        name: m.name,
        short: m.short,
        kind: 'human' as const,
      }))

      const newPrj: ProjectSummaryItem = {
        id: `prj-${Date.now()}`,
        code: projectCode.trim(),
        stage: '定义',
        name: projectName.trim(),
        goalSummary: goal.trim(),
        progress: 0,
        inProgressCount: 0,
        pendingAcceptCount: 0,
        blockedCount: 0,
        members: checkedMembersList,
        lastActiveTime: '刚刚创建',
      }

      onProjectCreated(newPrj)
    }, 600)
  }

  const checkedMemberCount =
    1 +
    Object.values(selectedMembers).filter((item) => item.checked).length

  return (
    <div className="flex h-full w-full flex-col overflow-y-auto select-text">
      {/* =====================================================================
          顶部向导头与 5 步进度条（已完成步骤显示勾选 ✓）
         ===================================================================== */}
      <div
        style={{
          backgroundColor: 'var(--cf-surface-card)',
          borderBottom: '1px solid var(--cf-border-strong)',
        }}
        className="shrink-0 px-6 py-3.5"
      >
        <div className="mx-auto max-w-[1120px]">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={onCancel}
                className="text-[12px] font-semibold text-[var(--cf-primary)] hover:underline"
              >
                ← 返回项目大厅
              </button>
              <span className="text-[var(--cf-border-strong)]">|</span>
              <h1 className="text-[16px] font-bold text-[var(--cf-text-primary)]">
                新建项目（5 步向导：把想法变成结构化的章程和第一批任务）
              </h1>
            </div>

            {/* 快速跳步预览器（方便评审直接点看任意一步） */}
            <div className="flex items-center gap-1 text-[11px]">
              <span className="text-[var(--cf-text-tertiary)]">快速跳步检视:</span>
              {[1, 2, 3, 4, 5].map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setCurrentStep(s)}
                  style={{
                    backgroundColor:
                      currentStep === s
                        ? 'var(--cf-primary)'
                        : 'var(--cf-surface-secondary)',
                    color:
                      currentStep === s
                        ? 'var(--cf-surface-card)'
                        : 'var(--cf-text-secondary)',
                    borderColor: 'var(--cf-border-strong)',
                  }}
                  className="h-[22px] border px-2 font-mono-tabular font-semibold"
                >
                  Step {s}
                </button>
              ))}
            </div>
          </div>

          {/* 5 步指示条（已完成步骤显示勾选 ✓） */}
          <div className="mt-3 grid grid-cols-5 gap-2">
            {WIZARD_STEPS.map((item) => {
              const isDone = item.step < currentStep
              const isCurrent = item.step === currentStep
              return (
                <div
                  key={item.step}
                  onClick={() => {
                    if (isDone) setCurrentStep(item.step)
                  }}
                  style={{
                    backgroundColor: isCurrent
                      ? 'var(--cf-primary-tint)'
                      : isDone
                        ? 'var(--cf-success-bg)'
                        : 'var(--cf-surface-secondary)',
                    borderColor: isCurrent
                      ? 'var(--cf-primary)'
                      : isDone
                        ? 'var(--cf-success)'
                        : 'var(--cf-border-strong)',
                    borderLeftWidth: isCurrent || isDone ? '3px' : '1px',
                  }}
                  className={`flex items-center justify-between border px-3 py-2 text-[12px] ${
                    isDone ? 'cursor-pointer' : ''
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span
                      style={{
                        backgroundColor: isDone
                          ? 'var(--cf-success)'
                          : isCurrent
                            ? 'var(--cf-primary)'
                            : 'var(--cf-surface-tertiary)',
                        color:
                          isDone || isCurrent
                            ? 'var(--cf-surface-card)'
                            : 'var(--cf-text-secondary)',
                      }}
                      className="inline-flex h-[18px] w-[18px] shrink-0 items-center justify-center font-mono-tabular text-[10px] font-bold"
                    >
                      {isDone ? '✓' : item.step}
                    </span>
                    <span
                      className={`truncate font-semibold ${
                        isCurrent
                          ? 'text-[var(--cf-primary)]'
                          : isDone
                            ? 'text-[var(--cf-success)]'
                            : 'text-[var(--cf-text-secondary)]'
                      }`}
                    >
                      {item.short}
                    </span>
                  </div>
                  {isDone && (
                    <span className="font-mono-tabular text-[10px] font-semibold text-[var(--cf-success)]">
                      已完成
                    </span>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {/* =====================================================================
          向导主表单卡片
         ===================================================================== */}
      <div className="mx-auto flex-1 w-full max-w-[1120px] px-6 py-5">
        <div
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="border p-6"
        >
          {/* -----------------------------------------------------------------
              第 1 步 · 基本信息（模板选择放在最上面 + 项目名称、代号、一句话说明）
             ----------------------------------------------------------------- */}
          {currentStep === 1 && (
            <div className="space-y-5">
              <div>
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <h2 className="text-[15px] font-bold text-[var(--cf-text-primary)]">
                    模板选择（只预填章程与任务清单，之后随便改）
                  </h2>
                  <span className="font-mono-tabular text-[11px] text-[var(--cf-primary)]">
                    点选「空白项目」可体验清空必填项后「下一步」不可点的禁用态
                  </span>
                </div>

                {/* 四张可点选模板卡片：空白项目、软件小团队(6个任务)、内容创作(6个任务)、竞赛项目(6个任务) */}
                <div className="mt-2.5 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  {PROJECT_TEMPLATES.map((tpl) => {
                    const isSelected = selectedTemplateId === tpl.id
                    return (
                      <div
                        key={tpl.id}
                        onClick={() => handleSelectTemplate(tpl)}
                        style={{
                          backgroundColor: isSelected
                            ? 'var(--cf-primary-tint)'
                            : 'var(--cf-surface-secondary)',
                          borderColor: isSelected
                            ? 'var(--cf-primary)'
                            : 'var(--cf-border-strong)',
                          borderTopWidth: isSelected ? '3px' : '1px',
                        }}
                        className="flex cursor-pointer flex-col justify-between border p-3.5 transition-all"
                      >
                        <div>
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-[14px] font-bold text-[var(--cf-text-primary)]">
                              {tpl.name}
                            </span>
                            <span
                              style={{
                                backgroundColor: isSelected
                                  ? 'var(--cf-primary)'
                                  : 'var(--cf-surface-card)',
                                color: isSelected
                                  ? 'var(--cf-surface-card)'
                                  : 'var(--cf-text-secondary)',
                                borderColor: 'var(--cf-border-strong)',
                              }}
                              className="border px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold"
                            >
                              {tpl.taskCount === 0
                                ? '0 个预置任务'
                                : `${tpl.taskCount} 个任务`}
                            </span>
                          </div>
                          <p className="mt-1.5 text-[12px] leading-[17px] text-[var(--cf-text-secondary)]">
                            {tpl.description}
                          </p>
                        </div>
                        <div className="mt-3 flex items-center justify-between border-t border-[var(--cf-border-subtle)] pt-1.5 font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                          <span>{isSelected ? '● 当前已选' : '○ 点击选用'}</span>
                          <span>只预填章程与任务清单，之后随便改</span>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>

              {/* 项目名称、项目代号（2-6 位大写字母或数字）、一句话说明 */}
              <div className="border-t border-[var(--cf-border-subtle)] pt-4 space-y-4">
                <div className="grid grid-cols-1 gap-4 md:grid-cols-12">
                  <div className="md:col-span-8">
                    <label className="mb-1 block text-[12px] font-semibold text-[var(--cf-text-primary)]">
                      项目名称 <span className="text-[var(--cf-danger)]">*</span>
                    </label>
                    <input
                      type="text"
                      value={projectName}
                      onChange={(e) => setProjectName(e.target.value)}
                      placeholder="请输入项目全称，例如：轻量级多 Agent 检索服务与接口联调"
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: projectName.trim()
                          ? 'var(--cf-border-strong)'
                          : 'var(--cf-warning)',
                      }}
                      className="h-[34px] w-full border px-3 text-[13px] outline-none focus:border-[var(--cf-primary)]"
                    />
                  </div>

                  <div className="md:col-span-4">
                    <label className="mb-1 flex items-center justify-between text-[12px] font-semibold text-[var(--cf-text-primary)]">
                      <span>
                        项目代号 <span className="text-[var(--cf-danger)]">*</span>
                      </span>
                      <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                        2–6 位大写字母或数字
                      </span>
                    </label>
                    <input
                      type="text"
                      maxLength={6}
                      value={projectCode}
                      onChange={(e) => setProjectCode(e.target.value.toUpperCase())}
                      placeholder="如 ZX 或 SW01"
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: codeValid
                          ? 'var(--cf-border-strong)'
                          : 'var(--cf-danger)',
                      }}
                      className="font-mono-tabular h-[34px] w-full border px-3 text-[13px] font-bold uppercase outline-none focus:border-[var(--cf-primary)]"
                    />
                    {!codeValid && (
                      <span className="mt-1 block text-[11px] text-[var(--cf-danger)]">
                        需为 2–6 位大写英文字母或数字（用于任务编号前缀）
                      </span>
                    )}
                  </div>
                </div>

                <div>
                  <label className="mb-1 block text-[12px] font-semibold text-[var(--cf-text-primary)]">
                    一句话说明 <span className="text-[var(--cf-danger)]">*</span>
                  </label>
                  <input
                    type="text"
                    value={oneLiner}
                    onChange={(e) => setOneLiner(e.target.value)}
                    placeholder="用一句话概括这个项目要解决什么核心问题..."
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: oneLiner.trim()
                        ? 'var(--cf-border-strong)'
                        : 'var(--cf-warning)',
                    }}
                    className="h-[34px] w-full border px-3 text-[13px] outline-none focus:border-[var(--cf-primary)]"
                  />
                </div>
              </div>
            </div>
          )}

          {/* -----------------------------------------------------------------
              第 2 步 · 目标与范围（项目目标、目标用户、交付范围、非目标、硬性约束）
             ----------------------------------------------------------------- */}
          {currentStep === 2 && (
            <div className="space-y-3.5 text-[12px]">
              <div className="border-b border-[var(--cf-border-subtle)] pb-2">
                <h2 className="text-[15px] font-bold text-[var(--cf-text-primary)]">
                  第 2 步 · 目标与范围（写入 L0 稳定层章程，所有 Agent 每次执行必读）
                </h2>
              </div>

              <div className="grid grid-cols-1 gap-3.5 md:grid-cols-2">
                <div>
                  <label className="mb-1 block font-semibold text-[var(--cf-text-primary)]">
                    1. 项目目标 <span className="text-[var(--cf-danger)]">*</span>
                  </label>
                  <textarea
                    rows={2}
                    value={goal}
                    onChange={(e) => setGoal(e.target.value)}
                    placeholder="明确可量化的项目最终目标..."
                    className="w-full border border-[var(--cf-border-strong)] p-2.5 text-[13px]"
                  />
                </div>

                <div>
                  <label className="mb-1 block font-semibold text-[var(--cf-text-primary)]">
                    2. 目标用户 <span className="text-[var(--cf-danger)]">*</span>
                  </label>
                  <textarea
                    rows={2}
                    value={targetUsers}
                    onChange={(e) => setTargetUsers(e.target.value)}
                    placeholder="交付成果面向的使用者、评审或客户..."
                    className="w-full border border-[var(--cf-border-strong)] p-2.5 text-[13px]"
                  />
                </div>
              </div>

              <div>
                <label className="mb-1 block font-semibold text-[var(--cf-text-primary)]">
                  3. 交付范围 (In-Scope) <span className="text-[var(--cf-danger)]">*</span>
                </label>
                <textarea
                  rows={2}
                  value={scope}
                  onChange={(e) => setScope(e.target.value)}
                  placeholder="列出必须交付的核心源码、文档、数据集或演示系统..."
                  className="w-full border border-[var(--cf-border-strong)] p-2.5 text-[13px]"
                />
              </div>

              <div className="grid grid-cols-1 gap-3.5 md:grid-cols-2">
                <div>
                  <label className="mb-1 block font-semibold text-[var(--cf-text-primary)]">
                    4. 非目标 (Non-Goals · 防止范围蔓延){' '}
                    <span className="text-[var(--cf-danger)]">*</span>
                  </label>
                  <textarea
                    rows={2}
                    value={nonGoals}
                    onChange={(e) => setNonGoals(e.target.value)}
                    placeholder="明确本期不做哪些事，防止成员或 Agent 消耗额外预算..."
                    className="w-full border border-[var(--cf-border-strong)] p-2.5 text-[13px]"
                  />
                </div>

                <div>
                  <label className="mb-1 block font-semibold text-[var(--cf-danger)]">
                    5. 硬性约束 (Hard Constraints) <span className="text-[var(--cf-danger)]">*</span>
                  </label>
                  <textarea
                    rows={2}
                    value={constraints}
                    onChange={(e) => setConstraints(e.target.value)}
                    placeholder="性能红线、算力/内存限制、数据安全脱敏要求..."
                    className="w-full border border-[var(--cf-danger-border)] bg-[var(--cf-danger-bg)]/30 p-2.5 text-[13px]"
                  />
                </div>
              </div>
            </div>
          )}

          {/* -----------------------------------------------------------------
              第 3 步 · 验收标准（多行验收标准；若选了模板显示模板说明替代首个里程碑，否则显示首个里程碑输入）
             ----------------------------------------------------------------- */}
          {currentStep === 3 && (
            <div className="space-y-4 text-[12px]">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--cf-border-subtle)] pb-2">
                <h2 className="text-[15px] font-bold text-[var(--cf-text-primary)]">
                  第 3 步 · 验收标准与里程碑初始化
                </h2>
                <div className="flex items-center gap-2 text-[11px]">
                  <span className="text-[var(--cf-text-tertiary)]">切换预览条件分支:</span>
                  <button
                    type="button"
                    onClick={() => handleSelectTemplate(PROJECT_TEMPLATES[1])}
                    className={`border px-2 py-0.5 ${
                      selectedTemplateId !== 'blank'
                        ? 'border-[var(--cf-primary)] bg-[var(--cf-primary-tint)] font-semibold text-[var(--cf-primary)]'
                        : 'border-[var(--cf-border-strong)]'
                    }`}
                  >
                    已选模板态（显示模板生成说明）
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedTemplateId('blank')
                      if (!acceptanceCriteria) {
                        setAcceptanceCriteria('1. 所有交付物附带可复现验证日志与人工签批记录')
                      }
                    }}
                    className={`border px-2 py-0.5 ${
                      selectedTemplateId === 'blank'
                        ? 'border-[var(--cf-primary)] bg-[var(--cf-primary-tint)] font-semibold text-[var(--cf-primary)]'
                        : 'border-[var(--cf-border-strong)]'
                    }`}
                  >
                    空白项目态（显示首个里程碑输入）
                  </button>
                </div>
              </div>

              <div>
                <label className="mb-1 block font-semibold text-[var(--cf-primary)]">
                  项目级验收标准（多行，每行一条法定核验口径）{' '}
                  <span className="text-[var(--cf-danger)]">*</span>
                </label>
                <textarea
                  rows={4}
                  value={acceptanceCriteria}
                  onChange={(e) => setAcceptanceCriteria(e.target.value)}
                  placeholder="请输入项目整体验收标准（每行一条）..."
                  style={{
                    backgroundColor: 'var(--cf-primary-tint)',
                    borderColor: 'var(--cf-primary)',
                  }}
                  className="w-full border p-3 text-[13px] font-medium leading-[20px]"
                />
              </div>

              {/* 条件分支：若选了模板，显示模板说明（将生成哪些里程碑和任务）替代"首个里程碑"输入；否则显示"首个里程碑"输入 */}
              {selectedTemplateId !== 'blank' ? (
                <div
                  style={{
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderColor: 'var(--cf-border-strong)',
                    borderLeft: '4px solid var(--cf-primary)',
                  }}
                  className="border p-4"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[13px] font-bold text-[var(--cf-primary)]">
                      模板说明：已选用「{currentTemplate.name}」模板（自动替代手动输入首个里程碑）
                    </span>
                    <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                      将自动生成 {currentTemplate.milestonePreview.length} 个里程碑 ·{' '}
                      {currentTemplate.taskCount} 项初始任务
                    </span>
                  </div>

                  <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-12">
                    <div className="md:col-span-4 space-y-1.5">
                      <div className="text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                        将自动生成的里程碑：
                      </div>
                      {currentTemplate.milestonePreview.map((ms, i) => (
                        <div
                          key={i}
                          className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] px-2.5 py-1.5 font-semibold text-[var(--cf-text-primary)]"
                        >
                          {ms}
                        </div>
                      ))}
                    </div>

                    <div className="md:col-span-8">
                      <div className="mb-1.5 text-[11px] font-semibold text-[var(--cf-text-secondary)]">
                        将自动生成的 6 个初始任务清单：
                      </div>
                      <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                        {currentTemplate.taskPreview.map((tsk, i) => (
                          <div
                            key={i}
                            className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] px-2.5 py-1 font-mono-tabular text-[11px] text-[var(--cf-text-primary)]"
                          >
                            {tsk}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div
                  style={{
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderColor: 'var(--cf-border-strong)',
                  }}
                  className="border p-4"
                >
                  <label className="mb-1 block text-[13px] font-bold text-[var(--cf-text-primary)]">
                    首个里程碑名称（空白项目必填） <span className="text-[var(--cf-danger)]">*</span>
                  </label>
                  <input
                    type="text"
                    value={firstMilestone}
                    onChange={(e) => setFirstMilestone(e.target.value)}
                    placeholder="例如：M1 · 基础章程锁定与核心原型验证"
                    className="h-[34px] w-full border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] px-3 text-[13px]"
                  />
                </div>
              )}
            </div>
          )}

          {/* -----------------------------------------------------------------
              第 4 步 · 成员与角色
              发起人固定为当前用户（目标决策权+最终验收权）；可勾选成员列表+角色下拉；底部一句箴言
             ----------------------------------------------------------------- */}
          {currentStep === 4 && (
            <div className="space-y-4 text-[12px]">
              <div className="border-b border-[var(--cf-border-subtle)] pb-2">
                <h2 className="text-[15px] font-bold text-[var(--cf-text-primary)]">
                  第 4 步 · 成员与角色配置
                </h2>
              </div>

              {/* 发起人固定为当前用户 */}
              <div
                style={{
                  backgroundColor: 'var(--cf-primary-tint)',
                  borderColor: 'var(--cf-primary)',
                  borderLeftWidth: '4px',
                }}
                className="flex flex-wrap items-center justify-between gap-2 border p-3"
              >
                <div className="flex items-center gap-2.5">
                  <input
                    type="checkbox"
                    checked
                    disabled
                    className="h-4 w-4"
                  />
                  <SingleAvatar
                    item={{ id: 'm1', name: '林知夏', short: '林', kind: 'human' }}
                    size={26}
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[13px] font-bold text-[var(--cf-text-primary)]">
                        林知夏（当前用户 · 固定为发起人）
                      </span>
                      <span className="font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                        linzhixia@coflow.dev
                      </span>
                    </div>
                    <div className="mt-0.5 text-[11px] font-semibold text-[var(--cf-primary)]">
                      权限说明：目标决策权 + 最终验收权
                    </div>
                  </div>
                </div>
                <span
                  style={{
                    backgroundColor: 'var(--cf-primary)',
                    color: 'var(--cf-surface-card)',
                  }}
                  className="px-2 py-0.5 font-mono-tabular text-[11px] font-semibold"
                >
                  发起人 (INITIATOR · 锁定)
                </span>
              </div>

              {/* 可勾选成员列表（勾选后出现角色下拉：负责人 / 成员 / 评审 / 观察员） */}
              <div className="divide-y divide-[var(--cf-border-subtle)] border border-[var(--cf-border-strong)]">
                {INITIAL_MEMBER_ACCOUNTS.filter((m) => !m.isSelf).map((member) => {
                  const state = selectedMembers[member.id] || {
                    checked: false,
                    role: 'member' as const,
                  }
                  return (
                    <div
                      key={member.id}
                      style={{
                        backgroundColor: state.checked
                          ? 'var(--cf-surface-card)'
                          : 'var(--cf-surface-secondary)',
                      }}
                      className="flex flex-wrap items-center justify-between gap-3 px-3.5 py-2.5"
                    >
                      <label className="flex cursor-pointer items-center gap-2.5">
                        <input
                          type="checkbox"
                          checked={state.checked}
                          onChange={(e) =>
                            setSelectedMembers((prev) => ({
                              ...prev,
                              [member.id]: {
                                ...state,
                                checked: e.target.checked,
                              },
                            }))
                          }
                          className="h-4 w-4 accent-[#0F5257]"
                        />
                        <SingleAvatar
                          item={{
                            id: member.id,
                            name: member.name,
                            short: member.short,
                            kind: 'human',
                          }}
                          size={24}
                        />
                        <span className="text-[13px] font-semibold text-[var(--cf-text-primary)]">
                          {member.name}
                        </span>
                        <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                          {member.account}
                        </span>
                      </label>

                      {state.checked ? (
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] text-[var(--cf-text-secondary)]">
                            分配角色:
                          </span>
                          <select
                            value={state.role}
                            onChange={(e) =>
                              setSelectedMembers((prev) => ({
                                ...prev,
                                [member.id]: {
                                  ...state,
                                  role: e.target.value as Exclude<
                                    RoleType,
                                    'initiator'
                                  >,
                                },
                              }))
                            }
                            className="h-[26px] border border-[var(--cf-primary)] bg-[var(--cf-surface-card)] px-2 text-[12px] font-semibold text-[var(--cf-primary)]"
                          >
                            <option value="owner">负责人</option>
                            <option value="member">成员</option>
                            <option value="reviewer">评审</option>
                            <option value="observer">观察员</option>
                          </select>
                        </div>
                      ) : (
                        <span className="text-[11px] text-[var(--cf-text-muted)]">
                          未勾选加入本项目
                        </span>
                      )}
                    </div>
                  )
                })}
              </div>

              {/* 底部一句 */}
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderColor: 'var(--cf-border-strong)',
                  borderLeft: '3px solid var(--cf-primary)',
                }}
                className="border px-3 py-2 text-[12px] font-semibold text-[var(--cf-text-primary)]"
              >
                角色决定的是事实层的写入权限，不是头衔。
              </div>
            </div>
          )}

          {/* -----------------------------------------------------------------
              第 5 步 · Agent 接入
              零密钥接入说明（工具授权归原工具、项目授权归 CoFlow）+ "本次创建将写入"清单（项目、章程、成员、模板、事件）+ 「创建项目」按钮
             ----------------------------------------------------------------- */}
          {currentStep === 5 && (
            <div className="space-y-4 text-[12px]">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--cf-border-subtle)] pb-2">
                <h2 className="text-[15px] font-bold text-[var(--cf-text-primary)]">
                  第 5 步 · Agent 接入与事实层写入确认
                </h2>
                <label className="flex cursor-pointer items-center gap-1.5 text-[11px] text-[var(--cf-danger)]">
                  <input
                    type="checkbox"
                    checked={simulateError}
                    onChange={(e) => setSimulateError(e.target.checked)}
                    className="h-3.5 w-3.5 accent-[#B91C1C]"
                  />
                  <span>模拟创建失败（检验错误原因提示态）</span>
                </label>
              </div>

              {/* 零密钥接入说明：工具授权归原工具、项目授权归 CoFlow */}
              <div
                style={{
                  backgroundColor: 'var(--cf-primary-tint)',
                  borderColor: 'var(--cf-primary)',
                  borderLeftWidth: '4px',
                }}
                className="border p-3.5"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[13px] font-bold text-[var(--cf-primary)]">
                    零密钥接入机制：工具授权归原工具、项目授权归 CoFlow
                  </span>
                  <span className="font-mono-tabular text-[10px] font-semibold text-[var(--cf-primary)]">
                    ZERO-KEY ARCHITECTURE
                  </span>
                </div>
                <p className="mt-1 text-[12px] leading-[18px] text-[var(--cf-text-secondary)]">
                  CoFlow 绝不读取、不托管成员的大模型 API Key。成员电脑上的 Cursor、Claude Code 或 Windsurf 使用各自原有的模型凭证运行，通过本地连接器接入本项目后，由 CoFlow 下发受目录白名单约束的上下文包与任务租约。
                </p>
              </div>

              {/* 失败显示原因 */}
              {createErrorReason && (
                <div
                  style={{
                    backgroundColor: 'var(--cf-danger-bg)',
                    borderColor: 'var(--cf-danger)',
                    borderLeftWidth: '4px',
                    color: 'var(--cf-danger)',
                  }}
                  className="border p-3 font-semibold"
                >
                  {createErrorReason}
                </div>
              )}

              {/* "本次创建将写入"清单：项目、章程、成员、模板、事件 */}
              <div>
                <div className="mb-2 text-[13px] font-bold text-[var(--cf-text-primary)]">
                  「本次创建将写入」事实层清单：
                </div>
                <div className="grid grid-cols-1 gap-2.5 md:grid-cols-5">
                  {[
                    {
                      tag: '1. 项目',
                      title: `${projectName || '未命名'} [${projectCode || '--'}]`,
                      detail: `初始阶段：定义 · ${oneLiner.slice(0, 26)}...`,
                    },
                    {
                      tag: '2. 章程',
                      title: 'CHR-v1.0 基线锁定',
                      detail: '含目标、交付范围、非目标、硬性约束与验收标准五要素',
                    },
                    {
                      tag: '3. 成员',
                      title: `共 ${checkedMemberCount} 名协作席位`,
                      detail: '发起人 林知夏 + 已勾选成员角色权限表写入',
                    },
                    {
                      tag: '4. 模板',
                      title: currentTemplate.name,
                      detail:
                        selectedTemplateId === 'blank'
                          ? `初始化首个里程碑：${firstMilestone}`
                          : `自动生成 ${currentTemplate.milestonePreview.length} 个里程碑与 ${currentTemplate.taskCount} 项任务`,
                    },
                    {
                      tag: '5. 事件',
                      title: '2 条创世系统事件',
                      detail: '写入 #general：[创建项目] 与 [发布章程 CHR-v1.0]',
                    },
                  ].map((w) => (
                    <div
                      key={w.tag}
                      style={{
                        backgroundColor: 'var(--cf-surface-secondary)',
                        borderColor: 'var(--cf-border-strong)',
                      }}
                      className="border p-2.5"
                    >
                      <div className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                        {w.tag}
                      </div>
                      <div className="mt-1 font-semibold text-[var(--cf-text-primary)]">
                        {w.title}
                      </div>
                      <p className="mt-1 text-[11px] leading-[15px] text-[var(--cf-text-secondary)]">
                        {w.detail}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* =================================================================
              底部操作栏（上一步 / 当前步骤未填完时"下一步"不可点 / 创建项目）
             ================================================================= */}
          <div
            style={{ borderColor: 'var(--cf-border-strong)' }}
            className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t pt-4"
          >
            <div className="text-[12px] text-[var(--cf-text-tertiary)]">
              {currentStep < 5 && !canGoNext ? (
                <span className="font-semibold text-[var(--cf-danger)]">
                  [必填未完成] 当前步骤还有必填项未完成（或项目代号格式不符），「下一步」已锁定不可点。
                </span>
              ) : (
                <span>已完成步骤自动标记勾选，可随时回退修改。</span>
              )}
            </div>

            <div className="flex items-center gap-2.5">
              {currentStep > 1 && (
                <CfButton
                  variant="secondary"
                  size="default"
                  onClick={() => setCurrentStep((s) => s - 1)}
                >
                  ← 上一步
                </CfButton>
              )}

              {currentStep < 5 ? (
                <CfButton
                  variant="primary"
                  size="default"
                  visualState={canGoNext ? 'default' : 'disabled'}
                  onClick={() => {
                    if (canGoNext) setCurrentStep((s) => s + 1)
                  }}
                >
                  下一步 →
                </CfButton>
              ) : (
                <CfButton
                  variant="primary"
                  size="default"
                  visualState={isCreating ? 'loading' : 'default'}
                  onClick={handleCreateProject}
                >
                  {isCreating ? '正在写入事实层并创建项目...' : '创建项目'}
                </CfButton>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
