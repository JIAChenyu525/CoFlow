import { useState } from 'react'

const FOUR_PRINCIPLES = [
  {
    code: 'P1 · IMMUTABLE',
    title: '事件不可变',
    desc: '事实层采用只追加（Append-Only）事件日志。任何章程修订、决策推翻或验收退回均通过写入新事件（如 decision.superseded、acceptance.returned）表达，严禁原地篡改或抹除历史事件。',
  },
  {
    code: 'P2 · PROJECTABLE',
    title: '状态可投影',
    desc: '工作台看到的「当前任务状态」「有效章程版本」与「未解决阻塞」均是事件流按序重放（Projection）的确定性结果。任意时刻重放同一段事件流，必然得到完全一致的项目快照。',
  },
  {
    code: 'P3 · VERSIONED',
    title: '写入带版本',
    desc: '所有改变实体状态的写入请求必须携带客户端读取时的基准版本号（base_version）。若服务端当前版本已高于基准版本，立即拒绝写入并返回冲突错误，防止多人或多 Agent 静默覆盖。',
  },
  {
    code: 'P4 · EVIDENCE FIRST',
    title: '证据先于结论',
    desc: '没有绑定可定位产物凭据（提交哈希、相对路径、校验摘要）的完成声明一律无效；Agent 只能上报产物事件并将任务推进至「待验收」，最终「已完成」结论仅接受人类评审角色写入。',
  },
]

const COMMON_FIELDS_13 = [
  {
    idx: 1,
    name: 'event_id',
    type: 'string (ULID)',
    required: '必填',
    desc: '全局唯一、按字典序单调递增的事件标识符',
    example: '"evt_01JVB9X4K8M2R7P3Q5N6T8W9Y0"',
  },
  {
    idx: 2,
    name: 'project_id',
    type: 'string',
    required: '必填',
    desc: '所属项目唯一标识（用于分区隔离与订阅路由）',
    example: '"prj_zx_2025"',
  },
  {
    idx: 3,
    name: 'schema_version',
    type: 'string',
    required: '必填',
    desc: '事件协议结构版本号，首版固定为 1.0',
    example: '"1.0"',
  },
  {
    idx: 4,
    name: 'event_type',
    type: 'enum (12 种)',
    required: '必填',
    desc: '域级点分事件类型名（见下方 12 个首版事件类型清单）',
    example: '"artifact.submitted"',
  },
  {
    idx: 5,
    name: 'occurred_at',
    type: 'ISO-8601 UTC',
    required: '必填',
    desc: '动作在客户端或本地连接器实际发生的物理时间戳',
    example: '"2026-11-12T08:26:12.402Z"',
  },
  {
    idx: 6,
    name: 'recorded_at',
    type: 'ISO-8601 UTC',
    required: '必填',
    desc: '事实层服务端完成乐观锁校验并落盘的权威时间戳',
    example: '"2026-11-12T08:26:12.418Z"',
  },
  {
    idx: 7,
    name: 'actor_type',
    type: 'enum',
    required: '必填',
    desc: '操作主体类别：human（人类成员）| agent（本地连接器）| system（规则引擎）',
    example: '"agent"',
  },
  {
    idx: 8,
    name: 'actor_id',
    type: 'string',
    required: '必填',
    desc: '触发该事件的成员账号 ID 或已授权的 Agent 端点 ID',
    example: '"ep_cursor_win_02"',
  },
  {
    idx: 9,
    name: 'session_id',
    type: 'string | null',
    required: '条件必填',
    desc: '当 actor_type 为 agent 时必填，指向当前有效租约会话编号',
    example: '"ses_91_tsk108"',
  },
  {
    idx: 10,
    name: 'entity_type',
    type: 'enum',
    required: '必填',
    desc: '被作用的事实实体类型：project | charter | task | decision | artifact | device',
    example: '"task"',
  },
  {
    idx: 11,
    name: 'entity_id',
    type: 'string',
    required: '必填',
    desc: '被作用实体的业务主键（如任务编号 TSK-108 或决策编号 DEC-03）',
    example: '"TSK-108"',
  },
  {
    idx: 12,
    name: 'base_version',
    type: 'integer',
    required: '必填',
    desc: '写入前读取到的目标实体版本号，用于乐观并发控制（OCC）',
    example: '3',
  },
  {
    idx: 13,
    name: 'payload_hash',
    type: 'string (SHA-256)',
    required: '必填',
    desc: '事件 payload 规范化 JSON 的 SHA-256 摘要，保障传输与归档完整性',
    example: '"sha256:7b91e0c4f8a2..."',
  },
]

const EVENT_TYPES_12 = [
  {
    idx: '01',
    type: 'project.created',
    domain: '项目与章程',
    actor: 'human (initiator)',
    effect: '初始化项目元数据、成员角色表与创世章程 CHR-v1.0',
  },
  {
    idx: '02',
    type: 'charter.updated',
    domain: '项目与章程',
    actor: 'human (initiator/owner)',
    effect: '章程版本号 +1，记录必填变更说明，并触发全部活跃上下文包 L0 层失效重算',
  },
  {
    idx: '03',
    type: 'task.created',
    domain: '任务状态机',
    actor: 'human',
    effect: '校验输入材料与验收标准：缺项则投影为 clarify（待澄清），齐备则投影为 unclaimed 或 ready',
  },
  {
    idx: '04',
    type: 'task.status_changed',
    domain: '任务状态机',
    actor: 'human / system',
    effect: '按不跳级规则推进主状态（clarify → unclaimed → ready → in_progress → pending_accept）',
  },
  {
    idx: '05',
    type: 'task.blocked',
    domain: '任务状态机',
    actor: 'human / agent',
    effect: '将任务切入旁路 blocked 状态，强制写入阻塞原因与所需外部支持，置顶至工作台风险区',
  },
  {
    idx: '06',
    type: 'decision.proposed',
    domain: '决策治理',
    actor: 'human',
    effect: '从讨论消息提炼或直接新建「决策提案」，进入右区「需要处理」等待裁决',
  },
  {
    idx: '07',
    type: 'decision.confirmed',
    domain: '决策治理',
    actor: 'human (initiator/owner)',
    effect: '将提案正式升格写入事实层 L2 动态层；若指定了被替代决策，自动将旧决策标记为 superseded',
  },
  {
    idx: '08',
    type: 'artifact.submitted',
    domain: '产物与验收',
    actor: 'human / agent',
    effect: '登记带类型、版本、相对路径与 SHA-1 哈希的交付物凭证，挂载至目标任务名下',
  },
  {
    idx: '09',
    type: 'acceptance.recorded',
    domain: '产物与验收',
    actor: 'human (initiator/owner/reviewer)',
    effect: '记录人工逐条验收结论（通过→done；退回→in_progress 且返工轮次 R+1；补充材料→维持或退回）',
  },
  {
    idx: '10',
    type: 'agent.lease_acquired',
    domain: 'Agent 协同',
    actor: 'agent',
    effect: '本地连接器领取已派发租约，锁定上下文快照哈希并将任务由 ready 推进至 in_progress',
  },
  {
    idx: '11',
    type: 'agent.session_reported',
    domain: 'Agent 协同',
    actor: 'agent',
    effect: '上报连接器执行心跳、Token 消耗与终端退出状态，在讨论流折叠渲染为弱化汇报条',
  },
  {
    idx: '12',
    type: 'device.revoked',
    domain: '安全与设备',
    actor: 'human',
    effect: '立即吊销目标设备及下属全部端点的访问令牌，中断在途租约并将设备移入已撤销审计区',
  },
]

const SAMPLE_EVENT_JSON = `{
  "event_id": "evt_01JVB9X4K8M2R7P3Q5N6T8W9Y0",
  "project_id": "prj_zx_2025",
  "schema_version": "1.0",
  "event_type": "artifact.submitted",
  "occurred_at": "2026-11-12T08:26:12.402Z",
  "recorded_at": "2026-11-12T08:26:12.418Z",
  "actor_type": "agent",
  "actor_id": "ep_cursor_win_02",
  "session_id": "ses_91_tsk108",
  "entity_type": "task",
  "entity_id": "TSK-108",
  "base_version": 3,
  "payload_hash": "sha256:7b91e0c4f8a219d04e63b812c904a712e839d012f481a920c381b740e129a0f1",
  "payload": {
    "artifact_id": "ART-108-02",
    "artifact_type": "评测报告",
    "name": "recall_bench_v1.4.csv",
    "version": "v1.4.2-rc",
    "location": "artifacts/eval/recall_bench_v1.4.csv",
    "content_sha1": "7b91e0c4f8a219d04e63b812c904a712e839d012",
    "context_snapshot_id": "SNAP-v3",
    "modified_paths": [
      "src/retrieval/vector_eval.py",
      "artifacts/eval/recall_bench_v1.4.csv"
    ],
    "submit_for_acceptance": true,
    "telemetry": {
      "tokens_consumed": 14820,
      "duration_ms": 228400,
      "exit_code": 0
    }
  }
}`

const CONTEXT_LAYERS_TABLE = [
  {
    layer: 'L0 稳定层',
    content: '项目章程五要素：项目目标、交付范围、非目标、硬性约束、验收口径',
    trimmable: '不可裁剪',
    updatePolicy: '仅当触发 charter.updated 事件时更新版本号并重新计算 L0 哈希；会话执行期间严格锁定',
  },
  {
    layer: 'L1 任务层',
    content: '当前任务契约：标题、说明、输入材料、工作范围、非工作范围、验收标准、前置依赖状态',
    trimmable: '不可裁剪',
    updatePolicy: '任务定义保存（definition_version +1）或前置依赖状态变更时实时刷新；L0+L1 超预算直接阻断派发',
  },
  {
    layer: 'L2 动态层',
    content: '已确认决策（本任务关联项优先）、未解决阻塞（原因+所需支持）、最近 5 条关键变更事件',
    trimmable: '可裁剪（按关联度与时间窗口）',
    updatePolicy: '每次构建上下文包时动态拉取最新已确认事实；若总 Token 逼近 32k 上限，按「历史变更 → 非本任务直接关联决策」顺序裁剪并写入裁剪记录',
  },
  {
    layer: 'L3 证据层',
    content: '允许修改的路径白名单、禁止访问的路径黑名单、提交格式要求、必须回传的内容清单',
    trimmable: '不可裁剪（安全沙箱契约）',
    updatePolicy: '由「Agent 连接」端点授权目录与任务工作范围交集实时计算生成；若交集为空则降级为 READ_ONLY_LOCKED',
  },
]

const AGENT_RETURN_CONTRACTS_7 = [
  {
    no: '合同 01',
    title: '租约与上下文哈希绑定',
    detail:
      '连接器回传任何事件或产物时，必须携带有效的 session_id 与拉取时的 context_snapshot_hash；租约过期或任务已被人工改派时，服务端拒绝接收回传。',
  },
  {
    no: '合同 02',
    title: '写入路径白名单强制校验',
    detail:
      '回传的 modified_paths 必须 100% 落在 L3「允许修改的路径」白名单内且不触碰「禁止访问的路径」；一旦检测到越界修改，整次提交自动拦截并记入「越界修改」失败统计。',
  },
  {
    no: '合同 03',
    title: '产物可定位与哈希完备性',
    detail:
      '禁止回传纯口头文本“我已经改好了”。每项产物必须包含明确的物理相对路径/Commit ID、语义版本号以及文件内容 SHA-1 校验值。',
  },
  {
    no: '合同 04',
    title: '状态机封顶限制（严禁自验收）',
    detail:
      'actor_type="agent" 的主体最多只能将任务状态由 in_progress 推进至 pending_accept（待验收），协议层硬编码禁止 Agent 发送 conclusion="APPROVED" 的验收事件。',
  },
  {
    no: '合同 05',
    title: '本地敏感路径与环境变量脱敏',
    detail:
      '连接器在打包日志与错误堆栈前，必须自动将主机绝对路径替换为工作区相对路径，并掩码过滤所有形如 sk-*、ghp_* 或 .env 中的凭据字符。',
  },
  {
    no: '合同 06',
    title: '结构化退出码与遥测计量',
    detail:
      '每次会话结束（无论成功、超时或报错）必须上报 exit_code、duration_ms 与 tokens_consumed，用于生成周报中的固定成本与失败分类审计。',
  },
  {
    no: '合同 07',
    title: '离线缓冲与幂等重传',
    detail:
      '当网络闪断时，连接器以预生成的同一 event_id 在本地队列持久化；网络恢复后重传时，服务端基于 event_id 做幂等去重，确保不会产生重复产物记录。',
  },
]

const IMPLEMENTATION_DEVIATIONS = [
  {
    code: 'DEV-01',
    aspect: 'Token 计数器实现精度',
    designSpec: '设计规范要求针对不同模型（Claude / GPT / Qwen）调用各自原生 Tokenizer 计算精确 Token 数。',
    currentImpl:
      '因平台坚持「零密钥、不绑定特定模型厂商」原则，首版在浏览器与轻量服务端采用「UTF-8 字节加权启发式估算器（中文字符 ×0.65 + ASCII 词元 ×0.28）」，与原生分词器存在 ±3% 以内的微幅偏差。',
  },
  {
    code: 'DEV-02',
    aspect: '高频流式心跳的存储策略',
    designSpec: '设计规范中原则一要求「所有事件不可变且全量持久化」。',
    currentImpl:
      '为避免本地连接器每 5 秒一次的心跳事件撑爆项目台账，工程实现中仅对 agent.session_reported 的「首次启动」与「最终结束/异常退出」写入永久事件表，中间心跳仅更新内存态最后活跃时间。',
  },
  {
    code: 'DEV-03',
    aspect: '大体积数据集产物的哈希计算',
    designSpec: '设计规范要求对所有提交产物计算全文件 SHA-256。',
    currentImpl:
      '针对超过 500MB 的竞赛多模态数据集快照，为避免阻塞本地终端提交体验，连接器首版改用「首尾各 4MB 分块 + 文件大小 + 修改时间」生成快速复合指纹，并在版本尾缀标注 -fastdigest。',
  },
]

export function EventProtocolPage() {
  const [copiedJson, setCopiedJson] = useState(false)

  const handleCopyJson = () => {
    navigator.clipboard?.writeText(SAMPLE_EVENT_JSON)
    setCopiedJson(true)
    setTimeout(() => setCopiedJson(false), 1800)
  }

  return (
    <div className="flex h-full w-full flex-col overflow-y-auto select-text">
      {/* 顶部文档头 */}
      <div
        style={{
          backgroundColor: 'var(--cf-surface-secondary)',
          borderBottom: '1px solid var(--cf-border-strong)',
        }}
        className="flex shrink-0 flex-wrap items-center justify-between gap-2 px-6 py-2.5"
      >
        <div className="flex items-center gap-2.5">
          <span
            style={{
              backgroundColor: 'var(--cf-primary)',
              color: 'var(--cf-surface-card)',
            }}
            className="px-2 py-0.5 font-mono-tabular text-[11px] font-bold"
          >
            SPECIFICATION // RFC-COFLOW-01
          </span>
          <h1 className="text-[15px] font-bold text-[var(--cf-text-primary)]">
            四、事件协议（CoFlow 项目事实层与 Agent 协同协议规范 v1.0）
          </h1>
        </div>

        <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
          阅读型技术规范页 · 4 原则 · 13 公共字段 · 12 事件类型 · L0-L3 分层 · 7 回传合同 · 实现偏差
        </span>
      </div>

      {/* 主体阅读容器（控制在舒适阅读宽度 1180px，章节层次分明） */}
      <div className="mx-auto w-full max-w-[1180px] space-y-6 px-6 py-6">
        {/* ===================================================================
            1. 原则四条（事件不可变、状态可投影、写入带版本、证据先于结论）
           =================================================================== */}
        <section
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="border p-5"
        >
          <div className="mb-3.5 flex items-baseline justify-between border-b border-[var(--cf-border-strong)] pb-2">
            <h2 className="text-[16px] font-bold text-[var(--cf-text-primary)]">
              一、核心原则（四条铁律）
            </h2>
            <span className="font-mono-tabular text-[11px] text-[var(--cf-primary)]">
              SECTION 01 // ARCHITECTURAL AXIOMS
            </span>
          </div>

          <div className="grid grid-cols-1 gap-3.5 md:grid-cols-2">
            {FOUR_PRINCIPLES.map((p) => (
              <div
                key={p.code}
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderColor: 'var(--cf-border-strong)',
                  borderLeft: '4px solid var(--cf-primary)',
                }}
                className="border p-3.5"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[14px] font-bold text-[var(--cf-text-primary)]">
                    {p.title}
                  </span>
                  <span className="font-mono-tabular text-[10px] font-bold text-[var(--cf-primary)]">
                    {p.code}
                  </span>
                </div>
                <p className="mt-1.5 text-[13px] leading-[20px] text-[var(--cf-text-secondary)]">
                  {p.desc}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* ===================================================================
            2. 事件公共字段表（13 个字段）
           =================================================================== */}
        <section
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="overflow-hidden border"
        >
          <div
            style={{
              backgroundColor: 'var(--cf-surface-secondary)',
              borderBottom: '1px solid var(--cf-border-strong)',
            }}
            className="flex items-center justify-between px-5 py-3"
          >
            <h2 className="text-[16px] font-bold text-[var(--cf-text-primary)]">
              二、事件公共字段表（共 13 个标准字段）
            </h2>
            <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
              SECTION 02 // ENVELOPE SCHEMA (13 FIELDS)
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-[12px]">
              <thead>
                <tr
                  style={{
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderBottom: '1px solid var(--cf-border-strong)',
                  }}
                  className="text-[11px] font-semibold text-[var(--cf-text-secondary)]"
                >
                  <th className="w-12 px-4 py-2">#</th>
                  <th className="w-40 px-4 py-2">字段名</th>
                  <th className="w-36 px-4 py-2">数据类型</th>
                  <th className="w-20 px-4 py-2">约束</th>
                  <th className="px-4 py-2">语义与用途说明</th>
                  <th className="w-64 px-4 py-2">标准示例值</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--cf-border-subtle)]">
                {COMMON_FIELDS_13.map((f) => (
                  <tr
                    key={f.name}
                    className="hover:bg-[var(--cf-surface-secondary)]/60"
                  >
                    <td className="px-4 py-2 font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                      {String(f.idx).padStart(2, '0')}
                    </td>
                    <td className="px-4 py-2 font-mono-tabular font-bold text-[var(--cf-primary)]">
                      {f.name}
                    </td>
                    <td className="px-4 py-2 font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                      {f.type}
                    </td>
                    <td className="px-4 py-2">
                      <span
                        style={{
                          backgroundColor:
                            f.required === '必填'
                              ? 'var(--cf-primary-tint)'
                              : 'var(--cf-warning-bg)',
                          color:
                            f.required === '必填'
                              ? 'var(--cf-primary)'
                              : 'var(--cf-warning)',
                        }}
                        className="px-1.5 py-0.5 text-[10px] font-semibold"
                      >
                        {f.required}
                      </span>
                    </td>
                    <td className="px-4 py-2 text-[12px] leading-[18px] text-[var(--cf-text-primary)]">
                      {f.desc}
                    </td>
                    <td className="px-4 py-2 font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                      {f.example}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* ===================================================================
            3. 首版事件类型清单（12 个） + 4. 一段示例 JSON（深色代码块）
           =================================================================== */}
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
          {/* 首版事件类型清单（12 个） */}
          <section
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="overflow-hidden border lg:col-span-7"
          >
            <div
              style={{
                backgroundColor: 'var(--cf-surface-secondary)',
                borderBottom: '1px solid var(--cf-border-strong)',
              }}
              className="flex items-center justify-between px-4 py-2.5"
            >
              <h2 className="text-[15px] font-bold text-[var(--cf-text-primary)]">
                三、首版事件类型清单（共 12 个）
              </h2>
              <span className="font-mono-tabular text-[11px] text-[var(--cf-primary)]">
                12 CANONICAL EVENTS
              </span>
            </div>

            <div className="divide-y divide-[var(--cf-border-subtle)] text-[12px]">
              {EVENT_TYPES_12.map((ev) => (
                <div key={ev.type} className="px-4 py-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono-tabular text-[10px] font-bold text-[var(--cf-text-tertiary)]">
                        #{ev.idx}
                      </span>
                      <code className="font-mono-tabular text-[12px] font-bold text-[var(--cf-primary)]">
                        {ev.type}
                      </code>
                      <span className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] px-1.5 py-0.2 text-[10px] text-[var(--cf-text-secondary)]">
                        {ev.domain}
                      </span>
                    </div>
                    <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                      actor: {ev.actor}
                    </span>
                  </div>
                  <p className="mt-0.5 pl-6 text-[12px] leading-[18px] text-[var(--cf-text-secondary)]">
                    {ev.effect}
                  </p>
                </div>
              ))}
            </div>
          </section>

          {/* 一段示例 JSON（深色代码块） */}
          <section
            style={{
              backgroundColor: '#12161E',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="flex flex-col overflow-hidden border text-[#E6EDF3] lg:col-span-5"
          >
            <div className="flex items-center justify-between border-b border-[#2D333B] bg-[#1B202B] px-4 py-2.5">
              <div>
                <h2 className="text-[14px] font-bold text-white">
                  四、标准事件示例 JSON（深色代码块）
                </h2>
                <span className="font-mono-tabular text-[10px] text-[#8B949E]">
                  artifact.submitted · 含完整 13 公共字段与 payload
                </span>
              </div>
              <button
                type="button"
                onClick={handleCopyJson}
                className="border border-[#3D444D] bg-[#262C36] px-2.5 py-1 font-mono-tabular text-[11px] text-[#A7F3D0] hover:bg-[#30363D]"
              >
                {copiedJson ? '✓ 已复制 JSON' : '复制 JSON'}
              </button>
            </div>

            <pre className="font-mono-tabular flex-1 overflow-x-auto p-4 text-[11px] leading-[17px] text-[#D2DFF0]">
              {SAMPLE_EVENT_JSON}
            </pre>
          </section>
        </div>

        {/* ===================================================================
            5. 上下文包分层表（L0–L3，含更新策略）
           =================================================================== */}
        <section
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="overflow-hidden border"
        >
          <div
            style={{
              backgroundColor: 'var(--cf-surface-secondary)',
              borderBottom: '1px solid var(--cf-border-strong)',
            }}
            className="flex items-center justify-between px-5 py-3"
          >
            <h2 className="text-[16px] font-bold text-[var(--cf-text-primary)]">
              五、上下文包分层表（L0–L3 · 含裁剪属性与更新策略）
            </h2>
            <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
              SECTION 05 // CONTEXT PACK LAYERS
            </span>
          </div>

          <table className="w-full border-collapse text-left text-[12px]">
            <thead>
              <tr
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderBottom: '1px solid var(--cf-border-strong)',
                }}
                className="text-[11px] font-semibold text-[var(--cf-text-secondary)]"
              >
                <th className="w-28 px-4 py-2">层级</th>
                <th className="w-72 px-4 py-2">承载事实内容</th>
                <th className="w-40 px-4 py-2">是否可裁剪</th>
                <th className="px-4 py-2">更新策略与触发时机</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--cf-border-subtle)]">
              {CONTEXT_LAYERS_TABLE.map((row) => (
                <tr key={row.layer}>
                  <td className="px-4 py-2.5 font-mono-tabular font-bold text-[var(--cf-primary)]">
                    {row.layer}
                  </td>
                  <td className="px-4 py-2.5 font-medium text-[var(--cf-text-primary)]">
                    {row.content}
                  </td>
                  <td className="px-4 py-2.5">
                    <span
                      style={{
                        backgroundColor: row.trimmable.includes('不可裁剪')
                          ? 'var(--cf-danger-bg)'
                          : 'var(--cf-warning-bg)',
                        color: row.trimmable.includes('不可裁剪')
                          ? 'var(--cf-danger)'
                          : 'var(--cf-warning)',
                      }}
                      className="inline-block px-1.5 py-0.5 font-mono-tabular text-[11px] font-semibold"
                    >
                      {row.trimmable}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 leading-[18px] text-[var(--cf-text-secondary)]">
                    {row.updatePolicy}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        {/* ===================================================================
            6. Agent 回传合同（7 条）
           =================================================================== */}
        <section
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="border p-5"
        >
          <div className="mb-3.5 flex items-baseline justify-between border-b border-[var(--cf-border-strong)] pb-2">
            <h2 className="text-[16px] font-bold text-[var(--cf-text-primary)]">
              六、Agent 回传合同（7 条强制契约）
            </h2>
            <span className="font-mono-tabular text-[11px] text-[var(--cf-primary)]">
              SECTION 06 // CONNECTOR RETURN CONTRACT (7 CLAUSES)
            </span>
          </div>

          <div className="divide-y divide-[var(--cf-border-subtle)]">
            {AGENT_RETURN_CONTRACTS_7.map((c) => (
              <div
                key={c.no}
                className="grid grid-cols-1 gap-2 py-2.5 md:grid-cols-12"
              >
                <div className="md:col-span-3 flex items-center gap-2">
                  <span
                    style={{
                      backgroundColor: 'var(--cf-primary)',
                      color: 'var(--cf-surface-card)',
                    }}
                    className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-bold"
                  >
                    {c.no}
                  </span>
                  <span className="text-[13px] font-bold text-[var(--cf-text-primary)]">
                    {c.title}
                  </span>
                </div>
                <div className="md:col-span-9 text-[13px] leading-[20px] text-[var(--cf-text-secondary)]">
                  {c.detail}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ===================================================================
            7. 实现偏差说明（设计与实现不一致的地方）
           =================================================================== */}
        <section
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-warning)',
            borderLeftWidth: '4px',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="border p-5"
        >
          <div className="mb-3.5 flex items-baseline justify-between border-b border-[var(--cf-border-subtle)] pb-2">
            <div>
              <h2 className="text-[16px] font-bold text-[var(--cf-text-primary)]">
                七、实现偏差说明（设计与当前工程实现不一致的地方）
              </h2>
              <p className="mt-0.5 text-[12px] text-[var(--cf-text-tertiary)]">
                遵循事实透明原则，在此公示首版工程落地对理论协议所做的 3 处务实折中：
              </p>
            </div>
            <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-warning)]">
              SECTION 07 // IMPLEMENTATION DEVIATIONS
            </span>
          </div>

          <div className="space-y-3">
            {IMPLEMENTATION_DEVIATIONS.map((dev) => (
              <div
                key={dev.code}
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderColor: 'var(--cf-border-strong)',
                }}
                className="border p-3.5 text-[12px]"
              >
                <div className="flex items-center gap-2">
                  <span className="bg-[var(--cf-warning)] px-1.5 py-0.5 font-mono-tabular text-[10px] font-bold text-white">
                    {dev.code}
                  </span>
                  <span className="text-[13px] font-bold text-[var(--cf-text-primary)]">
                    {dev.aspect}
                  </span>
                </div>
                <div className="mt-2 grid grid-cols-1 gap-2.5 md:grid-cols-2">
                  <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-card)] p-2.5">
                    <div className="font-mono-tabular text-[10px] font-semibold text-[var(--cf-text-tertiary)]">
                      [原协议理论设计]
                    </div>
                    <p className="mt-1 leading-[18px] text-[var(--cf-text-secondary)]">
                      {dev.designSpec}
                    </p>
                  </div>
                  <div className="border border-[var(--cf-warning-border)] bg-[var(--cf-warning-bg)]/50 p-2.5">
                    <div className="font-mono-tabular text-[10px] font-semibold text-[var(--cf-warning)]">
                      [当前工程实现与折中原因]
                    </div>
                    <p className="mt-1 leading-[18px] text-[var(--cf-text-primary)]">
                      {dev.currentImpl}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
