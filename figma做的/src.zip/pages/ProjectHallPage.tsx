import React, { useState } from 'react'
import {
  CfButton,
  AvatarGroup,
  ThinProgressBar,
} from '../design-system/components'
import { ProjectSummaryItem, ProjectStage } from '../data/mockProjects'

interface ProjectHallPageProps {
  projects: ProjectSummaryItem[]
  onEnterProjectWorkbench: (projectId: string) => void
  onOpenProjectSettings: (projectId: string) => void
  onStartCreateProject: () => void
}

function StageBadge({ stage }: { stage: ProjectStage }) {
  const styleMap: Record<ProjectStage, React.CSSProperties> = {
    定义: {
      backgroundColor: 'var(--cf-warning-bg)',
      color: 'var(--cf-warning)',
      borderColor: 'var(--cf-warning-border)',
    },
    开发: {
      backgroundColor: 'var(--cf-info-bg)',
      color: 'var(--cf-info)',
      borderColor: 'var(--cf-info-border)',
    },
    联调: {
      backgroundColor: 'var(--cf-primary-tint)',
      color: 'var(--cf-primary)',
      borderColor: 'var(--cf-primary)',
    },
    验收: {
      backgroundColor: 'var(--cf-warning-bg)',
      color: 'var(--cf-warning)',
      borderColor: 'var(--cf-warning)',
      borderLeftWidth: '3px',
    },
    归档: {
      backgroundColor: 'var(--cf-surface-tertiary)',
      color: 'var(--cf-text-tertiary)',
      borderColor: 'var(--cf-border-strong)',
    },
  }

  return (
    <span
      style={styleMap[stage]}
      className="inline-flex h-[20px] items-center border px-1.5 text-[11px] font-semibold leading-none"
    >
      阶段 · {stage}
    </span>
  )
}

export function ProjectHallPage({
  projects,
  onEnterProjectWorkbench,
  onOpenProjectSettings,
  onStartCreateProject,
}: ProjectHallPageProps) {
  // 状态切换：未完成上手引导条显隐 + 空项目大厅状态验证
  const [showOnboardingBar, setShowOnboardingBar] = useState(true)
  const [emptyHallDemo, setEmptyHallDemo] = useState(false)

  const activeProjects = emptyHallDemo ? [] : projects

  // 四个全局统计数字汇总
  const totalProjects = activeProjects.length
  const totalInProgress = activeProjects.reduce((acc, p) => acc + p.inProgressCount, 0)
  const totalPendingAccept = activeProjects.reduce(
    (acc, p) => acc + p.pendingAcceptCount,
    0
  )
  const totalBlocked = activeProjects.reduce((acc, p) => acc + p.blockedCount, 0)

  return (
    <div className="flex h-full w-full flex-col overflow-y-auto select-text">
      {/* =====================================================================
          未完成上手时的顶部引导条
         ===================================================================== */}
      {showOnboardingBar && (
        <div
          style={{
            backgroundColor: 'var(--cf-warning-bg)',
            borderBottom: '1px solid var(--cf-warning)',
            borderLeft: '4px solid var(--cf-warning)',
          }}
          className="shrink-0 px-6 py-2"
        >
          <div className="mx-auto flex max-w-[1380px] flex-wrap items-center justify-between gap-2 text-[12px]">
            <div className="flex items-center gap-2">
              <span
                style={{
                  backgroundColor: 'var(--cf-warning)',
                  color: 'var(--cf-surface-card)',
                }}
                className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-bold"
              >
                ONBOARDING
              </span>
              <span className="font-semibold text-[var(--cf-text-primary)]">
                15 分钟跑通第一个闭环 · 建项目 → 连设备 → 授权目录 → 建任务 → 交付验收
              </span>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onStartCreateProject}
                style={{
                  backgroundColor: 'var(--cf-primary)',
                  color: 'var(--cf-surface-card)',
                }}
                className="h-[24px] px-2.5 text-[12px] font-semibold hover:bg-[var(--cf-primary-deep)]"
              >
                开始 →
              </button>
              <button
                type="button"
                onClick={() => setShowOnboardingBar(false)}
                className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)] hover:text-[var(--cf-text-primary)]"
              >
                [隐藏引导条]
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="mx-auto flex flex-1 w-full max-w-[1380px] flex-col justify-between px-6 py-5 gap-6">
        <div className="space-y-5">
          {/* =================================================================
              1. 页面标题 + 一句说明 + 状态验证开关 + 右上新建按钮
             ================================================================= */}
          <div className="flex flex-wrap items-end justify-between gap-3 border-b border-[var(--cf-border-strong)] pb-3.5">
            <div>
              <div className="font-mono-tabular text-[11px] font-semibold tracking-widest text-[var(--cf-primary)]">
                COFLOW PROJECT HALL // ARCHIVAL LEDGER
              </div>
              <div className="mt-0.5 flex flex-wrap items-baseline gap-3">
                <h1
                  style={{
                    fontSize: 'var(--cf-t1-size)',
                    lineHeight: 'var(--cf-t1-lh)',
                  }}
                  className="font-bold text-[var(--cf-text-primary)]"
                >
                  项目大厅
                </h1>
                <p className="text-[13px] font-medium text-[var(--cf-text-secondary)]">
                  同一份事实，给人看，也给 Agent 读。
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              {/* 状态验证切换器 */}
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-card)',
                  borderColor: 'var(--cf-border-strong)',
                }}
                className="flex items-center border p-0.5 text-[11px]"
              >
                <span className="px-1.5 text-[var(--cf-text-tertiary)]">状态演示:</span>
                <button
                  type="button"
                  onClick={() => setEmptyHallDemo(false)}
                  style={{
                    backgroundColor: !emptyHallDemo
                      ? 'var(--cf-primary)'
                      : 'transparent',
                    color: !emptyHallDemo
                      ? 'var(--cf-surface-card)'
                      : 'var(--cf-text-secondary)',
                  }}
                  className="h-[22px] px-2 font-medium"
                >
                  常态多项目 ({projects.length})
                </button>
                <button
                  type="button"
                  onClick={() => setEmptyHallDemo(true)}
                  style={{
                    backgroundColor: emptyHallDemo
                      ? 'var(--cf-primary)'
                      : 'transparent',
                    color: emptyHallDemo
                      ? 'var(--cf-surface-card)'
                      : 'var(--cf-text-secondary)',
                  }}
                  className="h-[22px] px-2 font-medium"
                >
                  空项目状态
                </button>
                <button
                  type="button"
                  onClick={() => setShowOnboardingBar((v) => !v)}
                  className="h-[22px] border-l border-[var(--cf-border-subtle)] px-2 text-[var(--cf-primary)]"
                >
                  {showOnboardingBar ? '已开启上手条' : '显示上手条'}
                </button>
              </div>

              <CfButton
                variant="primary"
                size="default"
                onClick={onStartCreateProject}
              >
                ＋ 新建项目
              </CfButton>
            </div>
          </div>

          {/* =================================================================
              2. 四个统计数字（项目总数、进行中任务数、待验收数、阻塞数）
             ================================================================= */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              {
                label: '项目总数',
                value: totalProjects,
                unit: '个活跃与归档项目',
                color: 'var(--cf-text-primary)',
                leftBorder: 'var(--cf-primary)',
              },
              {
                label: '进行中任务数',
                value: totalInProgress,
                unit: '人机协同执行中',
                color: 'var(--cf-primary)',
                leftBorder: 'var(--cf-info)',
              },
              {
                label: '待验收数',
                value: totalPendingAccept,
                unit: '等待人工签批结论',
                color: 'var(--cf-warning)',
                leftBorder: 'var(--cf-warning)',
              },
              {
                label: '阻塞数',
                value: totalBlocked,
                unit: '需外部支持或裁决',
                color: totalBlocked > 0 ? 'var(--cf-danger)' : 'var(--cf-text-secondary)',
                leftBorder: 'var(--cf-danger)',
              },
            ].map((stat) => (
              <div
                key={stat.label}
                style={{
                  backgroundColor: 'var(--cf-surface-card)',
                  borderColor: 'var(--cf-border-strong)',
                  borderLeft: `4px solid ${stat.leftBorder}`,
                  boxShadow: 'var(--cf-shadow-card)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="flex items-baseline justify-between border px-4 py-3"
              >
                <div>
                  <div className="text-[12px] font-semibold text-[var(--cf-text-secondary)]">
                    {stat.label}
                  </div>
                  <div className="mt-0.5 text-[11px] text-[var(--cf-text-tertiary)]">
                    {stat.unit}
                  </div>
                </div>
                <div
                  style={{ color: stat.color }}
                  className="font-mono-tabular text-[26px] font-bold leading-none"
                >
                  {stat.value}
                </div>
              </div>
            ))}
          </div>

          {/* =================================================================
              3. 项目卡片列表 + 「＋ 新建项目」入口卡（或空状态）
             ================================================================= */}
          {activeProjects.length === 0 ? (
            /* 空状态：没有任何项目时的指定引导文案 */
            <div
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-border-strong)',
                boxShadow: 'var(--cf-shadow-card)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="flex flex-col items-center justify-center border border-dashed px-6 py-12 text-center"
            >
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderColor: 'var(--cf-border-strong)',
                }}
                className="mb-3 flex h-12 w-12 items-center justify-center border font-mono-tabular text-[16px] font-bold text-[var(--cf-primary)]"
              >
                §0
              </div>
              <h2 className="text-[16px] font-semibold text-[var(--cf-text-primary)]">
                还没有任何项目
              </h2>
              <p className="mt-2 max-w-xl text-[13px] leading-[21px] text-[var(--cf-text-secondary)]">
                先建一个项目章程：目标、范围、非目标、约束、验收标准。没有这些，Agent 拿到的上下文只会是一堆聊天记录。
              </p>
              <div className="mt-4 flex items-center gap-3">
                <CfButton
                  variant="primary"
                  size="default"
                  onClick={onStartCreateProject}
                >
                  ＋ 创建第一个项目（5 步向导）
                </CfButton>
                <CfButton
                  variant="secondary"
                  size="default"
                  onClick={() => setEmptyHallDemo(false)}
                >
                  恢复示例项目列表
                </CfButton>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
              {activeProjects.map((prj) => (
                <div
                  key={prj.id}
                  onClick={() => onEnterProjectWorkbench(prj.id)}
                  style={{
                    backgroundColor: 'var(--cf-surface-card)',
                    borderColor: 'var(--cf-border-strong)',
                    boxShadow: 'var(--cf-shadow-card)',
                    borderRadius: 'var(--cf-radius-container)',
                  }}
                  className="group flex cursor-pointer flex-col justify-between border p-4 transition-all hover:-translate-y-0.5 hover:border-[var(--cf-primary)]"
                >
                  <div>
                    {/* 顶行：项目代号（如 ZX） + 阶段（定义/开发/联调/验收/归档） + 设置快捷入口 */}
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span
                          style={{
                            backgroundColor: 'var(--cf-primary)',
                            color: 'var(--cf-surface-card)',
                          }}
                          className="px-2 py-0.5 font-mono-tabular text-[12px] font-bold tracking-wider"
                        >
                          {prj.code}
                        </span>
                        <StageBadge stage={prj.stage} />
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation()
                          onOpenProjectSettings(prj.id)
                        }}
                        className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)] hover:text-[var(--cf-primary)] hover:underline"
                      >
                        [项目设置]
                      </button>
                    </div>

                    {/* 项目名称 */}
                    <h3 className="mt-2.5 text-[15px] font-semibold text-[var(--cf-text-primary)] group-hover:text-[var(--cf-primary)]">
                      {prj.name}
                    </h3>

                    {/* 目标摘要（两行 line-clamp-2） */}
                    <p className="mt-1 line-clamp-2 text-[12px] leading-[18px] text-[var(--cf-text-secondary)]">
                      {prj.goalSummary}
                    </p>
                  </div>

                  <div className="mt-4 space-y-2.5">
                    {/* 交付进度百分比与进度条 */}
                    <div>
                      <div className="mb-1 flex items-center justify-between text-[11px]">
                        <span className="text-[var(--cf-text-tertiary)]">交付进度</span>
                        <span className="font-mono-tabular font-semibold text-[var(--cf-text-primary)]">
                          {prj.progress}%
                        </span>
                      </div>
                      <ThinProgressBar percent={prj.progress} />
                    </div>

                    {/* 状态计数（进行中 / 待验收 / 阻塞）三格等宽台账 */}
                    <div
                      style={{
                        backgroundColor: 'var(--cf-surface-secondary)',
                        borderColor: 'var(--cf-border-subtle)',
                      }}
                      className="grid grid-cols-3 divide-x divide-[var(--cf-border-subtle)] border text-center font-mono-tabular text-[11px]"
                    >
                      <div className="py-1">
                        <span className="text-[var(--cf-text-tertiary)]">进行中 </span>
                        <strong className="text-[var(--cf-primary)]">
                          {prj.inProgressCount}
                        </strong>
                      </div>
                      <div className="py-1">
                        <span className="text-[var(--cf-text-tertiary)]">待验收 </span>
                        <strong className="text-[var(--cf-warning)]">
                          {prj.pendingAcceptCount}
                        </strong>
                      </div>
                      <div
                        style={{
                          backgroundColor:
                            prj.blockedCount > 0 ? 'var(--cf-danger-bg)' : undefined,
                        }}
                        className="py-1"
                      >
                        <span className="text-[var(--cf-text-tertiary)]">阻塞 </span>
                        <strong
                          style={{
                            color:
                              prj.blockedCount > 0
                                ? 'var(--cf-danger)'
                                : 'var(--cf-text-secondary)',
                          }}
                        >
                          {prj.blockedCount}
                        </strong>
                      </div>
                    </div>

                    {/* 底行：成员头像组 + 最近活动时间 */}
                    <div
                      style={{ borderColor: 'var(--cf-border-subtle)' }}
                      className="flex items-center justify-between border-t pt-2"
                    >
                      <AvatarGroup items={prj.members} max={5} />
                      <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                        活跃于 {prj.lastActiveTime}
                      </span>
                    </div>
                  </div>
                </div>
              ))}

              {/* 一张「＋ 新建项目」入口卡 */}
              <div
                onClick={onStartCreateProject}
                style={{
                  backgroundColor: 'var(--cf-surface-paper)',
                  borderColor: 'var(--cf-border-strong-hover)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="group flex min-h-[230px] cursor-pointer flex-col items-center justify-center border-2 border-dashed p-6 text-center transition-colors hover:border-[var(--cf-primary)] hover:bg-[var(--cf-surface-card)]"
              >
                <div
                  style={{
                    backgroundColor: 'var(--cf-surface-card)',
                    borderColor: 'var(--cf-border-strong)',
                  }}
                  className="mb-3 flex h-11 w-11 items-center justify-center border font-mono-tabular text-[20px] font-semibold text-[var(--cf-primary)] group-hover:border-[var(--cf-primary)] group-hover:bg-[var(--cf-primary)] group-hover:text-white"
                >
                  ＋
                </div>
                <h3 className="text-[15px] font-semibold text-[var(--cf-text-primary)] group-hover:text-[var(--cf-primary)]">
                  ＋ 新建项目
                </h3>
                <p className="mt-1 max-w-[240px] text-[12px] leading-[18px] text-[var(--cf-text-tertiary)]">
                  通过 5 步向导（支持软件、内容、竞赛模板）将想法转化为结构化章程与第一批任务。
                </p>
              </div>
            </div>
          )}
        </div>

        {/* ===================================================================
            4. 页面底部产品说明：「聊天负责交流意图，任务与产物负责表达事实」+ 四个要点
           =================================================================== */}
        <footer
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="border p-4"
        >
          <div className="mb-3 flex flex-wrap items-baseline justify-between gap-2 border-b border-[var(--cf-border-subtle)] pb-2">
            <div className="flex items-center gap-2">
              <span
                style={{
                  backgroundColor: 'var(--cf-primary)',
                  color: 'var(--cf-surface-card)',
                }}
                className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold"
              >
                COFLOW 协作哲学
              </span>
              <h2 className="text-[14px] font-bold text-[var(--cf-text-primary)]">
                聊天负责交流意图，任务与产物负责表达事实
              </h2>
            </div>
            <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
              FACTS OVER MESSAGES · 4 PILLARS
            </span>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4 text-[12px]">
            {[
              {
                code: '01 · 目标',
                title: '目标（带版本号，变更需分析影响）',
                desc: '项目章程明确目标、范围与非目标，每次修订递增版本号并强制记录变更说明，作为 L0 稳定层注入所有 Agent。',
              },
              {
                code: '02 · 任务',
                title: '任务（状态机驱动，不可跳级）',
                desc: '待澄清 → 待认领 → 已就绪 → 进行中 → 待验收 → 已完成；缺输入或验收标准的任务自动拦截在待澄清。',
              },
              {
                code: '03 · 决策',
                title: '决策（确认后才进入上下文）',
                desc: '群聊里的讨论只是过程，唯有经发起人或负责人点击「确认并写入事实层」的决策，才会被 Agent 当作执行依据。',
              },
              {
                code: '04 · 产物',
                title: '产物（完成必须有证据）',
                desc: '提交任务必须附带可定位的提交号、路径与版本快照；Agent 只能提交至待验收，最终结论由人签批。',
              },
            ].map((pillar) => (
              <div
                key={pillar.code}
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderColor: 'var(--cf-border-subtle)',
                }}
                className="border p-3"
              >
                <div className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                  {pillar.code}
                </div>
                <div className="mt-0.5 font-semibold text-[var(--cf-text-primary)]">
                  {pillar.title}
                </div>
                <p className="mt-1 text-[11px] leading-[17px] text-[var(--cf-text-secondary)]">
                  {pillar.desc}
                </p>
              </div>
            ))}
          </div>
        </footer>
      </div>
    </div>
  )
}
