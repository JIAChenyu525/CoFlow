import React, { useState } from 'react'
import { CfButton } from '../design-system/components'

type DecisionStatus = 'proposal' | 'confirmed' | 'superseded'

interface DecisionLedgerItem {
  id: string
  status: DecisionStatus
  title: string
  conclusion: string
  rationale: string
  alternatives: string
  impactScope: string[]
  decider: string
  time: string
  version: string
  supersedesTitle?: string
  supersededById?: string
}

type TimelineEventKind =
  | '决策确认'
  | '产物提交'
  | '任务状态变更'
  | '任务阻塞'
  | '章程升级'

interface TimelineEventItem {
  id: string
  kind: TimelineEventKind
  title: string
  operator: string
  summary: string
  time: string
  entityRef: string
}

// 严格按状态排序：提案 (proposal) → 已确认 (confirmed) → 已被替代 (superseded)
const INITIAL_DECISIONS: DecisionLedgerItem[] = [
  {
    id: 'DEC-04',
    status: 'proposal',
    title: '路演演示台切换为本地离线加密快照包 v1.4，与外网政务云网关联调解耦',
    conclusion:
      '在周五挑战杯路演现场统一加载本地离线加密快照包 v1.4，不依赖实时外网政务云 VPN 隧道。',
    rationale:
      'TSK-109 政务云网关因等待企业营业执照扫描件已阻塞 5 天，存在路演现场网络抖动或鉴权超时风险。',
    alternatives:
      '备选 A：临时申请手机 5G 热点直连政务云测试跳板机（被否决：违反章程 §4 数据安全红线且延迟不可控）。',
    impactScope: ['TSK-119 答辩演示文稿', 'TSK-109 实测网关联调', 'M4 · 竞赛路演'],
    decider: '苏哲 (提议 · 待发起人/负责人确认)',
    time: '2025-05-14 15:08',
    version: 'v0.9-draft',
  },
  {
    id: 'DEC-03',
    status: 'confirmed',
    title: '采用 BGE-M3 + 轻量 Cross-Encoder 两阶段混合检索架构',
    conclusion:
      '锁定「BM25 + BGE-M3 稠密召回 + Top-30 轻量 Cross-Encoder 重排」作为全项目唯一生产检索架构。',
    rationale:
      '实测该架构在单张 RTX 4090 上 P99 延迟仅 142ms，且 Top-10 召回率达 94.82%，全面优于章程 §1/§4 的 93.0% / 180ms 基线。',
    alternatives:
      '备选 A：租用 8×A100 全量微调 70B 开源基座大模型（成本超支 400% 且推理延迟高达 1,200ms）；备选 B：纯 BM25 关键词检索（召回率仅 78.4%）。',
    impactScope: ['CHR-v2.4 章程 §3/§4', 'TSK-108 召回率评测', 'TSK-114 融合重排实验'],
    decider: '林知夏',
    time: '2025-05-12 18:20',
    version: 'v2.0',
    supersedesTitle: 'DEC-01：采用 70B 开源基座模型全量微调方案',
  },
  {
    id: 'DEC-02',
    status: 'confirmed',
    title: '标准评测基准集锁定为 2,400 条脱敏工业问答对 (#9a4c12)',
    conclusion:
      '所有检索与重排算法迭代必须且只能在哈希为 #9a4c12 的 2,400 条标准评测集上跑批出表。',
    rationale:
      '消除不同成员使用私自抽样小数据集汇报虚高指标的口径偏差，保证各轮实验结果 100% 横向可比。',
    alternatives:
      '备选 A：沿用早期 1,500 条未均衡样本集（缺少跨页财务表格困难样本，代表性不足）。',
    impactScope: ['TSK-105 评测集构建', 'TSK-108 向量评测', 'data/ground_truth_2400.jsonl'],
    decider: '陈默',
    time: '2025-05-10 14:05',
    version: 'v1.2',
  },
  {
    id: 'DEC-01',
    status: 'superseded',
    title: '采用 70B 开源基座模型全量微调方案',
    conclusion:
      '原定租用 8 卡 A100 集群对 70B 基座模型进行行业语料全参数微调并直接生成检索答案。',
    rationale:
      '立项初期假设大模型参数量越大领域理解越准，未充分评估单次检索 180ms 延迟硬约束。',
    alternatives:
      '备选 A：轻量向量检索 + 重排方案（后经实测证实更优，已在 DEC-03 中正式采纳并替代本决策）。',
    impactScope: ['TSK-102 70B 算力租赁与微调脚本 (已取消)'],
    decider: '林知夏',
    time: '2025-05-06 11:00',
    version: 'v1.0 (已作废)',
    supersededById: 'DEC-03',
  },
]

const INITIAL_TIMELINE_EVENTS: TimelineEventItem[] = [
  {
    id: 'ev-08',
    kind: '任务阻塞',
    title: 'TSK-109 标记为「已阻塞」',
    operator: '许嘉树',
    summary: '政务云实测网关拦截连接器探针，已阻塞 5 天，等待加盖公章的企业营业执照扫描件。',
    time: '05-14 14:15',
    entityRef: 'TSK-109',
  },
  {
    id: 'ev-07',
    kind: '任务状态变更',
    title: 'TSK-106 验收退回 → 重新进入「进行中 (R2)」',
    operator: '周舟',
    summary: '退回负样本基线对齐验收申请：缺少第 9–12 类近似型号混淆矩阵附件，触发 R2 返工轮次。',
    time: '05-14 13:40',
    entityRef: 'TSK-106',
  },
  {
    id: 'ev-06',
    kind: '产物提交',
    title: '登记评测报告产物 recall_bench_v1.4.csv (v1.4.2-rc)',
    operator: '陈默 (cursor-win-02)',
    summary: '回传 2,400 条评测集 Top-10 召回率实测数据 (94.82%) 与 SHA-1 证据哈希 #7b91e0。',
    time: '05-14 11:26',
    entityRef: 'ART-108-02',
  },
  {
    id: 'ev-05',
    kind: '任务状态变更',
    title: 'TSK-108 流转至「待验收」',
    operator: '陈默',
    summary: '向量检索模块召回率评测已完成全部 2 份产物证据登记，正式提请评审人周舟核验。',
    time: '05-14 11:27',
    entityRef: 'TSK-108',
  },
  {
    id: 'ev-04',
    kind: '章程升级',
    title: '项目章程升级至 CHR-v2.4.0',
    operator: '林知夏',
    summary: '在 §4 硬性约束中新增「单次检索 P99 延迟 ≤ 180ms」与 16 并发压测验收门槛。',
    time: '05-14 10:02',
    entityRef: 'CHR-v2.4',
  },
  {
    id: 'ev-03',
    kind: '决策确认',
    title: '确认决策 DEC-03 并写入事实层（取代 DEC-01）',
    operator: '林知夏',
    summary: '正式锁定 BGE-M3 + 轻量重排两阶段架构，同时将原 TSK-102 (70B 微调) 置为已取消。',
    time: '05-12 18:20',
    entityRef: 'DEC-03',
  },
  {
    id: 'ev-02',
    kind: '产物提交',
    title: '封存标准评测集 ground_truth_2400.jsonl (v1.0.0)',
    operator: '周舟',
    summary: '通过 PII 敏感信息零检出扫描与双盲抽检 (准确率 99.0%)，写入 data/ground_truth_2400.jsonl。',
    time: '05-11 17:10',
    entityRef: 'ART-105-01',
  },
  {
    id: 'ev-01',
    kind: '决策确认',
    title: '确认决策 DEC-02 并写入事实层',
    operator: '陈默',
    summary: '全项目统一使用 2,400 条脱敏工业问答对作为唯一基准测试源，禁止私自抽样汇报。',
    time: '05-10 14:05',
    entityRef: 'DEC-02',
  },
]

function DecisionStatusBadge({ status }: { status: DecisionStatus }) {
  if (status === 'proposal') {
    return (
      <span
        style={{
          backgroundColor: 'var(--cf-warning-bg)',
          color: 'var(--cf-warning)',
          borderColor: 'var(--cf-warning)',
          borderLeftWidth: '3px',
        }}
        className="inline-flex h-[20px] items-center gap-1 border border-dashed px-1.5 text-[11px] font-bold leading-none"
      >
        <span>◆ 提案</span>
      </span>
    )
  }
  if (status === 'confirmed') {
    return (
      <span
        style={{
          backgroundColor: 'var(--cf-success)',
          color: 'var(--cf-surface-card)',
          borderColor: 'var(--cf-success)',
        }}
        className="inline-flex h-[20px] items-center gap-1 border px-1.5 text-[11px] font-bold leading-none"
      >
        <span>✓ 已确认</span>
      </span>
    )
  }
  return (
    <span
      style={{
        color: 'var(--cf-text-tertiary)',
        borderColor: 'var(--cf-border-strong)',
      }}
      className="cf-pattern-cancelled inline-flex h-[20px] items-center gap-1 border px-1.5 text-[11px] font-medium leading-none"
    >
      <span className="line-through">已被替代</span>
    </span>
  )
}

function EventTypeBadge({ kind }: { kind: TimelineEventKind }) {
  const config: Record<
    TimelineEventKind,
    { style: React.CSSProperties; glyph: React.ReactNode }
  > = {
    决策确认: {
      style: {
        backgroundColor: 'var(--cf-success)',
        color: 'var(--cf-surface-card)',
        borderColor: 'var(--cf-success)',
      },
      glyph: (
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
          <path d="M5 1L9 5L5 9L1 5L5 1Z" stroke="currentColor" strokeWidth="1.3" />
          <path d="M3.2 5L4.5 6.3L7 3.7" stroke="currentColor" strokeWidth="1.3" />
        </svg>
      ),
    },
    产物提交: {
      style: {
        backgroundColor: 'var(--cf-primary-tint)',
        color: 'var(--cf-primary)',
        borderColor: 'var(--cf-primary)',
      },
      glyph: (
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
          <rect x="1.5" y="1.5" width="7" height="7" stroke="currentColor" strokeWidth="1.3" />
          <path d="M3.2 5H6.8M5 3.2V6.8" stroke="currentColor" strokeWidth="1.3" />
        </svg>
      ),
    },
    任务状态变更: {
      style: {
        backgroundColor: 'var(--cf-info-bg)',
        color: 'var(--cf-info)',
        borderColor: 'var(--cf-info-border)',
      },
      glyph: (
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
          <path d="M2 5H8M5.5 2.5L8 5L5.5 7.5" stroke="currentColor" strokeWidth="1.3" />
        </svg>
      ),
    },
    任务阻塞: {
      style: {
        backgroundColor: 'var(--cf-danger)',
        color: 'var(--cf-surface-card)',
        borderColor: 'var(--cf-danger)',
      },
      glyph: (
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
          <path
            d="M3.2 1.2H6.8L8.8 3.2V6.8L6.8 8.8H3.2L1.2 6.8V3.2L3.2 1.2Z"
            stroke="currentColor"
            strokeWidth="1.3"
          />
          <path d="M3 5H7" stroke="currentColor" strokeWidth="1.5" />
        </svg>
      ),
    },
    章程升级: {
      style: {
        backgroundColor: 'var(--cf-warning-bg)',
        color: 'var(--cf-warning)',
        borderColor: 'var(--cf-warning)',
        borderLeftWidth: '3px',
      },
      glyph: (
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
          <path d="M2.2 1.5H7.8V8.5H2.2V1.5Z" stroke="currentColor" strokeWidth="1.3" />
          <path d="M3.8 4H6.2M3.8 6H6.2" stroke="currentColor" strokeWidth="1.2" />
        </svg>
      ),
    },
  }

  const c = config[kind]
  return (
    <span
      style={c.style}
      className="inline-flex h-[20px] w-[96px] shrink-0 items-center justify-center gap-1 border px-1.5 text-[11px] font-semibold leading-none"
    >
      {c.glyph}
      <span>{kind}</span>
    </span>
  )
}

export function DecisionsTimelinePage() {
  // 空状态切换：没有决策 / 没有事件
  const [emptyDecisions, setEmptyDecisions] = useState(false)
  const [emptyEvents, setEmptyEvents] = useState(false)
  const [eventFilter, setEventFilter] = useState<'all' | TimelineEventKind>('all')

  const activeDecisions = emptyDecisions ? [] : INITIAL_DECISIONS
  const activeEvents = emptyEvents
    ? []
    : eventFilter === 'all'
      ? INITIAL_TIMELINE_EVENTS
      : INITIAL_TIMELINE_EVENTS.filter((e) => e.kind === eventFilter)

  return (
    <div className="flex h-full w-full flex-col overflow-hidden select-text">
      {/* =====================================================================
          顶部说明与空状态验证栏
         ===================================================================== */}
      <div
        style={{
          backgroundColor: 'var(--cf-surface-secondary)',
          borderBottom: '1px solid var(--cf-border-strong)',
        }}
        className="flex shrink-0 flex-wrap items-center justify-between gap-2 px-6 py-2"
      >
        <div className="flex items-center gap-2">
          <span
            style={{
              backgroundColor: 'var(--cf-primary)',
              color: 'var(--cf-surface-card)',
            }}
            className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-bold"
          >
            DECISIONS & TIMELINE
          </span>
          <h1 className="text-[14px] font-bold text-[var(--cf-text-primary)]">
            三、决策与时间线（回答「为什么这样做」和「历史上发生了什么」· 高可扫读台账布局）
          </h1>
        </div>

        <div className="flex items-center gap-2 text-[11px]">
          <span className="text-[var(--cf-text-tertiary)]">空状态验证:</span>
          <button
            type="button"
            onClick={() => setEmptyDecisions((v) => !v)}
            style={{
              backgroundColor: emptyDecisions
                ? 'var(--cf-primary)'
                : 'var(--cf-surface-card)',
              color: emptyDecisions
                ? 'var(--cf-surface-card)'
                : 'var(--cf-text-secondary)',
              borderColor: 'var(--cf-border-strong)',
            }}
            className="h-[22px] border px-2 font-medium"
          >
            {emptyDecisions ? '✓ 已开启：没有决策' : '模拟：没有决策'}
          </button>

          <button
            type="button"
            onClick={() => setEmptyEvents((v) => !v)}
            style={{
              backgroundColor: emptyEvents
                ? 'var(--cf-primary)'
                : 'var(--cf-surface-card)',
              color: emptyEvents
                ? 'var(--cf-surface-card)'
                : 'var(--cf-text-secondary)',
              borderColor: 'var(--cf-border-strong)',
            }}
            className="h-[22px] border px-2 font-medium"
          >
            {emptyEvents ? '✓ 已开启：没有事件' : '模拟：没有事件'}
          </button>
        </div>
      </div>

      {/* =====================================================================
          双栏主体：左栏「决策列表 (7列宽)」 | 右栏「竖向事件时间线 (5列宽)」
         ===================================================================== */}
      <div className="mx-auto grid flex-1 w-full max-w-[1440px] grid-cols-12 overflow-hidden">
        {/* ===================================================================
            左栏 (7 列宽)：决策列表（按状态排序：提案 → 已确认 → 已被替代）
           =================================================================== */}
        <section
          style={{
            backgroundColor: 'var(--cf-surface-paper)',
            borderRight: '1px solid var(--cf-border-strong)',
          }}
          className="col-span-7 flex h-full flex-col overflow-y-auto p-4 space-y-3.5"
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <h2 className="text-[15px] font-bold text-[var(--cf-text-primary)]">
                决策列表（按状态排序：提案 → 已确认 → 已被替代）
              </h2>
              <span className="font-mono-tabular text-[11px] text-[var(--cf-primary)]">
                共 {activeDecisions.length} 项
              </span>
            </div>
            <span className="text-[11px] text-[var(--cf-text-tertiary)]">
              结构化字段分区：一眼扫读「结论」与「影响范围」，无需逐字通读
            </span>
          </div>

          {activeDecisions.length === 0 ? (
            <div
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-border-strong)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="flex flex-col items-center justify-center border border-dashed p-10 text-center"
            >
              <h3 className="text-[14px] font-bold text-[var(--cf-text-primary)]">
                暂无已登记的项目决策
              </h3>
              <p className="mt-1 max-w-md text-[12px] text-[var(--cf-text-tertiary)]">
                可在工作台讨论流消息上悬停点击「形成决策」，由发起人或负责人确认后写入此处。
              </p>
              <div className="mt-3">
                <CfButton
                  variant="secondary"
                  size="xs"
                  onClick={() => setEmptyDecisions(false)}
                >
                  恢复决策列表示例
                </CfButton>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {activeDecisions.map((dec) => {
                const isSuperseded = dec.status === 'superseded'
                const isProposal = dec.status === 'proposal'

                return (
                  <article
                    key={dec.id}
                    style={{
                      backgroundColor: isSuperseded
                        ? 'var(--cf-surface-tertiary)'
                        : 'var(--cf-surface-card)',
                      borderColor: isProposal
                        ? 'var(--cf-warning)'
                        : isSuperseded
                          ? 'var(--cf-border-strong)'
                          : 'var(--cf-primary)',
                      borderLeftWidth: '4px',
                      boxShadow: isSuperseded ? 'none' : 'var(--cf-shadow-card)',
                      borderRadius: 'var(--cf-radius-container)',
                    }}
                    className={`border transition-opacity ${
                      isSuperseded ? 'opacity-80' : ''
                    }`}
                  >
                    {/* 顶栏：状态徽标 + 决策编号 + 标题 + 版本号 + 若替代了旧决策显示"取代「旧决策标题」" */}
                    <div
                      style={{
                        backgroundColor: isSuperseded
                          ? 'var(--cf-surface-secondary)'
                          : 'var(--cf-surface-secondary)',
                        borderBottom: '1px solid var(--cf-border-subtle)',
                      }}
                      className="flex flex-wrap items-center justify-between gap-2 px-3.5 py-2"
                    >
                      <div className="flex flex-wrap items-center gap-2 min-w-0">
                        <DecisionStatusBadge status={dec.status} />
                        <span className="font-mono-tabular text-[12px] font-bold text-[var(--cf-primary)]">
                          {dec.id}
                        </span>
                        <h3
                          className={`text-[14px] font-bold text-[var(--cf-text-primary)] ${
                            isSuperseded ? 'line-through decoration-1' : ''
                          }`}
                        >
                          {dec.title}
                        </h3>
                      </div>

                      <span className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold text-[var(--cf-text-secondary)]">
                        版本 {dec.version}
                      </span>
                    </div>

                    {/* 若替代了旧决策，醒目显示 "取代「旧决策标题」" */}
                    {dec.supersedesTitle && (
                      <div
                        style={{
                          backgroundColor: 'var(--cf-primary-tint)',
                          borderBottom: '1px solid var(--cf-primary-border)',
                          color: 'var(--cf-primary-deep)',
                        }}
                        className="flex items-center gap-1.5 px-3.5 py-1 text-[11px] font-semibold"
                      >
                        <span className="font-mono-tabular text-[10px] uppercase">
                          [演进关系]
                        </span>
                        <span>取代「{dec.supersedesTitle}」</span>
                      </div>
                    )}

                    {/* 若自身已被替代，标注被哪条新决策取代 */}
                    {isSuperseded && dec.supersededById && (
                      <div className="border-b border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] px-3.5 py-1 text-[11px] font-medium text-[var(--cf-text-secondary)]">
                        注：本决策已被新决策 [{dec.supersededById}] 正式替代，仅作为历史演进背景保留查阅，不再注入 Agent 活跃执行指令。
                      </div>
                    )}

                    {/* 主体：1) 核心结论（独立高亮横槽，支持一秒扫读） + 2) 理由 & 备选方案双栏 + 3) 影响范围与元信息底栏 */}
                    <div className="space-y-2.5 p-3.5 text-[12px]">
                      {/* 结论 */}
                      <div
                        style={{
                          backgroundColor: isSuperseded
                            ? 'var(--cf-surface-card)'
                            : isProposal
                              ? 'var(--cf-warning-bg)'
                              : 'var(--cf-success-bg)',
                          borderColor: isSuperseded
                            ? 'var(--cf-border-subtle)'
                            : isProposal
                              ? 'var(--cf-warning-border)'
                              : 'var(--cf-success-border)',
                        }}
                        className="border px-3 py-2"
                      >
                        <span className="mr-1.5 font-mono-tabular text-[11px] font-bold uppercase text-[var(--cf-primary)]">
                          [结论]
                        </span>
                        <span className="text-[13px] font-semibold text-[var(--cf-text-primary)]">
                          {dec.conclusion}
                        </span>
                      </div>

                      {/* 理由 vs 备选方案 双栏 */}
                      <div className="grid grid-cols-1 gap-2.5 md:grid-cols-2">
                        <div
                          style={{
                            backgroundColor: 'var(--cf-surface-secondary)',
                            borderColor: 'var(--cf-border-subtle)',
                          }}
                          className="border p-2.5"
                        >
                          <div className="text-[11px] font-bold text-[var(--cf-text-secondary)]">
                            决策理由 (Why)
                          </div>
                          <p className="mt-1 leading-[18px] text-[var(--cf-text-primary)]">
                            {dec.rationale}
                          </p>
                        </div>

                        <div
                          style={{
                            backgroundColor: 'var(--cf-surface-secondary)',
                            borderColor: 'var(--cf-border-subtle)',
                          }}
                          className="border p-2.5"
                        >
                          <div className="text-[11px] font-bold text-[var(--cf-text-secondary)]">
                            备选方案与否决原因 (Alternatives)
                          </div>
                          <p className="mt-1 leading-[18px] text-[var(--cf-text-secondary)]">
                            {dec.alternatives}
                          </p>
                        </div>
                      </div>

                      {/* 底栏：影响范围 + 决策人 + 时间 */}
                      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-[var(--cf-border-subtle)] pt-2 text-[11px]">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="font-semibold text-[var(--cf-text-secondary)]">
                            影响范围：
                          </span>
                          {dec.impactScope.map((scope, idx) => (
                            <span
                              key={idx}
                              className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold text-[var(--cf-primary)]"
                            >
                              {scope}
                            </span>
                          ))}
                        </div>

                        <div className="flex items-center gap-3 font-mono-tabular text-[var(--cf-text-tertiary)]">
                          <span>
                            决策人：<strong className="text-[var(--cf-text-primary)]">{dec.decider}</strong>
                          </span>
                          <span>{dec.time}</span>
                        </div>
                      </div>
                    </div>
                  </article>
                )
              })}
            </div>
          )}
        </section>

        {/* ===================================================================
            右栏 (5 列宽)：事件时间线（竖向 · 区分 5 种事件类型：决策确认/产物提交/任务状态变更/任务阻塞/章程升级）
           =================================================================== */}
        <aside
          style={{
            backgroundColor: 'var(--cf-surface-card)',
          }}
          className="col-span-5 flex h-full flex-col overflow-hidden"
        >
          {/* 时间线顶栏与 5 类事件筛选器 */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-secondary)',
              borderBottom: '1px solid var(--cf-border-strong)',
            }}
            className="shrink-0 p-3.5"
          >
            <div className="flex items-center justify-between">
              <h2 className="text-[15px] font-bold text-[var(--cf-text-primary)]">
                事件时间线（竖向审计流）
              </h2>
              <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                共 {activeEvents.length} 条记录
              </span>
            </div>

            {/* 5 种事件类型快速过滤 */}
            <div className="mt-2 flex flex-wrap items-center gap-1 text-[11px]">
              {(
                [
                  'all',
                  '决策确认',
                  '产物提交',
                  '任务状态变更',
                  '任务阻塞',
                  '章程升级',
                ] as const
              ).map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => setEventFilter(k)}
                  style={{
                    backgroundColor:
                      eventFilter === k
                        ? 'var(--cf-primary)'
                        : 'var(--cf-surface-card)',
                    color:
                      eventFilter === k
                        ? 'var(--cf-surface-card)'
                        : 'var(--cf-text-secondary)',
                    borderColor: 'var(--cf-border-strong)',
                  }}
                  className="h-[20px] border px-1.5 font-medium"
                >
                  {k === 'all' ? '全部类型' : k}
                </button>
              ))}
            </div>
          </div>

          {/* 竖向事件时间线主体（固定左列时间 + 96px 等宽事件类型徽标 + 标题/操作人/一句话摘要） */}
          <div className="flex-1 overflow-y-auto p-4">
            {activeEvents.length === 0 ? (
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderColor: 'var(--cf-border-strong)',
                }}
                className="flex flex-col items-center justify-center border border-dashed p-8 text-center"
              >
                <div className="text-[13px] font-bold text-[var(--cf-text-primary)]">
                  当前没有历史事件记录
                </div>
                <p className="mt-1 text-[12px] text-[var(--cf-text-tertiary)]">
                  所有章程升级、决策确认、产物提交与任务状态流转均会在此生成不可篡改的竖向时间线。
                </p>
                <div className="mt-3">
                  <CfButton
                    variant="secondary"
                    size="xs"
                    onClick={() => {
                      setEmptyEvents(false)
                      setEventFilter('all')
                    }}
                  >
                    恢复时间线示例
                  </CfButton>
                </div>
              </div>
            ) : (
              <div className="relative border-l-2 border-[var(--cf-border-strong)] ml-3 space-y-3 pl-4">
                {activeEvents.map((ev) => {
                  const isBlocker = ev.kind === '任务阻塞'
                  return (
                    <div
                      key={ev.id}
                      style={{
                        backgroundColor: isBlocker
                          ? 'var(--cf-danger-bg)'
                          : 'var(--cf-surface-secondary)',
                        borderColor: isBlocker
                          ? 'var(--cf-danger-border)'
                          : 'var(--cf-border-subtle)',
                      }}
                      className="relative border p-3 text-[12px]"
                    >
                      {/* 竖向时间轴节点圆点 */}
                      <span
                        style={{
                          backgroundColor: isBlocker
                            ? 'var(--cf-danger)'
                            : 'var(--cf-primary)',
                          borderColor: 'var(--cf-surface-card)',
                        }}
                        className="absolute -left-[22px] top-3.5 h-3 w-3 border-2"
                      />

                      {/* 第一行：事件类型徽标 (5 种鲜明视觉区分) + 时间 + 操作人 */}
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <EventTypeBadge kind={ev.kind} />
                          <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]">
                            [{ev.entityRef}]
                          </span>
                        </div>

                        <div className="flex items-center gap-2 font-mono-tabular text-[11px]">
                          <span className="font-semibold text-[var(--cf-text-secondary)]">
                            操作人：{ev.operator}
                          </span>
                          <span className="text-[var(--cf-text-tertiary)]">{ev.time}</span>
                        </div>
                      </div>

                      {/* 第二行：事件标题 */}
                      <div className="mt-1.5 text-[13px] font-bold text-[var(--cf-text-primary)]">
                        {ev.title}
                      </div>

                      {/* 第三行：一句话摘要 */}
                      <p className="mt-0.5 text-[12px] leading-[18px] text-[var(--cf-text-secondary)]">
                        {ev.summary}
                      </p>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </aside>
      </div>
    </div>
  )
}
