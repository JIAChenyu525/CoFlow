import React, { useState, useEffect } from 'react'
import { CfButton } from '../design-system/components'

interface LoginPageProps {
  onLoginSuccess: () => void
  onOpenEventProtocol: () => void
}

export function LoginPage({
  onLoginSuccess,
  onOpenEventProtocol,
}: LoginPageProps) {
  const [step, setStep] = useState<'email' | 'code'>('email')
  const [email, setEmail] = useState('linzhixia@coflow.dev')
  const [code, setCode] = useState('842910')

  // 状态控制：发送中 / 60 秒冷却 / 验证码错误 / 已过期
  const [sendingState, setSendingState] = useState<
    'idle' | 'sending' | 'cooldown' | 'invalid_code' | 'expired_code'
  >('idle')
  const [cooldownSec, setCooldownSec] = useState<number>(58)

  useEffect(() => {
    if (sendingState !== 'cooldown') return
    const timer = setInterval(() => {
      setCooldownSec((prev) => {
        if (prev <= 1) {
          setSendingState('idle')
          return 60
        }
        return prev - 1
      })
    }, 1000)
    return () => clearInterval(timer)
  }, [sendingState])

  // 第一步：发送验证码
  const handleSendCode = (e: React.FormEvent) => {
    e.preventDefault()
    if (!email.trim() || sendingState === 'sending' || sendingState === 'cooldown') {
      return
    }
    setSendingState('sending')
    setTimeout(() => {
      setStep('code')
      setSendingState('cooldown')
      setCooldownSec(58)
    }, 450)
  }

  // 第二步：提交 6 位验证码登录
  const handleVerifyLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (sendingState === 'invalid_code' || sendingState === 'expired_code') {
      return
    }
    if (code.trim() === '000000') {
      setSendingState('invalid_code')
      return
    }
    onLoginSuccess()
  }

  return (
    <div className="flex h-full w-full flex-col justify-between overflow-y-auto select-text">
      {/* =====================================================================
          顶部状态验证切换条（方便一键检验：第一步 / 第二步 / 发送中 / 60秒冷却 / 验证码错误 / 已过期）
         ===================================================================== */}
      <div
        style={{
          backgroundColor: 'var(--cf-surface-secondary)',
          borderBottom: '1px solid var(--cf-border-strong)',
        }}
        className="flex shrink-0 flex-wrap items-center justify-between gap-2 px-6 py-2 text-[11px]"
      >
        <div className="flex items-center gap-2">
          <span
            style={{
              backgroundColor: 'var(--cf-primary)',
              color: 'var(--cf-surface-card)',
            }}
            className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-bold"
          >
            AUTH GATEWAY
          </span>
          <span className="font-semibold text-[var(--cf-text-primary)]">
            一、登录页（邮箱验证码两步流 & 4 种异常/冷却状态实时验证）
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[var(--cf-text-tertiary)]">状态演示切换:</span>
          {[
            {
              id: 'step1_idle',
              label: '第一步：输入邮箱',
              action: () => {
                setStep('email')
                setSendingState('idle')
              },
              active: step === 'email' && sendingState === 'idle',
            },
            {
              id: 'sending',
              label: '状态：发送中',
              action: () => {
                setStep('email')
                setSendingState('sending')
              },
              active: sendingState === 'sending',
            },
            {
              id: 'cooldown',
              label: '第二步 + 60秒冷却',
              action: () => {
                setStep('code')
                setSendingState('cooldown')
                setCooldownSec(58)
              },
              active: step === 'code' && sendingState === 'cooldown',
            },
            {
              id: 'invalid_code',
              label: '状态：验证码错误',
              action: () => {
                setStep('code')
                setSendingState('invalid_code')
              },
              active: sendingState === 'invalid_code',
            },
            {
              id: 'expired_code',
              label: '状态：已过期',
              action: () => {
                setStep('code')
                setSendingState('expired_code')
              },
              active: sendingState === 'expired_code',
            },
          ].map((btn) => (
            <button
              key={btn.id}
              type="button"
              onClick={btn.action}
              style={{
                backgroundColor: btn.active
                  ? 'var(--cf-primary)'
                  : 'var(--cf-surface-card)',
                color: btn.active
                  ? 'var(--cf-surface-card)'
                  : 'var(--cf-text-secondary)',
                borderColor: 'var(--cf-border-strong)',
              }}
              className="h-[22px] border px-2 font-medium transition-colors"
            >
              {btn.label}
            </button>
          ))}
        </div>
      </div>

      {/* =====================================================================
          登录主卡片（纸上实验室档案认证单风格）
         ===================================================================== */}
      <div className="flex flex-1 items-center justify-center p-6">
        <div
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderColor: 'var(--cf-border-strong)',
            boxShadow: 'var(--cf-shadow-card)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="w-full max-w-[460px] border"
        >
          {/* 顶部品牌栏：品牌名 CoFlow + 一句定位「项目事实层」 */}
          <div
            style={{
              backgroundColor: 'var(--cf-primary)',
              borderBottom: '1px solid var(--cf-primary-deep)',
              color: 'var(--cf-surface-card)',
            }}
            className="flex items-center justify-between px-6 py-4"
          >
            <div className="flex items-baseline gap-2.5">
              <span className="font-mono-tabular text-[20px] font-bold tracking-tight text-white">
                CoFlow
              </span>
              <span
                style={{
                  backgroundColor: 'var(--cf-primary-deep)',
                  borderColor: 'var(--cf-primary-border)',
                }}
                className="border px-2 py-0.5 text-[12px] font-semibold text-[#A7F3D0]"
              >
                项目事实层
              </span>
            </div>
            <span className="font-mono-tabular text-[11px] text-[#E3F1F2] opacity-80">
              FACT LEDGER v2.4
            </span>
          </div>

          <div className="p-6 space-y-5">
            {/* 标题与说明 */}
            <div>
              <h1
                style={{
                  fontSize: 'var(--cf-t1-size)',
                  lineHeight: 'var(--cf-t1-lh)',
                }}
                className="font-bold text-[var(--cf-text-primary)]"
              >
                登录 CoFlow
              </h1>
              <p className="mt-1.5 text-[13px] leading-[20px] text-[var(--cf-text-secondary)]">
                用邮箱验证码登录。项目数据属于你的账号，不属于某台电脑；之后接入 Agent 的设备凭据会绑定到这个账号上。
              </p>
            </div>

            {/* 步骤切换指示 */}
            <div
              style={{
                backgroundColor: 'var(--cf-surface-secondary)',
                borderColor: 'var(--cf-border-subtle)',
              }}
              className="grid grid-cols-2 border text-center text-[11px]"
            >
              <button
                type="button"
                onClick={() => {
                  setStep('email')
                  setSendingState('idle')
                }}
                style={{
                  backgroundColor:
                    step === 'email' ? 'var(--cf-primary-tint)' : 'transparent',
                  color:
                    step === 'email'
                      ? 'var(--cf-primary)'
                      : 'var(--cf-text-tertiary)',
                }}
                className="py-1.5 font-semibold"
              >
                第一步 · 验证工作邮箱
              </button>
              <button
                type="button"
                onClick={() => setStep('code')}
                style={{
                  backgroundColor:
                    step === 'code' ? 'var(--cf-primary-tint)' : 'transparent',
                  color:
                    step === 'code'
                      ? 'var(--cf-primary)'
                      : 'var(--cf-text-tertiary)',
                }}
                className="border-l border-[var(--cf-border-subtle)] py-1.5 font-semibold"
              >
                第二步 · 输入 6 位验证码
              </button>
            </div>

            {step === 'email' ? (
              /* ===============================================================
                 第一步：邮箱输入 + 「发送验证码」
                 =============================================================== */
              <form onSubmit={handleSendCode} className="space-y-4">
                <div>
                  <label className="mb-1.5 block text-[12px] font-semibold text-[var(--cf-text-primary)]">
                    账号邮箱
                  </label>
                  <input
                    type="email"
                    required
                    disabled={sendingState === 'sending'}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@team.com 或学号邮箱"
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                      borderRadius: 'var(--cf-radius-control)',
                    }}
                    className="font-mono-tabular h-[36px] w-full border px-3 text-[13px] text-[var(--cf-text-primary)] outline-none focus:border-[var(--cf-primary)]"
                  />
                </div>

                <div className="flex flex-col gap-2">
                  <CfButton
                    variant="primary"
                    size="default"
                    visualState={
                      sendingState === 'sending'
                        ? 'loading'
                        : sendingState === 'cooldown'
                          ? 'disabled'
                          : 'default'
                    }
                    onClick={() => {
                      if (sendingState === 'idle') {
                        setStep('code')
                        setSendingState('cooldown')
                        setCooldownSec(58)
                      }
                    }}
                  >
                    {sendingState === 'sending'
                      ? '正在发送验证码...'
                      : sendingState === 'cooldown'
                        ? `重新发送 (${cooldownSec}s 冷却中)`
                        : '发送验证码'}
                  </CfButton>
                </div>
              </form>
            ) : (
              /* ===============================================================
                 第二步：上方显示"已发送到 xxx@xxx" + 「换个邮箱」入口 + 6 位验证码输入（等宽、大字距）+ 「登录」
                 =============================================================== */
              <form onSubmit={handleVerifyLogin} className="space-y-4">
                <div
                  style={{
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderColor: 'var(--cf-border-subtle)',
                  }}
                  className="flex items-center justify-between border px-3 py-2 text-[12px]"
                >
                  <span className="text-[var(--cf-text-secondary)]">
                    已发送到{' '}
                    <strong className="font-mono-tabular text-[var(--cf-text-primary)]">
                      {email || 'linzhixia@coflow.dev'}
                    </strong>
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setStep('email')
                      setSendingState('idle')
                    }}
                    className="font-semibold text-[var(--cf-primary)] hover:underline"
                  >
                    换个邮箱
                  </button>
                </div>

                <div>
                  <div className="mb-1.5 flex items-center justify-between text-[12px]">
                    <label className="font-semibold text-[var(--cf-text-primary)]">
                      6 位验证码（等宽大字距）
                    </label>
                    {sendingState === 'cooldown' ? (
                      <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                        {cooldownSec} 秒后可重发
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setSendingState('cooldown')
                          setCooldownSec(60)
                        }}
                        className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)] hover:underline"
                      >
                        重新发送验证码
                      </button>
                    )}
                  </div>

                  <input
                    type="text"
                    maxLength={6}
                    value={code}
                    onChange={(e) => {
                      setCode(e.target.value.replace(/\D/g, '').slice(0, 6))
                      if (
                        sendingState === 'invalid_code' ||
                        sendingState === 'expired_code'
                      ) {
                        setSendingState('cooldown')
                      }
                    }}
                    placeholder="000000"
                    style={{
                      backgroundColor:
                        sendingState === 'invalid_code' ||
                        sendingState === 'expired_code'
                          ? 'var(--cf-danger-bg)'
                          : 'var(--cf-surface-card)',
                      borderColor:
                        sendingState === 'invalid_code' ||
                        sendingState === 'expired_code'
                          ? 'var(--cf-danger)'
                          : 'var(--cf-primary)',
                      borderRadius: 'var(--cf-radius-control)',
                    }}
                    className="font-mono-tabular h-[42px] w-full border-2 px-4 text-center text-[20px] font-bold tracking-[0.45em] text-[var(--cf-text-primary)] outline-none"
                  />

                  {/* 验证码错误 / 已过期 状态提示 */}
                  {sendingState === 'invalid_code' && (
                    <div
                      style={{
                        backgroundColor: 'var(--cf-danger-bg)',
                        borderColor: 'var(--cf-danger)',
                        color: 'var(--cf-danger)',
                      }}
                      className="mt-2 border-l-4 px-3 py-1.5 text-[12px] font-semibold"
                    >
                      验证码错误：输入的 6 位验证码与邮件不匹配，请核对后重试。
                    </div>
                  )}

                  {sendingState === 'expired_code' && (
                    <div
                      style={{
                        backgroundColor: 'var(--cf-warning-bg)',
                        borderColor: 'var(--cf-warning)',
                        color: 'var(--cf-warning)',
                      }}
                      className="mt-2 flex items-center justify-between border-l-4 px-3 py-1.5 text-[12px] font-semibold"
                    >
                      <span>验证码已过期：该验证码已超过 10 分钟有效期。</span>
                      <button
                        type="button"
                        onClick={() => {
                          setSendingState('cooldown')
                          setCooldownSec(60)
                        }}
                        className="underline"
                      >
                        重新获取
                      </button>
                    </div>
                  )}
                </div>

                <div className="pt-1">
                  <button
                    type="submit"
                    style={{
                      backgroundColor: 'var(--cf-primary)',
                      color: 'var(--cf-surface-card)',
                      borderRadius: 'var(--cf-radius-control)',
                    }}
                    className="h-[34px] w-full text-[13px] font-semibold hover:bg-[var(--cf-primary-deep)]"
                  >
                    登录
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* 底部说明与「了解事件协议」次要入口 */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-secondary)',
              borderTop: '1px solid var(--cf-border-strong)',
            }}
            className="px-6 py-3.5 text-[11px] leading-[17px] text-[var(--cf-text-secondary)]"
          >
            <p>
              继续即表示同意：平台只保存项目事实，不读取、不保存你本地工具的模型密钥。
            </p>
            <div className="mt-2 flex items-center justify-between border-t border-[var(--cf-border-subtle)] pt-2">
              <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                ZERO-KEY · IMMUTABLE EVENT PROTOCOL
              </span>
              <button
                type="button"
                onClick={onOpenEventProtocol}
                className="font-semibold text-[var(--cf-primary)] hover:underline"
              >
                了解事件协议 →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
