import React, { useState } from 'react'
import {
  CapabilityBadge,
  CfButton,
  RoleType,
} from '../design-system/components'

interface AgentEndpointSpec {
  id: string
  toolName: string
  version: string
  capability: 'auto' | 'semi' | 'manual'
  capabilityDesc: string
  degradeReason?: string
  degradeSupplement?: string
  boundProject: string
  lastHeartbeat: string
  authorizedDirs: string
}

interface ConnectedDeviceSpec {
  id: string
  deviceName: string
  osInfo: string
  online: boolean
  pairedAt: string
  ownerName: string
  endpoints: AgentEndpointSpec[]
}

interface RevokedDeviceSpec {
  id: string
  deviceName: string
  osInfo: string
  ownerName: string
  revokedAt: string
}

const INITIAL_DEVICES: ConnectedDeviceSpec[] = [
  {
    id: 'dev-01',
    deviceName: 'CHENMO-WIN11-WORKSTATION',
    osInfo: 'Windows 11 Pro 23H2 (x64 · RTX 4090)',
    online: true,
    pairedAt: '2025-05-06 09:40',
    ownerName: '陈默',
    endpoints: [
      {
        id: 'ep-101',
        toolName: 'Cursor MCP Connector',
        version: 'v1.4.2',
        capability: 'auto',
        capabilityDesc: '支持无头 JSON 流式输出、自动拉取上下文包与回传 Git 补丁哈希',
        boundProject: 'ZX · 多智能体企业知识库混合检索系统',
        lastHeartbeat: '4 秒前 (17:42:18)',
        authorizedDirs: 'src/retrieval/**, config/retrieval.prod.yaml, artifacts/eval/**',
      },
      {
        id: 'ep-102',
        toolName: 'Claude Code CLI',
        version: 'v0.8.1-legacy',
        capability: 'semi',
        capabilityDesc: '支持读取本地上下文快照与交互式代码生成，不支持后台无人值守批处理',
        degradeReason: '该版本不支持无头 JSON 输出（缺少 --print / --output-format）',
        degradeSupplement: '只能半自动或手动执行，不能 coflow run',
        boundProject: 'ZX · 多智能体企业知识库混合检索系统',
        lastHeartbeat: '28 秒前 (17:41:54)',
        authorizedDirs: 'scripts/**, tests/retrieval/**',
      },
    ],
  },
  {
    id: 'dev-02',
    deviceName: 'JIA-WSL2-UBUNTU22',
    osInfo: 'Windows 11 + WSL2 Ubuntu 22.04 LTS',
    online: true,
    pairedAt: '2025-05-08 14:15',
    ownerName: '许嘉树',
    endpoints: [
      {
        id: 'ep-201',
        toolName: 'Windsurf Local Bridge',
        version: 'v1.1.0',
        capability: 'auto',
        capabilityDesc: '支持双向 MCP 协议、沙箱目录读写隔离与自动化单测退出码捕获',
        boundProject: 'MCP2 · 跨平台本地 AI 连接器沙箱网关',
        lastHeartbeat: '11 秒前 (17:42:11)',
        authorizedDirs: 'src/connector/**, src/gateway/**',
      },
      {
        id: 'ep-202',
        toolName: 'Local Shell Assistant (Custom Wrapper)',
        version: 'v0.3.0',
        capability: 'manual',
        capabilityDesc: '仅提供上下文包导出下载，由成员手动执行脚本并登记产物路径',
        degradeReason: '未实现标准 MCP 回调接口与结构化事件流套接字（缺少 --mcp-server 守护能力）',
        degradeSupplement: '只能半自动或手动执行，不能 coflow run',
        boundProject: 'ZX · 多智能体企业知识库混合检索系统',
        lastHeartbeat: '12 分钟前 (17:30:05)',
        authorizedDirs: 'docs/whitepaper/**, artifacts/figures/**',
      },
    ],
  },
]

const INITIAL_REVOKED_DEVICES: RevokedDeviceSpec[] = [
  {
    id: 'rev-01',
    deviceName: 'SUZHE-LAPTOP-OLD',
    osInfo: 'Windows 10 22H2',
    ownerName: '苏哲',
    revokedAt: '2025-05-10 21:15',
  },
  {
    id: 'rev-02',
    deviceName: 'LAB-PUBLIC-GPU04',
    osInfo: 'Ubuntu 20.04 Server',
    ownerName: '周舟',
    revokedAt: '2025-05-09 18:02',
  },
]

export function AgentConnectPage({ currentRole }: { currentRole: RoleType }) {
  const isObserver = currentRole === 'observer'

  // 设备与已撤销列表
  const [devices, setDevices] = useState<ConnectedDeviceSpec[]>(INITIAL_DEVICES)
  const [revokedDevices, setRevokedDevices] = useState<RevokedDeviceSpec[]>(
    INITIAL_REVOKED_DEVICES
  )

  // 状态切换：没有任何设备 / 配对码状态（正常、错误、过期、已使用） / 保存目录失败
  const [emptyDevicesDemo, setEmptyDevicesDemo] = useState(false)
  const [pairingCode, setPairingCode] = useState('ABCD-2345')
  const [pairingSimMode, setPairingSimMode] = useState<
    'ok' | 'invalid' | 'expired' | 'used'
  >('ok')
  const [pairingFeedback, setPairingFeedback] = useState<{
    type: 'success' | 'error'
    message: string
  } | null>(null)

  // 端点「授权目录」展开与保存状态
  const [editingDirEpId, setEditingDirEpId] = useState<string | null>('ep-101')
  const [dirInputMap, setDirInputMap] = useState<Record<string, string>>({
    'ep-101': 'src/retrieval/**, config/retrieval.prod.yaml, artifacts/eval/**',
    'ep-102': 'scripts/**, tests/retrieval/**',
    'ep-201': 'src/connector/**, src/gateway/**',
    'ep-202': 'docs/whitepaper/**, artifacts/figures/**',
  })
  const [simulateDirSaveError, setSimulateDirSaveError] = useState(false)
  const [dirSaveStatusMap, setDirSaveStatusMap] = useState<
    Record<string, { ok: boolean; msg: string }>
  >({})

  const activeDevices = emptyDevicesDemo ? [] : devices

  // 处理「授权这台设备」
  const handleAuthorizeDevice = (e: React.FormEvent) => {
    e.preventDefault()
    if (isObserver) return

    const clean = pairingCode.trim().toUpperCase()
    if (!clean || pairingSimMode === 'invalid' || clean === 'ERR0-0000') {
      setPairingFeedback({
        type: 'error',
        message:
          '配对码错误：未找到匹配的待授权终端会话，请核对终端显示的 8 位字符（形如 ABCD-2345）。',
      })
      return
    }
    if (pairingSimMode === 'expired' || clean === 'EXPR-1234') {
      setPairingFeedback({
        type: 'error',
        message:
          '配对码已过期：配对码有效期为 5 分钟，请在目标电脑重新执行 npx coflow-connector login 获取新码。',
      })
      return
    }
    if (pairingSimMode === 'used' || clean === 'USED-9999') {
      setPairingFeedback({
        type: 'error',
        message:
          '配对码已使用：该配对码已绑定过设备，单次配对码不可重复使用。',
      })
      return
    }

    const newDev: ConnectedDeviceSpec = {
      id: `dev-${Date.now()}`,
      deviceName: `ZHOUZHOU-WIN11-${clean.slice(0, 4)}`,
      osInfo: 'Windows 11 Pro 24H2 (x64)',
      online: true,
      pairedAt: '2025-05-14 17:45',
      ownerName: '周舟',
      endpoints: [
        {
          id: `ep-${Date.now()}`,
          toolName: 'Cursor MCP Connector',
          version: 'v1.4.2',
          capability: 'auto',
          capabilityDesc: '新接入端点：支持无头 JSON 输出与受控目录读写',
          boundProject: 'ZX · 多智能体企业知识库混合检索系统',
          lastHeartbeat: '刚刚 (17:45:02)',
          authorizedDirs: 'artifacts/eval/**',
        },
      ],
    }

    setDevices((prev) => [newDev, ...prev])
    if (emptyDevicesDemo) setEmptyDevicesDemo(false)
    setPairingFeedback({
      type: 'success',
      message: `设备 [${newDev.deviceName}] 授权成功！已自动发现 1 个本地 Agent 端点。`,
    })
  }

  // 撤销设备
  const handleRevokeDevice = (dev: ConnectedDeviceSpec) => {
    if (isObserver) return
    setDevices((prev) => prev.filter((d) => d.id !== dev.id))
    setRevokedDevices((prev) => [
      {
        id: `rev-${Date.now()}`,
        deviceName: dev.deviceName,
        osInfo: dev.osInfo,
        ownerName: dev.ownerName,
        revokedAt: '2025-05-14 17:46',
      },
      ...prev,
    ])
  }

  // 保存端点授权目录
  const handleSaveEndpointDirs = (deviceId: string, endpointId: string) => {
    const rawVal = (dirInputMap[endpointId] || '').trim()
    if (simulateDirSaveError || rawVal.includes('..') || rawVal.includes('C:\\')) {
      setDirSaveStatusMap((prev) => ({
        ...prev,
        [endpointId]: {
          ok: false,
          msg: '保存目录失败：包含越界父级路径 (..) 或系统绝对路径，本地连接器已拒绝挂载该目录白名单。',
        },
      }))
      return
    }

    setDevices((prev) =>
      prev.map((d) =>
        d.id !== deviceId
          ? d
          : {
              ...d,
              endpoints: d.endpoints.map((ep) =>
                ep.id === endpointId ? { ...ep, authorizedDirs: rawVal } : ep
              ),
            }
      )
    )
    setDirSaveStatusMap((prev) => ({
      ...prev,
      [endpointId]: {
        ok: true,
        msg: '✓ 授权目录白名单已同步至本地连接器守护进程',
      },
    }))
  }

  return (
    <div className="flex h-full w-full flex-col overflow-y-auto select-text">
      {/* =====================================================================
          顶部状态验证控制栏（方便一键切换验证：无设备 / 配对码错误/过期/已使用 / 保存目录失败）
         ===================================================================== */}
      <div
        style={{
          backgroundColor: 'var(--cf-surface-secondary)',
          borderBottom: '1px solid var(--cf-border-strong)',
        }}
        className="flex shrink-0 flex-wrap items-center justify-between gap-2 px-6 py-2"
      >
        <div className="flex items-center gap-2">
          <span
            style={{
              backgroundColor: 'var(--cf-primary)',
              color: 'var(--cf-surface-card)',
            }}
            className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold"
          >
            CONNECTOR HUB
          </span>
          <h1 className="text-[14px] font-bold text-[var(--cf-text-primary)]">
            一、Agent 连接（设备配对 · 两层授权边界 · 端点能力与目录白名单）
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-[11px]">
          <span className="text-[var(--cf-text-tertiary)]">边界状态验证:</span>
          <button
            type="button"
            onClick={() => setEmptyDevicesDemo((v) => !v)}
            style={{
              backgroundColor: emptyDevicesDemo
                ? 'var(--cf-primary)'
                : 'var(--cf-surface-card)',
              color: emptyDevicesDemo
                ? 'var(--cf-surface-card)'
                : 'var(--cf-text-secondary)',
              borderColor: 'var(--cf-border-strong)',
            }}
            className="h-[22px] border px-2 font-medium"
          >
            {emptyDevicesDemo ? '✓ 已开启：没有任何设备态' : '模拟：没有任何设备'}
          </button>

          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
            }}
            className="flex items-center border p-0.5"
          >
            <span className="px-1.5 text-[var(--cf-text-tertiary)]">配对码结果:</span>
            {[
              { id: 'ok', label: '正常授权' },
              { id: 'invalid', label: '配对码错误' },
              { id: 'expired', label: '已过期' },
              { id: 'used', label: '已使用' },
            ].map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => {
                  setPairingSimMode(m.id as typeof pairingSimMode)
                  setPairingFeedback(null)
                }}
                style={{
                  backgroundColor:
                    pairingSimMode === m.id
                      ? m.id === 'ok'
                        ? 'var(--cf-primary)'
                        : 'var(--cf-danger)'
                      : 'transparent',
                  color:
                    pairingSimMode === m.id
                      ? 'var(--cf-surface-card)'
                      : 'var(--cf-text-secondary)',
                }}
                className="h-[20px] px-1.5 font-medium"
              >
                {m.label}
              </button>
            ))}
          </div>

          <label className="flex cursor-pointer items-center gap-1 border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] px-2 py-0.5 text-[var(--cf-danger)]">
            <input
              type="checkbox"
              checked={simulateDirSaveError}
              onChange={(e) => setSimulateDirSaveError(e.target.checked)}
              className="h-3 w-3 accent-[#B91C1C]"
            />
            <span>模拟：保存目录失败</span>
          </label>
        </div>
      </div>

      <div className="mx-auto w-full max-w-[1380px] space-y-5 px-6 py-5">
        {/* ===================================================================
            第一区：双栏顶卡 —— 左「连接一台设备」 | 右「两层授权，别混在一起」
           =================================================================== */}
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
          {/* 左卡：连接一台设备（三步说明 + 等宽大字距配对码输入框 + 授权这台设备按钮） */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="flex flex-col justify-between border p-4 lg:col-span-6"
          >
            <div>
              <div className="flex items-center justify-between border-b border-[var(--cf-border-subtle)] pb-2">
                <h2 className="text-[15px] font-bold text-[var(--cf-text-primary)]">
                  连接一台设备
                </h2>
                <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]">
                  DEVICE PAIRING PROTOCOL
                </span>
              </div>

              {/* 三步说明 */}
              <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-3 text-[12px]">
                <div
                  style={{
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderColor: 'var(--cf-border-subtle)',
                  }}
                  className="border p-2.5"
                >
                  <div className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                    STEP 1
                  </div>
                  <div className="mt-1 text-[var(--cf-text-primary)]">
                    在目标电脑执行{' '}
                    <code className="font-mono-tabular font-semibold text-[var(--cf-primary)]">
                      npx coflow-connector login
                    </code>
                  </div>
                </div>

                <div
                  style={{
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderColor: 'var(--cf-border-subtle)',
                  }}
                  className="border p-2.5"
                >
                  <div className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                    STEP 2
                  </div>
                  <div className="mt-1 text-[var(--cf-text-primary)]">
                    终端显示形如{' '}
                    <code className="font-mono-tabular font-semibold text-[var(--cf-warning)]">
                      ABCD-2345
                    </code>{' '}
                    的配对码
                  </div>
                </div>

                <div
                  style={{
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderColor: 'var(--cf-border-subtle)',
                  }}
                  className="border p-2.5"
                >
                  <div className="font-mono-tabular text-[11px] font-bold text-[var(--cf-primary)]">
                    STEP 3
                  </div>
                  <div className="mt-1 text-[var(--cf-text-primary)]">
                    在下方输入配对码并完成设备绑定与目录授权
                  </div>
                </div>
              </div>
            </div>

            {/* 配对码输入框（等宽、大字距）+「授权这台设备」按钮 */}
            {isObserver ? (
              <div className="mt-3.5 border border-dashed border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] px-3 py-2 text-[12px] text-[var(--cf-text-secondary)]">
                当前身份只读（观察员）：配对码输入框与设备授权入口已隐藏。
              </div>
            ) : (
              <form onSubmit={handleAuthorizeDevice} className="mt-3.5">
                <div className="flex flex-wrap items-center gap-2.5">
                  <input
                    type="text"
                    maxLength={9}
                    value={pairingCode}
                    onChange={(e) => {
                      setPairingCode(e.target.value.toUpperCase())
                      setPairingFeedback(null)
                    }}
                    placeholder="ABCD-2345"
                    style={{
                      backgroundColor: 'var(--cf-surface-secondary)',
                      borderColor:
                        pairingFeedback?.type === 'error'
                          ? 'var(--cf-danger)'
                          : 'var(--cf-primary)',
                      borderRadius: 'var(--cf-radius-control)',
                    }}
                    className="font-mono-tabular h-[38px] w-56 border-2 px-3 text-center text-[17px] font-bold tracking-[0.25em] text-[var(--cf-text-primary)] uppercase outline-none"
                  />
                  <CfButton
                    variant="primary"
                    size="default"
                    onClick={() => {}}
                  >
                    <span onClick={handleAuthorizeDevice}>授权这台设备</span>
                  </CfButton>
                  <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                    当前模式：{pairingSimMode === 'ok' ? '验证通过' : `模拟「${pairingSimMode}」`}
                  </span>
                </div>

                {/* 配对码错误 / 过期 / 已使用 / 成功反馈 */}
                {pairingFeedback && (
                  <div
                    style={{
                      backgroundColor:
                        pairingFeedback.type === 'error'
                          ? 'var(--cf-danger-bg)'
                          : 'var(--cf-success-bg)',
                      borderColor:
                        pairingFeedback.type === 'error'
                          ? 'var(--cf-danger)'
                          : 'var(--cf-success)',
                      color:
                        pairingFeedback.type === 'error'
                          ? 'var(--cf-danger)'
                          : 'var(--cf-success)',
                    }}
                    className="mt-2.5 border-l-4 px-3 py-1.5 text-[12px] font-semibold"
                  >
                    {pairingFeedback.message}
                  </div>
                )}
              </form>
            )}
          </div>

          {/* 右卡：「两层授权，别混在一起」 */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="flex flex-col justify-between border p-4 lg:col-span-6"
          >
            <div className="flex items-center justify-between border-b border-[var(--cf-border-subtle)] pb-2">
              <h2 className="text-[15px] font-bold text-[var(--cf-text-primary)]">
                两层授权，别混在一起
              </h2>
              <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-text-tertiary)]">
                TWO-TIER AUTH SEPARATION
              </span>
            </div>

            <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2 flex-1">
              {/* 第一块：工具授权 · 归原工具 */}
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderColor: 'var(--cf-border-strong)',
                  borderLeft: '4px solid var(--cf-neutral)',
                }}
                className="flex flex-col justify-between border p-3.5"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[13px] font-bold text-[var(--cf-text-primary)]">
                      工具授权 · 归原工具
                    </span>
                    <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                      LAYER 01
                    </span>
                  </div>
                  <p className="mt-2 text-[13px] font-medium leading-[20px] text-[var(--cf-text-primary)]">
                    Claude Code 登录没登录、用哪个模型，平台不碰。
                  </p>
                  <p className="mt-1.5 text-[11px] leading-[17px] text-[var(--cf-text-secondary)]">
                    成员电脑上的 AI 工具使用各自的官方账号或本地 API Key 鉴权，CoFlow 不中转模型流量、不索取任何模型密钥。
                  </p>
                </div>
                <div className="mt-2 border-t border-[var(--cf-border-subtle)] pt-1.5 font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                  边界：模型计费与账号登录完全驻留成员本机
                </div>
              </div>

              {/* 第二块：项目授权 · 归 CoFlow */}
              <div
                style={{
                  backgroundColor: 'var(--cf-primary-tint)',
                  borderColor: 'var(--cf-primary)',
                  borderLeft: '4px solid var(--cf-primary)',
                }}
                className="flex flex-col justify-between border p-3.5"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[13px] font-bold text-[var(--cf-primary)]">
                      项目授权 · 归 CoFlow
                    </span>
                    <span className="font-mono-tabular text-[10px] font-semibold text-[var(--cf-primary)]">
                      LAYER 02
                    </span>
                  </div>
                  <p className="mt-2 text-[13px] font-medium leading-[20px] text-[var(--cf-text-primary)]">
                    能进哪个项目、读哪些任务、写哪些目录、回传哪些事件。
                  </p>
                  <p className="mt-1.5 text-[11px] leading-[17px] text-[var(--cf-text-secondary)]">
                    由项目负责人与设备持有人在下方端点列表中显式配置可写目录白名单，超出白名单的文件修改将被拦截。
                  </p>
                </div>
                <div className="mt-2 border-t border-[var(--cf-primary-border)] pt-1.5 font-mono-tabular text-[10px] font-semibold text-[var(--cf-primary)]">
                  边界：最小权限沙箱 + 产物哈希强制审计
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ===================================================================
            第二区：设备列表 + 嵌套 Agent 端点（或「没有任何设备」空状态）
           =================================================================== */}
        {activeDevices.length === 0 ? (
          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-card)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="flex flex-col items-center justify-center border border-dashed px-6 py-12 text-center"
          >
            <div
              style={{
                backgroundColor: 'var(--cf-surface-secondary)',
                borderColor: 'var(--cf-border-strong)',
              }}
              className="mb-3 flex h-11 w-11 items-center justify-center border font-mono-tabular text-[15px] font-bold text-[var(--cf-primary)]"
            >
              MCP
            </div>
            <h3 className="text-[15px] font-bold text-[var(--cf-text-primary)]">
              当前尚未接入任何成员设备
            </h3>
            <p className="mt-1.5 text-[13px] font-semibold text-[var(--cf-primary)]">
              没有设备也能用完整流程——产物可以用人工回传
            </p>
            <p className="mt-1 max-w-lg text-[12px] text-[var(--cf-text-secondary)]">
              您仍可在「任务详情」或「产物与验收」页手动登记提交号、文件路径与评测报告完成验收闭环；如需接入本地 AI 工具，请在上方输入配对码。
            </p>
            <div className="mt-4">
              <CfButton
                variant="secondary"
                size="sm"
                onClick={() => setEmptyDevicesDemo(false)}
              >
                恢复示例已配对设备 (2 台设备 · 4 个端点)
              </CfButton>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-[14px] font-bold text-[var(--cf-text-primary)]">
                已授权设备与 Agent 端点列表（共 {activeDevices.length} 台设备 ·{' '}
                {activeDevices.reduce((acc, d) => acc + d.endpoints.length, 0)} 个端点）
              </h2>
              <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                固定列宽台账布局 · 支持快速垂直扫视能力等级与降级原因
              </span>
            </div>

            {activeDevices.map((dev) => (
              <div
                key={dev.id}
                style={{
                  backgroundColor: 'var(--cf-surface-card)',
                  borderColor: 'var(--cf-border-strong)',
                  boxShadow: 'var(--cf-shadow-card)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="overflow-hidden border"
              >
                {/* 设备行：设备名、系统、在线状态、配对时间、「撤销」按钮 */}
                <div
                  style={{
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderBottom: '1px solid var(--cf-border-strong)',
                  }}
                  className="flex flex-wrap items-center justify-between gap-3 px-4 py-2.5"
                >
                  <div className="flex flex-wrap items-center gap-3">
                    <span
                      style={{
                        backgroundColor: dev.online
                          ? 'var(--cf-success-bg)'
                          : 'var(--cf-surface-tertiary)',
                        color: dev.online
                          ? 'var(--cf-success)'
                          : 'var(--cf-text-tertiary)',
                        borderColor: dev.online
                          ? 'var(--cf-success-border)'
                          : 'var(--cf-border-strong)',
                      }}
                      className="inline-flex h-[20px] items-center gap-1.5 border px-2 text-[11px] font-semibold"
                    >
                      <span
                        style={{
                          backgroundColor: dev.online
                            ? 'var(--cf-success)'
                            : 'var(--cf-text-muted)',
                        }}
                        className="h-2 w-2 rounded-full"
                      />
                      <span>{dev.online ? '在线' : '离线'}</span>
                    </span>

                    <span className="font-mono-tabular text-[14px] font-bold text-[var(--cf-text-primary)]">
                      {dev.deviceName}
                    </span>

                    <span className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] px-2 py-0.5 font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                      系统：{dev.osInfo}
                    </span>

                    <span className="text-[12px] text-[var(--cf-text-secondary)]">
                      归属成员：<strong>{dev.ownerName}</strong>
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                      配对时间：{dev.pairedAt}
                    </span>
                    {!isObserver && (
                      <CfButton
                        variant="danger"
                        size="xs"
                        onClick={() => handleRevokeDevice(dev)}
                      >
                        撤销
                      </CfButton>
                    )}
                  </div>
                </div>

                {/* 设备下属的 Agent 端点列表（高可扫读性分栏） */}
                <div className="divide-y divide-[var(--cf-border-subtle)]">
                  {dev.endpoints.map((ep) => {
                    const isEditingDir = editingDirEpId === ep.id
                    const saveStatus = dirSaveStatusMap[ep.id]

                    return (
                      <div key={ep.id} className="p-3.5 text-[12px]">
                        {/* 端点主信息行：固定左锚点（能力徽标 + 工具名版本）+ 中部说明与绑定项目 + 右侧心跳与「授权目录」按钮 */}
                        <div className="grid grid-cols-1 gap-3 lg:grid-cols-12 items-start">
                          {/* 左锚点 (4 列)：能力等级徽标 + 工具名与版本 */}
                          <div className="lg:col-span-4 flex items-start gap-2.5">
                            <CapabilityBadge level={ep.capability} />
                            <div>
                              <div className="font-mono-tabular text-[13px] font-bold text-[var(--cf-text-primary)]">
                                {ep.toolName}{' '}
                                <span className="text-[11px] font-normal text-[var(--cf-primary)]">
                                  {ep.version}
                                </span>
                              </div>
                              <div className="mt-0.5 font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                                绑定项目：{ep.boundProject}
                              </div>
                            </div>
                          </div>

                          {/* 中栏 (5 列)：能力说明 + 半自动/手动强制显示的降级原因 */}
                          <div className="lg:col-span-5 space-y-1.5">
                            <div className="text-[12px] text-[var(--cf-text-secondary)]">
                              <strong>能力说明：</strong>
                              {ep.capabilityDesc}
                            </div>

                            {/* 半自动 / 手动端点必须显示降级原因 + 补充"只能半自动或手动执行，不能 coflow run" */}
                            {ep.degradeReason && (
                              <div
                                style={{
                                  backgroundColor: 'var(--cf-warning-bg)',
                                  borderColor: 'var(--cf-warning)',
                                  borderLeftWidth: '3px',
                                  color: 'var(--cf-warning)',
                                }}
                                className="border px-2.5 py-1.5 text-[11px] leading-[16px]"
                              >
                                <div className="font-bold">
                                  降级原因：{ep.degradeReason}
                                </div>
                                <div className="mt-0.5 font-mono-tabular font-semibold">
                                  → {ep.degradeSupplement}
                                </div>
                              </div>
                            )}

                            {/* 当前已授权目录速览 */}
                            <div className="flex flex-wrap items-center gap-1.5 font-mono-tabular text-[11px]">
                              <span className="text-[var(--cf-text-tertiary)]">
                                已授权可写目录:
                              </span>
                              <code className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)] px-1.5 py-0.5 text-[var(--cf-primary)]">
                                {ep.authorizedDirs}
                              </code>
                            </div>
                          </div>

                          {/* 右栏 (3 列)：最后心跳 + 「授权目录」操作按钮 */}
                          <div className="lg:col-span-3 flex flex-col items-end justify-between gap-2">
                            <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                              最后心跳：{ep.lastHeartbeat}
                            </span>
                            {!isObserver && (
                              <CfButton
                                variant={isEditingDir ? 'primary' : 'secondary'}
                                size="xs"
                                onClick={() => {
                                  setEditingDirEpId(isEditingDir ? null : ep.id)
                                  setDirSaveStatusMap((prev) => {
                                    const next = { ...prev }
                                    delete next[ep.id]
                                    return next
                                  })
                                }}
                              >
                                {isEditingDir ? '收起目录配置 ▲' : '授权目录 ▾'}
                              </CfButton>
                            )}
                          </div>
                        </div>

                        {/* 展开的「授权目录」一行输入（多个路径用逗号分隔）+ 保存 */}
                        {isEditingDir && !isObserver && (
                          <div
                            style={{
                              backgroundColor: 'var(--cf-surface-secondary)',
                              borderColor: 'var(--cf-primary-border)',
                            }}
                            className="mt-2.5 border p-2.5"
                          >
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="text-[11px] font-semibold text-[var(--cf-primary)]">
                                授权可写目录（多个路径用逗号分隔）：
                              </span>
                              <input
                                type="text"
                                value={dirInputMap[ep.id] ?? ep.authorizedDirs}
                                onChange={(e) =>
                                  setDirInputMap((prev) => ({
                                    ...prev,
                                    [ep.id]: e.target.value,
                                  }))
                                }
                                placeholder="例如：src/retrieval/**, artifacts/eval/**, tests/**"
                                className="font-mono-tabular h-[28px] flex-1 border border-[var(--cf-border-strong)] bg-[var(--cf-surface-card)] px-2.5 text-[12px] text-[var(--cf-text-primary)] outline-none focus:border-[var(--cf-primary)]"
                              />
                              <CfButton
                                variant="primary"
                                size="sm"
                                onClick={() => handleSaveEndpointDirs(dev.id, ep.id)}
                              >
                                保存
                              </CfButton>
                            </div>

                            {saveStatus && (
                              <div
                                style={{
                                  color: saveStatus.ok
                                    ? 'var(--cf-success)'
                                    : 'var(--cf-danger)',
                                }}
                                className="mt-1.5 text-[11px] font-semibold"
                              >
                                {saveStatus.msg}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ===================================================================
            第三区：已撤销设备区（设备名 + 撤销时间）
           =================================================================== */}
        <div
          style={{
            backgroundColor: 'var(--cf-surface-tertiary)',
            borderColor: 'var(--cf-border-strong)',
            borderRadius: 'var(--cf-radius-container)',
          }}
          className="border p-3.5"
        >
          <div className="mb-2 flex items-center justify-between">
            <span className="text-[12px] font-bold text-[var(--cf-text-secondary)]">
              已撤销设备区（Revoked Devices · 令牌已作废，仅保留安全审计记录）
            </span>
            <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
              共 {revokedDevices.length} 台历史设备
            </span>
          </div>

          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {revokedDevices.map((rev) => (
              <div
                key={rev.id}
                style={{
                  backgroundColor: 'var(--cf-surface-card)',
                  borderColor: 'var(--cf-border-subtle)',
                }}
                className="flex items-center justify-between border px-3 py-2 text-[11px] opacity-80"
              >
                <div>
                  <div className="font-mono-tabular font-semibold text-[var(--cf-text-secondary)] line-through">
                    {rev.deviceName}
                  </div>
                  <div className="text-[10px] text-[var(--cf-text-tertiary)]">
                    {rev.ownerName} · {rev.osInfo}
                  </div>
                </div>
                <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                  撤销于 {rev.revokedAt}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
