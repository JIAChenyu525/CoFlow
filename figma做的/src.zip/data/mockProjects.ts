import { CollaboratorAvatarItem, RoleType } from '../design-system/components'

export type ProjectStage = '定义' | '开发' | '联调' | '验收' | '归档'

export interface ProjectSummaryItem {
  id: string
  code: string
  stage: ProjectStage
  name: string
  goalSummary: string
  progress: number
  inProgressCount: number
  pendingAcceptCount: number
  blockedCount: number
  members: CollaboratorAvatarItem[]
  lastActiveTime: string
}

export interface ProjectTemplateSpec {
  id: 'blank' | 'software' | 'content' | 'competition'
  name: string
  description: string
  taskCount: number
  defaultCode: string
  defaultProjectName: string
  defaultOneLiner: string
  goal: string
  targetUsers: string
  scope: string
  nonGoals: string
  constraints: string
  acceptanceCriteria: string
  milestonePreview: string[]
  taskPreview: string[]
}

export interface CharterVersionRecord {
  version: string
  changeNote: string
  author: string
  time: string
}

export interface ProjectMemberAccount {
  id: string
  name: string
  short: string
  account: string
  role: RoleType
  isSelf?: boolean
}

export const ROLE_PERMISSION_DESCRIPTIONS: Record<RoleType, string> = {
  initiator: '目标决策权 + 章程修订权 + 最终验收裁决权 + 成员角色管理权',
  owner: '任务拆解指派权 + 决策确认权 + 人工验收签批权',
  reviewer: '产物证据核验权 + 验收结论签批权（通过/退回/补充材料）',
  member: '任务认领权 + 本地 Agent 派发与产物提交权 + 讨论澄清权',
  observer: '全局事实、章程与过程只读查阅权（无任何写入与签批权）',
}

export const INITIAL_PROJECTS: ProjectSummaryItem[] = [
  {
    id: 'prj-zx',
    code: 'ZX',
    stage: '联调',
    name: '多智能体企业知识库混合检索系统',
    goalSummary:
      '交付挑战杯与企业实测双达标的多智能体混合检索系统，在 50 万条异构文档上实现 Top-10 召回率 ≥ 93.0% 且 P99 延迟 ≤ 180ms。',
    progress: 72,
    inProgressCount: 2,
    pendingAcceptCount: 1,
    blockedCount: 2,
    members: [
      { id: 'm1', name: '林知夏', short: '林', kind: 'human' },
      { id: 'm2', name: '陈默', short: '陈', kind: 'human' },
      { id: 'm3', name: '周舟', short: '周', kind: 'human' },
      { id: 'a1', name: 'cursor-win-02', short: 'AI', kind: 'agent' },
      { id: 'm4', name: '苏哲', short: '苏', kind: 'human' },
      { id: 'm5', name: '许嘉树', short: '许', kind: 'human' },
      { id: 'a2', name: 'claude-code-01', short: 'CC', kind: 'agent' },
    ],
    lastActiveTime: '12 分钟前 (16:48)',
  },
  {
    id: 'prj-mcp',
    code: 'MCP2',
    stage: '开发',
    name: '跨平台本地 AI 连接器沙箱与目录授权网关',
    goalSummary:
      '为 Windows 与 WSL2 环境提供零密钥本地连接器守护进程，严格隔离文件读写白名单并自动生成产物 SHA-1 证据链。',
    progress: 54,
    inProgressCount: 4,
    pendingAcceptCount: 2,
    blockedCount: 0,
    members: [
      { id: 'm2', name: '陈默', short: '陈', kind: 'human' },
      { id: 'm5', name: '许嘉树', short: '许', kind: 'human' },
      { id: 'a1', name: 'cursor-win-02', short: 'AI', kind: 'agent' },
      { id: 'm1', name: '林知夏', short: '林', kind: 'human' },
    ],
    lastActiveTime: '45 分钟前 (16:15)',
  },
  {
    id: 'prj-wp',
    code: 'DOC8',
    stage: '验收',
    name: '2025 人工智能工程化实践年度技术白皮书',
    goalSummary:
      '联合 4 位撰稿人与校对 Agent 完成 8 章共 6.5 万字白皮书编纂、数据图表溯源核验及出版级排版定稿。',
    progress: 88,
    inProgressCount: 1,
    pendingAcceptCount: 3,
    blockedCount: 1,
    members: [
      { id: 'm4', name: '苏哲', short: '苏', kind: 'human' },
      { id: 'm3', name: '周舟', short: '周', kind: 'human' },
      { id: 'm6', name: '顾言', short: '顾', kind: 'human' },
      { id: 'a3', name: 'windsurf-03', short: 'WS', kind: 'agent' },
    ],
    lastActiveTime: '2 小时前 (14:50)',
  },
  {
    id: 'prj-eval',
    code: 'BMK1',
    stage: '归档',
    name: '第一阶段：金融财报跨页表格解析基准评测集',
    goalSummary:
      '构建 1,200 份真实上市公司财报跨页合并单元格解析评测集，已完成全部人工双盲交叉核验并封存归档。',
    progress: 100,
    inProgressCount: 0,
    pendingAcceptCount: 0,
    blockedCount: 0,
    members: [
      { id: 'm3', name: '周舟', short: '周', kind: 'human' },
      { id: 'm1', name: '林知夏', short: '林', kind: 'human' },
      { id: 'm2', name: '陈默', short: '陈', kind: 'human' },
    ],
    lastActiveTime: '3 天前 (05-11)',
  },
]

export const PROJECT_TEMPLATES: ProjectTemplateSpec[] = [
  {
    id: 'blank',
    name: '空白项目',
    description: '从零定义项目章程、首个里程碑与任务结构，适合高度定制化议题。',
    taskCount: 0,
    defaultCode: '',
    defaultProjectName: '',
    defaultOneLiner: '',
    goal: '',
    targetUsers: '',
    scope: '',
    nonGoals: '',
    constraints: '',
    acceptanceCriteria: '',
    milestonePreview: [],
    taskPreview: [],
  },
  {
    id: 'software',
    name: '软件小团队',
    description: '面向 2–8 人前后端与 AI 协同开发，预置接口契约、联调与回归验收流程。',
    taskCount: 6,
    defaultCode: 'SW01',
    defaultProjectName: '轻量级多 Agent 检索服务与接口联调',
    defaultOneLiner: '基于统一契约完成核心检索模块开发、单元测试与沙箱性能压测。',
    goal: '在两周迭代内交付可独立部署的混合检索微服务，接口可用性 ≥ 99.9%，P99 延迟 ≤ 180ms。',
    targetUsers: '内部业务系统研发工程师与知识库管理员',
    scope: '1) OpenAPI 接口契约规范；2) 向量与关键词混合检索核心模块；3) 自动化回归与压测报告。',
    nonGoals: '本期不开发多租户计费后台，不迁移三年以前的历史冷数据。',
    constraints: '单节点内存占用 ≤ 8GB；所有外部配置必须支持环境变量注入；严禁硬编码密钥。',
    acceptanceCriteria:
      '1. 核心接口单元测试覆盖率 ≥ 85% 且 CI 全绿\n2. 16 并发压测下 P99 响应时间 ≤ 180ms\n3. 附带可复现 Docker Compose 启动脚本与压测 CSV 证据',
    milestonePreview: ['M1 · 架构契约与数据模型锁定', 'M2 · 核心模块研发与基准验收'],
    taskPreview: [
      'TSK-01 接口契约 OpenAPI 3.1 规范定义与错误码对齐',
      'TSK-02 文档切片与向量索引构建流水线实现',
      'TSK-03 混合检索与 Cross-Encoder 重排核心模块实现',
      'TSK-04 本地连接器异常断连重试与幂等队列开发',
      'TSK-05 2,000 条基准回归测试与 P99 延迟压测报告',
      'TSK-06 容器化构建镜像与生产上线核对单签批',
    ],
  },
  {
    id: 'content',
    name: '内容创作',
    description: '面向深度报告、白皮书、课程与多模态内容生产，强调事实核查与多轮审校。',
    taskCount: 6,
    defaultCode: 'CNT4',
    defaultProjectName: '2025 多智能体工程实践深度研究白皮书',
    defaultOneLiner: '多人协同撰稿 + AI 辅助文献综述与数据核查，交付可出版级行业白皮书。',
    goal: '完成 5 万字行业研究白皮书及配套数据图表集，所有引用数据 100% 附带原始出处快照。',
    targetUsers: '技术决策者、高校研究者与行业分析师',
    scope: '1) 全书三级提纲与术语表；2) 6 大核心章节正文；3) 24 张标准化矢量信息图与数据表。',
    nonGoals: '不包含线下发布会会务执行，不制作长视频纪录片。',
    constraints: '严禁使用未经人工核实的 AI 幻觉引用；全书专业术语译名必须与术语表严格一致。',
    acceptanceCriteria:
      '1. 每章引用文献与统计数据均附带原始网页/论文 PDF 页码证据\n2. 查重率 < 5%，术语一致性检查零冲突\n3. 经主编与外部评审双人通读签批',
    milestonePreview: ['M1 · 大纲立项与信源文献库封存', 'M2 · 章节撰稿、交叉事实核查与终审定稿'],
    taskPreview: [
      'TSK-01 全书三级目录大纲与核心论点章程锁定',
      'TSK-02 120 篇核心论文与行业报告信源库清洗归档',
      'TSK-03 上篇（架构与协议篇）初稿撰写与案例引用标注',
      'TSK-04 下篇（评测与落地篇）初稿撰写与实测图表绘制',
      'TSK-05 全文数据出处真实性交叉核验（防幻觉审计）',
      'TSK-06 统稿润色、排版样书导出与终审签批',
    ],
  },
  {
    id: 'competition',
    name: '竞赛项目',
    description: '面向挑战杯、互联网+、Kaggle/ACM 等学科与算法竞赛，统筹代码、论文与路演答辩。',
    taskCount: 6,
    defaultCode: 'CMP9',
    defaultProjectName: '挑战杯人工智能专项赛：工业知识库智能问答系统',
    defaultOneLiner: '兼顾算法排行榜刷分、技术申报书撰写与 5 分钟现场路演答辩的全闭环管理。',
    goal: '在赛题评测集上冲刺全国前 5% 精度指标，并交付完整的申报书、查新报告与实机路演系统。',
    targetUsers: '竞赛评委专家组、赛题合作企业技术团队',
    scope: '1) 赛题定制检索与重排算法源码；2) 2.5 万字技术申报书与附件证明；3) 离线可演示路演台与答辩 PPT。',
    nonGoals: '不在赛期内重写底层推理框架 C++ 算子。',
    constraints: '严格遵守赛题算力限制（单卡 24GB 显存）；提交截止时间前 24 小时冻结主干代码。',
    acceptanceCriteria:
      '1. 官方验证集综合得分 F1 ≥ 92.5% 且附带完整复现脚本\n2. 申报书格式、查新报告与企业应用证明原件齐备\n3. 路演演示系统在断网离线环境下连续演示 10 次零报错',
    milestonePreview: ['M1 · 赛题基线跑通与申报书框架锁定', 'M2 · 算法冲榜、离线演示包封存与模拟答辩'],
    taskPreview: [
      'TSK-01 赛题评分规则拆解与 Baseline 评测流水线搭建',
      'TSK-02 领域难例数据增强与多路融合重排冲榜实验',
      'TSK-03 离线防断网实机演示系统与可视化大屏封装',
      'TSK-04 挑战杯技术申报书正文与架构图撰写',
      'TSK-05 企业实测应用证明与第三方评测报告盖章归档',
      'TSK-06 终审 20 页答辩 PPT 与评委高频追问 Q&A 手册',
    ],
  },
]

export const INITIAL_CHARTER_HISTORY: CharterVersionRecord[] = [
  {
    version: 'v2.4.0',
    changeNote: '新增 §4 硬性约束「单次检索 P99 延迟 ≤ 180ms」与 16 路并发压测验收口径。',
    author: '林知夏',
    time: '2025-05-14 10:02',
  },
  {
    version: 'v2.3.0',
    changeNote: '明确 §3 非目标「放弃 70B 全量微调，全面转向 BGE-M3 + 轻量重排架构」。',
    author: '林知夏',
    time: '2025-05-12 18:20',
  },
  {
    version: 'v2.2.0',
    changeNote: '将标准评测集规模由 1,500 条扩充至 2,400 条脱敏工业问答对。',
    author: '陈默',
    time: '2025-05-10 14:05',
  },
  {
    version: 'v2.1.0',
    changeNote: '补充政务云实测网关双向 TLS 鉴权与数据脱敏合规红线条款。',
    author: '林知夏',
    time: '2025-05-08 11:30',
  },
  {
    version: 'v2.0.0',
    changeNote: '项目立项初始章程基线发布。',
    author: '林知夏',
    time: '2025-05-06 09:15',
  },
]

export const INITIAL_MEMBER_ACCOUNTS: ProjectMemberAccount[] = [
  {
    id: 'm1',
    name: '林知夏',
    short: '林',
    account: 'linzhixia@coflow.dev',
    role: 'initiator',
    isSelf: true,
  },
  {
    id: 'm2',
    name: '陈默',
    short: '陈',
    account: 'chenmo@coflow.dev',
    role: 'owner',
  },
  {
    id: 'm3',
    name: '周舟',
    short: '周',
    account: 'zhouzhou@lab.edu.cn',
    role: 'reviewer',
  },
  {
    id: 'm4',
    name: '苏哲',
    short: '苏',
    account: 'suzhe@lab.edu.cn',
    role: 'member',
  },
  {
    id: 'm5',
    name: '许嘉树',
    short: '许',
    account: 'xujiashu@coflow.dev',
    role: 'member',
  },
  {
    id: 'm6',
    name: '顾言',
    short: '顾',
    account: 'guyan@advisor.edu.cn',
    role: 'observer',
  },
]
