import { TaskStatus, PriorityLevel } from '../design-system/components'

export interface TaskArtifactItem {
  id: string
  type: '代码补丁' | '评测报告' | '数据集快照' | '联调日志' | '设计文档'
  name: string
  location: string // 提交号 / 路径 / 链接
  version: string
  submitter: string
  time: string
}

export interface AcceptanceCriterionResult {
  criterion: string
  passed: boolean
}

export interface TaskAcceptanceRecord {
  id: string
  conclusion: '通过' | '退回' | '补充材料'
  reviewer: string
  itemResults: AcceptanceCriterionResult[]
  comment: string
  time: string
}

export interface TaskLeaseInfo {
  status: '待领取' | '已接受' | '执行中'
  endpointName: string
  contextId: string
  expiresAt: string
}

export interface TaskDependencyRef {
  id: string
  title: string
  status: TaskStatus
}

export interface CoFlowTask {
  id: string
  title: string
  status: TaskStatus
  priority: PriorityLevel
  reworkRound: number // 0 表示首次，1 表示 R1，2 表示 R2
  dueDate: string
  isOverdue?: boolean
  assigneeName: string | null
  assigneeShort: string | null
  assigneeKind?: 'human' | 'agent'
  reviewerName: string
  milestone: string
  weight: number // 工作量权重
  definitionVersion: number
  createdAt: string
  updatedAt: string
  projectName: string
  // 任务定义卡 5 要素
  description: string
  inputMaterials: string[]
  workScope: string[]
  nonWorkScope: string[]
  acceptanceCriteria: string[]
  // 阻塞或旁路原因
  blockerReason?: string
  blockerNeed?: string
  pauseReason?: string
  cancelReason?: string
  // 关联列表
  artifacts: TaskArtifactItem[]
  acceptanceRecords: TaskAcceptanceRecord[]
  dependencies: TaskDependencyRef[]
  currentLease: TaskLeaseInfo | null
  // 上下文包专属配置
  allowedWritePaths: string[]
  forbiddenPaths: string[]
}

export interface AgentDispatchCandidate {
  id: string
  toolName: string
  version: string
  ownerName: string
  capability: 'auto' | 'semi' | 'manual'
  totalScore: number
  recommended: boolean
  reasons: {
    delta: string
    text: string
    positive: boolean
  }[]
}

export const DISPATCH_CANDIDATES: AgentDispatchCandidate[] = [
  {
    id: 'ep-cursor-02',
    toolName: 'Cursor MCP Connector',
    version: 'v1.4.2',
    ownerName: '陈默 (Windows 11 工作站)',
    capability: 'auto',
    totalScore: 95,
    recommended: true,
    reasons: [
      { delta: '+25', text: '可自动执行', positive: true },
      { delta: '+5', text: '空闲', positive: true },
      { delta: '+15', text: '授权目录覆盖任务范围 (src/retrieval/**)', positive: true },
    ],
  },
  {
    id: 'ep-claude-01',
    toolName: 'Claude Code CLI',
    version: 'v0.9.8',
    ownerName: '许嘉树 (WSL2 Ubuntu)',
    capability: 'semi',
    totalScore: 45,
    recommended: false,
    reasons: [
      { delta: '+10', text: '半自动受控执行（需人工确认写入）', positive: true },
      { delta: '+15', text: '授权目录覆盖任务范围', positive: true },
      { delta: '−30', text: '与执行中会话路径重叠 (scripts/clean_multimodal.py)', positive: false },
    ],
  },
  {
    id: 'ep-windsurf-03',
    toolName: 'Windsurf Local Bridge',
    version: 'v1.1.0',
    ownerName: '周舟 (Windows 11)',
    capability: 'auto',
    totalScore: 62,
    recommended: false,
    reasons: [
      { delta: '+25', text: '可自动执行', positive: true },
      { delta: '+5', text: '空闲', positive: true },
      { delta: '−18', text: '仅授权 artifacts/ 目录只读，不含 src/retrieval 写权限', positive: false },
    ],
  },
]

export const INITIAL_TASKS: CoFlowTask[] = [
  // 1. 待澄清 (clarify)
  {
    id: 'TSK-119',
    title: '评审答辩演示文稿与核心实验证据截图归档',
    status: 'clarify',
    priority: 'P2',
    reworkRound: 0,
    dueDate: '2025-05-19',
    assigneeName: '苏哲',
    assigneeShort: '苏',
    reviewerName: '林知夏',
    milestone: 'M4 · 竞赛答辩材料与终审路演',
    weight: 3,
    definitionVersion: 1,
    createdAt: '2025-05-13 10:15',
    updatedAt: '2025-05-14 09:30',
    projectName: '多智能体企业知识库混合检索系统',
    description: '整理挑战杯终审答辩所需的 20 页核心演示文稿，并嵌入混合检索实测对比图表。',
    inputMaterials: [], // 缺输入材料 -> 停留在待澄清
    workScope: ['docs/slides/final_defense.pptx', 'artifacts/figures/**'],
    nonWorkScope: ['不修改底层检索算法代码', '不重新跑全量 50 万条索引'],
    acceptanceCriteria: [
      '包含 BM25、稠密向量、混合重排三组 Recall@10 与 P99 延迟实测对照表',
      '所有数据图表均可追溯至已验收产物的 SHA-1 快照哈希',
    ],
    artifacts: [],
    acceptanceRecords: [],
    dependencies: [{ id: 'TSK-108', title: '向量检索模块召回率评测与章程指标对齐', status: 'pending_accept' }],
    currentLease: null,
    allowedWritePaths: ['docs/slides/**', 'artifacts/figures/**'],
    forbiddenPaths: ['src/**', '.env*'],
  },
  {
    id: 'TSK-121',
    title: '长文档跨页表格语义切分边界异常样本抽检规则制定',
    status: 'clarify',
    priority: 'P1',
    reworkRound: 1,
    dueDate: '2025-05-17',
    assigneeName: null,
    assigneeShort: null,
    reviewerName: '周舟',
    milestone: 'M2 · 混合检索与重排核心联调',
    weight: 2,
    definitionVersion: 2,
    createdAt: '2025-05-12 14:00',
    updatedAt: '2025-05-14 11:20',
    projectName: '多智能体企业知识库混合检索系统',
    description: '针对财务年报与技术规范书中跨页表格被截断导致召回下降的问题，明确抽检样本集与合格阈值。',
    inputMaterials: ['data/raw_tables/sample_50.json'],
    workScope: ['docs/spec/table_chunking_rule.md'],
    nonWorkScope: ['暂不改动生产环境 PDF 解析器内核'],
    acceptanceCriteria: [], // 缺验收标准 -> 停留在待澄清
    artifacts: [],
    acceptanceRecords: [],
    dependencies: [{ id: 'TSK-104', title: '项目总章程 v2.4 检索精度基线条款锁定', status: 'done' }],
    currentLease: null,
    allowedWritePaths: ['docs/spec/**'],
    forbiddenPaths: ['src/**'],
  },

  // 2. 待认领 (unclaimed)
  {
    id: 'TSK-117',
    title: 'MCP 本地连接器断线重连指数退避与本地缓存队列实现',
    status: 'unclaimed',
    priority: 'P1',
    reworkRound: 0,
    dueDate: '2025-05-18',
    assigneeName: null,
    assigneeShort: null,
    reviewerName: '陈默',
    milestone: 'M3 · 企业实测接入与资质合规',
    weight: 5,
    definitionVersion: 2,
    createdAt: '2025-05-13 16:00',
    updatedAt: '2025-05-14 10:05',
    projectName: '多智能体企业知识库混合检索系统',
    description: '当成员机器休眠或政务云跳板机闪断时，连接器需在本地持久化未上报的产物哈希与心跳事件，恢复连接后按序重传。',
    inputMaterials: [
      'docs/protocol/mcp_connector_v1.2.md',
      'src/connector/transport.ts',
    ],
    workScope: [
      '实现指数退避重连器 (1s, 2s, 4s, max 60s)',
      '本地 SQLite/JSONL 离线事件缓冲队列与幂等去重校验',
    ],
    nonWorkScope: ['不更改服务端 WebSocket 鉴权握手协议'],
    acceptanceCriteria: [
      '模拟断网 5 分钟后恢复，100 条缓冲事件零丢失且顺序一致',
      '单测覆盖率 ≥ 85%，附带断网注入测试日志',
    ],
    artifacts: [],
    acceptanceRecords: [],
    dependencies: [{ id: 'TSK-104', title: '项目总章程 v2.4 检索精度基线条款锁定', status: 'done' }],
    currentLease: null,
    allowedWritePaths: ['src/connector/**', 'tests/connector/**'],
    forbiddenPaths: ['src/retrieval/**', '.env*'],
  },

  // 3. 已就绪 (ready —— 重点用于演示「派发给 Agent」卡片与加减分推荐理由)
  {
    id: 'TSK-114',
    title: '多路召回融合重排实验（RRF 与 Cross-Encoder 权重网格搜索）',
    status: 'ready',
    priority: 'P0',
    reworkRound: 0,
    dueDate: '2025-05-16',
    assigneeName: '陈默',
    assigneeShort: '陈',
    reviewerName: '周舟',
    milestone: 'M2 · 混合检索与重排核心联调',
    weight: 8,
    definitionVersion: 3,
    createdAt: '2025-05-11 09:20',
    updatedAt: '2025-05-14 14:10',
    projectName: '多智能体企业知识库混合检索系统',
    description:
      '在前置索引构建与基线评测完成后，对 BM25 稀疏检索与 BGE-M3 稠密检索的融合参数及 Top-K 重排截断窗口进行网格搜索，锁定兼顾召回率与 180ms 延迟的最优配置。',
    inputMaterials: [
      'artifacts/eval/bm25_baseline_2400.json (#4a81c0)',
      'artifacts/eval/dense_bge_m3_2400.json (#9f12e4)',
      '章程 §4 硬性约束：P99 延迟 ≤ 180ms，上下文包 ≤ 32k tok',
    ],
    workScope: [
      '编写 src/retrieval/hybrid_grid_search.py 自动遍历 RRF k∈[20,60] 与 Top-N∈[20,50]',
      '输出帕累托最优前沿对比表至 artifacts/eval/hybrid_pareto_v1.csv',
      '更新默认检索配置文件 config/retrieval.prod.yaml',
    ],
    nonWorkScope: [
      '禁止修改评测集标准答案 ground_truth_2400.jsonl',
      '不引入超过 1GB 显存占用的重排模型',
    ],
    acceptanceCriteria: [
      '1. 混合检索 Top-10 召回率 ≥ 94.5%（较单一稠密检索提升 ≥ 1.2%）',
      '2. 并发 16 路压测下 P99 响应延迟 ≤ 165ms（留出 15ms 安全余量）',
      '3. 提交完整的网格搜索 CSV 产物与可复现命令行日志',
    ],
    artifacts: [],
    acceptanceRecords: [],
    dependencies: [
      { id: 'TSK-104', title: '项目总章程 v2.4 检索精度基线条款锁定', status: 'done' },
      { id: 'TSK-105', title: '2,400 条脱敏工业问答评测集构建与哈希封存', status: 'done' },
    ],
    currentLease: null,
    allowedWritePaths: [
      'src/retrieval/**',
      'config/retrieval.prod.yaml',
      'artifacts/eval/**',
    ],
    forbiddenPaths: [
      'data/ground_truth_2400.jsonl',
      'certs/enterprise_private/**',
      '.env.production',
    ],
  },

  // 4. 进行中 (in_progress —— 演示当前租约与提交产物)
  {
    id: 'TSK-112',
    title: '多模态竞赛数据集清洗脚本与 OCR 损坏样本自动剔除',
    status: 'in_progress',
    priority: 'P1',
    reworkRound: 0,
    dueDate: '2025-05-16',
    assigneeName: '许嘉树',
    assigneeShort: '许',
    reviewerName: '周舟',
    milestone: 'M2 · 混合检索与重排核心联调',
    weight: 5,
    definitionVersion: 2,
    createdAt: '2025-05-12 11:00',
    updatedAt: '2025-05-14 16:12',
    projectName: '多智能体企业知识库混合检索系统',
    description: '对竞赛组委会提供的 1.2 万份图文混排 PDF 切片进行乱码率与 OCR 置信度筛查，剔除低质切片并输出清洗清单。',
    inputMaterials: [
      'data/multimodal_raw/manifest_12k.json',
      'scripts/ocr_quality_ rules.yaml',
    ],
    workScope: [
      '开发 scripts/clean_multimodal.py 并输出被剔除样本 ID 与原因报告',
      '生成清洗后数据集快照 manifest_cleaned_v1.json',
    ],
    nonWorkScope: ['不手工重绘损坏原图'],
    acceptanceCriteria: [
      '清洗后样本乱码率 < 0.3%，随机抽检 100 条合格率 100%',
      '输出完整的剔除样本审计表（含原文件哈希与触发规则编号）',
    ],
    artifacts: [
      {
        id: 'ART-112-01',
        type: '代码补丁',
        name: 'clean_multimodal.py',
        location: 'commit:4e82a19 (scripts/clean_multimodal.py)',
        version: 'v0.9.1',
        submitter: 'claude-code-01 (由许嘉树托管)',
        time: '2025-05-14 15:40',
      },
    ],
    acceptanceRecords: [],
    dependencies: [{ id: 'TSK-104', title: '项目总章程 v2.4 检索精度基线条款锁定', status: 'done' }],
    currentLease: {
      status: '执行中',
      endpointName: 'claude-code-01 (Claude Code CLI)',
      contextId: 'CTX-112-v2 (#5c81a9)',
      expiresAt: '2025-05-14 18:30:00 (剩余 01h 42m)',
    },
    allowedWritePaths: ['scripts/**', 'artifacts/dataset_audit/**'],
    forbiddenPaths: ['data/multimodal_raw/**', '.env*'],
  },

  // 5. 待验收 (pending_accept —— 演示验收结论面板、产物列表与退回返工记录)
  {
    id: 'TSK-108',
    title: '向量检索模块召回率评测与章程指标对齐',
    status: 'pending_accept',
    priority: 'P0',
    reworkRound: 1,
    dueDate: '2025-05-15',
    assigneeName: '陈默',
    assigneeShort: '陈',
    reviewerName: '周舟',
    milestone: 'M2 · 混合检索与重排核心联调',
    weight: 8,
    definitionVersion: 4,
    createdAt: '2025-05-08 10:00',
    updatedAt: '2025-05-14 11:26',
    projectName: '多智能体企业知识库混合检索系统',
    description:
      '基于章程 v2.4 锁定的 2,400 条工业评测集，完成 BGE-M3 向量检索与重排流水线的全量跑批评测，输出分场景 Recall@10、MRR@10 与 P99 延迟核验报告。',
    inputMaterials: [
      'data/ground_truth_2400.jsonl (#9a4c12)',
      'config/retrieval_bge_m3.yaml',
      '项目总章程 CHR-v2.4 (§1 目标与 §4 硬性约束)',
    ],
    workScope: [
      '执行全量 2,400 条评测查询并记录逐条 Top-10 命中结果',
      '按「技术文档 / 财务台账 / 规章制度」三个子域统计细分召回率',
      '归档 GPU 显存峰值与 P50/P95/P99 响应耗时分布',
    ],
    nonWorkScope: [
      '不在本任务内微调 Embedding 模型权重',
      '不包含前端 UI 检索框样式调整',
    ],
    acceptanceCriteria: [
      '1. 全量 2,400 条测试集 Top-10 综合召回率 (Recall@10) ≥ 93.0%',
      '2. 单次查询 P99 延迟 ≤ 180ms（在标准 RTX 4090 单卡测试环境下）',
      '3. 提交可复现评测脚本、原始指标 CSV 及困难负样本错误分析摘要',
    ],
    artifacts: [
      {
        id: 'ART-108-02',
        type: '评测报告',
        name: 'recall_bench_v1.4.csv',
        location: 'artifacts/eval/recall_bench_v1.4.csv (#7b91e0)',
        version: 'v1.4.2-rc',
        submitter: 'cursor-win-02 (陈默)',
        time: '2025-05-14 11:26',
      },
      {
        id: 'ART-108-01',
        type: '代码补丁',
        name: 'vector_eval_runner.py',
        location: 'commit:8c31f04 (src/retrieval/vector_eval.py)',
        version: 'v1.4.0',
        submitter: '陈默',
        time: '2025-05-12 17:45',
      },
    ],
    acceptanceRecords: [
      {
        id: 'ACC-108-R0',
        conclusion: '补充材料',
        reviewer: '周舟',
        time: '2025-05-12 20:15',
        itemResults: [
          { criterion: '1. 全量 2,400 条测试集 Recall@10 ≥ 93.0%', passed: true },
          { criterion: '2. 单次查询 P99 延迟 ≤ 180ms', passed: true },
          { criterion: '3. 提交可复现脚本、原始 CSV 及困难负样本分析', passed: false },
        ],
        comment:
          '首次提测 Recall@10 达到 94.1%，但产物包中遗漏了跨页表格子域的困难负样本错例分布表，请补充后进入 R1 复审。',
      },
    ],
    dependencies: [
      { id: 'TSK-104', title: '项目总章程 v2.4 检索精度基线条款锁定', status: 'done' },
    ],
    currentLease: {
      status: '已接受',
      endpointName: 'cursor-win-02 (Cursor MCP)',
      contextId: 'CTX-108-v4 (#8f3a9c)',
      expiresAt: '2025-05-14 19:00:00',
    },
    allowedWritePaths: ['src/retrieval/**', 'artifacts/eval/**'],
    forbiddenPaths: ['data/ground_truth_2400.jsonl', '.env*'],
  },

  // 6. 已完成 (done —— 演示「重新打开」产生新返工轮次)
  {
    id: 'TSK-104',
    title: '项目总章程 v2.4 检索精度基线与安全边界条款锁定',
    status: 'done',
    priority: 'P0',
    reworkRound: 0,
    dueDate: '2025-05-10',
    assigneeName: '林知夏',
    assigneeShort: '林',
    reviewerName: '陈默',
    milestone: 'M1 · 章程基线与评测集构建',
    weight: 5,
    definitionVersion: 3,
    createdAt: '2025-05-06 09:00',
    updatedAt: '2025-05-10 18:00',
    projectName: '多智能体企业知识库混合检索系统',
    description: '确立项目目标、交付范围、非目标、P99 延迟硬性约束与人工签批验收口径，作为全项目 L0 不可裁剪稳定层基线。',
    inputMaterials: ['立项任务书 v1.0', '企业安全合规红线清单'],
    workScope: ['docs/charter/CHR-v2.4.md'],
    nonWorkScope: ['不涉及具体代码实现细节'],
    acceptanceCriteria: [
      '明确量化召回率 (≥93.0%) 与延迟指标 (≤180ms)',
      '发起人、负责人、质量评审三方会签确认',
    ],
    artifacts: [
      {
        id: 'ART-104-01',
        type: '设计文档',
        name: 'CHR-v2.4-signed.md',
        location: 'docs/charter/CHR-v2.4.md (#1a90f2)',
        version: 'v2.4.0',
        submitter: '林知夏',
        time: '2025-05-10 16:30',
      },
    ],
    acceptanceRecords: [
      {
        id: 'ACC-104-01',
        conclusion: '通过',
        reviewer: '陈默',
        time: '2025-05-10 17:55',
        itemResults: [
          { criterion: '明确量化召回率 (≥93.0%) 与延迟指标 (≤180ms)', passed: true },
          { criterion: '发起人、负责人、质量评审三方会签确认', passed: true },
        ],
        comment: '各项指标清晰无歧义，已锁定为 L0 稳定层事实基线。',
      },
    ],
    dependencies: [],
    currentLease: null,
    allowedWritePaths: ['docs/charter/**'],
    forbiddenPaths: ['src/**'],
  },
  {
    id: 'TSK-105',
    title: '2,400 条脱敏工业问答评测集构建与哈希封存',
    status: 'done',
    priority: 'P0',
    reworkRound: 0,
    dueDate: '2025-05-11',
    assigneeName: '周舟',
    assigneeShort: '周',
    reviewerName: '林知夏',
    milestone: 'M1 · 章程基线与评测集构建',
    weight: 6,
    definitionVersion: 2,
    createdAt: '2025-05-07 10:00',
    updatedAt: '2025-05-11 19:20',
    projectName: '多智能体企业知识库混合检索系统',
    description: '完成 2,400 条涵盖技术文档、财务台账、规章制度的标准问答对清洗与证据段落标注。',
    inputMaterials: ['原始脱敏语料包 v1'],
    workScope: ['data/ground_truth_2400.jsonl'],
    nonWorkScope: ['不含未脱敏客户字段'],
    acceptanceCriteria: ['PII 敏感词扫描零检出', '人工双盲抽检 200 条准确率 ≥ 98%'],
    artifacts: [
      {
        id: 'ART-105-01',
        type: '数据集快照',
        name: 'ground_truth_2400.jsonl',
        location: 'data/ground_truth_2400.jsonl (#9a4c12)',
        version: 'v1.0.0',
        submitter: '周舟',
        time: '2025-05-11 17:10',
      },
    ],
    acceptanceRecords: [
      {
        id: 'ACC-105-01',
        conclusion: '通过',
        reviewer: '林知夏',
        time: '2025-05-11 19:20',
        itemResults: [
          { criterion: 'PII 敏感词扫描零检出', passed: true },
          { criterion: '人工双盲抽检 200 条准确率 ≥ 98%', passed: true },
        ],
        comment: '脱敏合规，双盲抽检准确率 99.0%，准予封存。',
      },
    ],
    dependencies: [{ id: 'TSK-104', title: '项目总章程 v2.4 检索精度基线条款锁定', status: 'done' }],
    currentLease: null,
    allowedWritePaths: ['data/**'],
    forbiddenPaths: ['.env*'],
  },

  // =========================================================================
  // 旁路状态任务 (已阻塞 blocked / 已暂停 paused / 已取消 cancelled)
  // =========================================================================
  {
    id: 'TSK-109',
    title: '企业实测政务云网关接口联调与白名单探针验证',
    status: 'blocked',
    priority: 'P0',
    reworkRound: 0,
    dueDate: '2025-05-12',
    isOverdue: true,
    assigneeName: '许嘉树',
    assigneeShort: '许',
    reviewerName: '陈默',
    milestone: 'M3 · 企业实测接入与资质合规',
    weight: 6,
    definitionVersion: 2,
    createdAt: '2025-05-08 14:00',
    updatedAt: '2025-05-14 14:15',
    projectName: '多智能体企业知识库混合检索系统',
    description: '打通本地检索服务与企业政务云测试网关的双向 TLS 鉴权与检索接口联调。',
    inputMaterials: ['网关接口规范 v2.1', '测试客户端证书模板'],
    workScope: ['src/gateway/enterprise_client.ts'],
    nonWorkScope: ['不改动企业侧防火墙硬件策略'],
    acceptanceCriteria: ['连续 1,000 次沙箱请求成功率 100%', '双向 TLS 握手耗时 < 40ms'],
    blockerReason: '政务云网关拦截连接器探针，等待补交加盖公章的企业营业执照副本扫描件后下发测试 Token',
    blockerNeed: '营业执照副本扫描件 + 沙箱网关白名单授权函',
    artifacts: [],
    acceptanceRecords: [],
    dependencies: [{ id: 'TSK-104', title: '项目总章程 v2.4 检索精度基线条款锁定', status: 'done' }],
    currentLease: null,
    allowedWritePaths: ['src/gateway/**'],
    forbiddenPaths: ['certs/private/**'],
  },
  {
    id: 'TSK-106',
    title: '评测集困难负样本混淆矩阵基线对齐',
    status: 'blocked',
    priority: 'P1',
    reworkRound: 2,
    dueDate: '2025-05-11',
    isOverdue: true,
    assigneeName: '苏哲',
    assigneeShort: '苏',
    reviewerName: '周舟',
    milestone: 'M2 · 混合检索与重排核心联调',
    weight: 4,
    definitionVersion: 3,
    createdAt: '2025-05-07 15:00',
    updatedAt: '2025-05-13 13:40',
    projectName: '多智能体企业知识库混合检索系统',
    description: '针对容易混淆的近似型号参数条款，构建困难负样本评测子集并输出混淆矩阵。',
    inputMaterials: ['data/ground_truth_2400.jsonl'],
    workScope: ['artifacts/eval/hard_negatives_matrix.csv'],
    nonWorkScope: ['不扩充总评测集条数'],
    acceptanceCriteria: ['覆盖全部 12 类高频混淆产品型号', '附带混淆矩阵热力图与错例列表'],
    blockerReason: '已逾期 3 天：上游业务专家尚未确认第 9–12 类近似型号的标准判别口径',
    blockerNeed: '业务专家签字确认的《近似型号判别表》',
    artifacts: [],
    acceptanceRecords: [],
    dependencies: [{ id: 'TSK-105', title: '2,400 条脱敏工业问答评测集构建与哈希封存', status: 'done' }],
    currentLease: null,
    allowedWritePaths: ['artifacts/eval/**'],
    forbiddenPaths: ['src/**'],
  },
  {
    id: 'TSK-116',
    title: '多语种（英/日）扩展检索实验子集构建',
    status: 'paused',
    priority: 'P3',
    reworkRound: 0,
    dueDate: '2025-05-25',
    assigneeName: '苏哲',
    assigneeShort: '苏',
    reviewerName: '林知夏',
    milestone: 'M4 · 竞赛答辩材料与终审路演',
    weight: 3,
    definitionVersion: 1,
    createdAt: '2025-05-10 11:00',
    updatedAt: '2025-05-12 18:00',
    projectName: '多智能体企业知识库混合检索系统',
    description: '构建 300 条中英日跨语种检索测试集作为答辩加分项储备。',
    inputMaterials: ['海外产品手册样本'],
    workScope: ['data/multilingual_300.jsonl'],
    nonWorkScope: ['不纳入主章程核心验收阻塞项'],
    acceptanceCriteria: ['300 条对齐语料人工校对完毕'],
    pauseReason: '优先保障 M2/M3 中文核心评测闭环，经发起人确认暂停至下周启动',
    artifacts: [],
    acceptanceRecords: [],
    dependencies: [],
    currentLease: null,
    allowedWritePaths: ['data/**'],
    forbiddenPaths: ['src/**'],
  },
  {
    id: 'TSK-102',
    title: '70B 开源基座大模型全量微调算力租赁与脚本准备',
    status: 'cancelled',
    priority: 'P3',
    reworkRound: 0,
    dueDate: '2025-05-09',
    assigneeName: '陈默',
    assigneeShort: '陈',
    reviewerName: '林知夏',
    milestone: 'M1 · 章程基线与评测集构建',
    weight: 8,
    definitionVersion: 1,
    createdAt: '2025-05-06 10:00',
    updatedAt: '2025-05-12 18:22',
    projectName: '多智能体企业知识库混合检索系统',
    description: '原计划租用 8×A100 节点对 70B 模型进行领域微调。',
    inputMaterials: ['算力报价单'],
    workScope: ['scripts/finetune_70b.sh'],
    nonWorkScope: [],
    acceptanceCriteria: ['完成 1 个 epoch 训练'],
    cancelReason: '依据已确认决策 [DEC-03] 与章程 §3 非目标：采用 BGE-M3 + 轻量重排架构即可达标，取消全量微调',
    artifacts: [],
    acceptanceRecords: [],
    dependencies: [],
    currentLease: null,
    allowedWritePaths: [],
    forbiddenPaths: ['**'],
  },
]
