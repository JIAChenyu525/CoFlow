import React, { useState } from 'react'
import {
  TaskStatusBadge,
  PriorityBadge,
  RoleBadge,
  CapabilityBadge,
  CfButton,
  SingleAvatar,
  AvatarGroup,
  ThinProgressBar,
  KeyValueTag,
  TaskStatus,
  RoleType,
  CollaboratorAvatarItem,
  RiskSeverity,
} from '../design-system/components'

/* ============================================================================
   数据类型定义
   ============================================================================ */

interface CharterSection {
  key: string
  code: string
  title: string
  summary: string
  details: string[]
}

interface MilestoneItem {
  id: string
  name: string
  progress: number
  doneTasks: number
  totalTasks: number
  status: TaskStatus
}

interface TeamMember {
  id: string
  name: string
  role: RoleType
  avatarShort: string
  kind: 'human' | 'agent'
  specialty: string
}

type MessageKind =
  | 'chat'
  | 'system'
  | 'proposal'
  | 'artifact'
  | 'blocker'
  | 'agent_report'

interface StreamMessage {
  id: string
  kind: MessageKind
  senderName?: string
  senderShort?: string
  senderRole?: RoleType
  isAgent?: boolean
  time: string
  content: string
  // 系统事件附加
  systemTag?: '创建项目' | '升级章程' | '验收退回' | '事实写入'
  systemRef?: string
  // 决策提案附加
  proposalId?: string
  proposalStatus?: 'pending' | 'confirmed'
  // 产物提交附加
  artifactName?: string
  artifactVersion?: string
  artifactPath?: string
  artifactType?: string
  // 阻塞求助附加
  blockerTaskRef?: string
  blockerNeed?: string
  // Agent 汇报附加
  agentTool?: string
  agentTaskRef?: string
  agentTokens?: string
  agentSummary?: string
}

interface WorkbenchRiskItem {
  id: string
  severity: RiskSeverity
  taskId: string
  taskName: string
  reason: string
}

interface PendingDecisionItem {
  id: string
  title: string
  proposer: string
  proposedAt: string
  sourceMsgId?: string
}

interface PendingAcceptanceTask {
  id: string
  title: string
  submitter: string
  waitDays: number
  artifactRef: string
  artifactVersion: string
  criteriaNote: string
}

interface BlockedTaskItem {
  id: string
  title: string
  waitDays: number
  needWhat: string
  owner: string
}

interface RunningAgentSession {
  id: string
  toolType: string
  capability: 'auto' | 'semi' | 'manual'
  taskId: string
  taskTitle: string
  declaredPath: string
  duration: string
  tokensUsed: string
}

interface ConfirmedDecisionItem {
  id: string
  title: string
  decider: string
  time: string
}

interface LatestArtifactItem {
  id: string
  type: '评测报告' | '代码补丁' | '数据集' | '章程快照' | '答辩材料'
  name: string
  version: string
  path: string
  time: string
}

interface AgentEndpointItem {
  id: string
  nodeName: string
  toolName: string
  ownerName: string
  activeSessions: number
  capability: 'auto' | 'semi'
  degradeNote?: string
}

/* ============================================================================
   初始高密度业务数据（真实贴合「工程师 + 内容/竞赛学生」协作场景）
   ============================================================================ */

const CHARTER_SECTIONS: CharterSection[] = [
  {
    key: 'goal',
    code: '§1',
    title: '项目目标',
    summary: '交付挑战杯与企业实测双达标的多智能体企业知识库混合检索系统，Top-10 召回率 ≥ 93.0%。',
    details: [
      '在 50 万条异构技术文档与业务台账上实现毫秒级混合检索（BM25 + 稠密向量 + 重排）。',
      '完成企业真实生产环境接口联调与现场答辩演示包闭环。',
    ],
  },
  {
    key: 'scope',
    code: '§2',
    title: '交付范围',
    summary: '混合检索引擎源码、评测基准集 (v1.4)、企业资质核验沙箱接口、竞赛答辩白皮书与演示台。',
    details: [
      '1) 检索引擎核心模块与 MCP 本地连接器插件；',
      '2) 标准评测集 2,400 条问答对及可复现评测日志 CSV；',
      '3) 终审答辩 PPT 与 5 分钟实机录屏。',
    ],
  },
  {
    key: 'non_goal',
    code: '§3',
    title: '非目标',
    summary: '本期不自研底层基座大模型，不介入客户旧版 ERP 前端改造，不支持移动端原生 App。',
    details: [
      '禁止将算力预算消耗在全量微调 70B 模型上；所有实验基于开源 Embedding + 轻量重排器完成。',
    ],
  },
  {
    key: 'constraints',
    code: '§4',
    title: '硬性约束',
    summary: '单次检索 P99 延迟 ≤ 180ms；单任务上下文包 ≤ 32k tok；严禁明文上传客户未脱敏数据。',
    details: [
      '所有 Agent 产出的代码与评测报告必须附带 SHA-1 短哈希与命令日志，否则系统拦截提测。',
    ],
  },
  {
    key: 'acceptance',
    code: '§5',
    title: '验收口径',
    summary: '仅凭「可复现实验快照 + 评审人人工签批结论」入库，讨论区口头确认一律不计入事实。',
    details: [
      '代码类任务须通过基准回归且无 P0 告警；文档与竞赛材料须经发起人与评审双人核验。',
    ],
  },
]

const INITIAL_MILESTONES: MilestoneItem[] = [
  {
    id: 'MS-01',
    name: 'M1 · 章程基线与评测集构建',
    progress: 100,
    doneTasks: 6,
    totalTasks: 6,
    status: 'done',
  },
  {
    id: 'MS-02',
    name: 'M2 · 混合检索与重排核心联调',
    progress: 75,
    doneTasks: 6,
    totalTasks: 8,
    status: 'pending_accept',
  },
  {
    id: 'MS-03',
    name: 'M3 · 企业实测接入与资质合规',
    progress: 40,
    doneTasks: 2,
    totalTasks: 5,
    status: 'blocked',
  },
  {
    id: 'MS-04',
    name: 'M4 · 竞赛答辩材料与终审路演',
    progress: 25,
    doneTasks: 1,
    totalTasks: 4,
    status: 'in_progress',
  },
]

const TEAM_MEMBERS: TeamMember[] = [
  {
    id: 'm1',
    name: '林知夏',
    role: 'initiator',
    avatarShort: '林',
    kind: 'human',
    specialty: '项目总控 / 架构章程',
  },
  {
    id: 'm2',
    name: '陈默',
    role: 'owner',
    avatarShort: '陈',
    kind: 'human',
    specialty: '检索引擎 / 任务主理',
  },
  {
    id: 'm3',
    name: '周舟',
    role: 'reviewer',
    avatarShort: '周',
    kind: 'human',
    specialty: '评测基准 / 质量评审',
  },
  {
    id: 'm4',
    name: '苏哲',
    role: 'member',
    avatarShort: '苏',
    kind: 'human',
    specialty: '内容策展 / 竞赛白皮书',
  },
  {
    id: 'm5',
    name: '许嘉树',
    role: 'member',
    avatarShort: '许',
    kind: 'human',
    specialty: '数据清洗 / 接口联调',
  },
  {
    id: 'm6',
    name: '顾言',
    role: 'observer',
    avatarShort: '顾',
    kind: 'human',
    specialty: '指导教师 / 外部观察员',
  },
]

const COLLABORATOR_AVATARS: CollaboratorAvatarItem[] = [
  { id: 'm1', name: '林知夏 (发起人)', short: '林', kind: 'human' },
  { id: 'm2', name: '陈默 (负责人)', short: '陈', kind: 'human' },
  { id: 'm3', name: '周舟 (评审)', short: '周', kind: 'human' },
  { id: 'a1', name: 'cursor-win-02 (Agent)', short: 'AI', kind: 'agent' },
  { id: 'm4', name: '苏哲 (成员)', short: '苏', kind: 'human' },
  { id: 'a2', name: 'claude-code-01 (Agent)', short: 'CC', kind: 'agent' },
  { id: 'm5', name: '许嘉树 (成员)', short: '许', kind: 'human' },
  { id: 'm6', name: '顾言 (观察员)', short: '顾', kind: 'human' },
]

const INITIAL_MESSAGES: StreamMessage[] = [
  {
    id: 'msg-1',
    kind: 'system',
    time: '09:15:00',
    systemTag: '创建项目',
    systemRef: 'PRJ-COFLOW-04',
    content: '林知夏 创建了项目并初始化工作台基线，绑定本地连接器协议 v1.2。',
  },
  {
    id: 'msg-2',
    kind: 'system',
    time: '10:02:14',
    systemTag: '升级章程',
    systemRef: 'CHR-v2.4',
    content: '林知夏 升级了项目章程至 v2.4：新增 §4 硬性约束「单次检索 P99 延迟 ≤ 180ms」。',
  },
  {
    id: 'msg-3',
    kind: 'chat',
    senderName: '陈默',
    senderShort: '陈',
    senderRole: 'owner',
    time: '11:18:40',
    content:
      '我刚对比了 BGE-M3 和 GTE-Qwen2 在长表格切片上的表现，按 512 token 滑窗 + 64 token 重叠切分时，表格跨行召回率能提升 3.2 个百分点，而且不会撑爆 P99 延迟。',
  },
  {
    id: 'msg-4',
    kind: 'agent_report',
    time: '11:24:05',
    agentTool: 'cursor-win-02',
    agentTaskRef: 'TSK-108',
    agentTokens: '14.2k tok',
    agentSummary: '已完成 2,400 条评测样本的向量索引构建与 Top-10 召回跑批，无异常退出。',
    content:
      '执行路径：src/retrieval/vector_eval.py | 耗时：03m48s | 峰值显存：6.4GB | 输出文件：artifacts/eval/recall_bench_v1.4.csv (#7b91e0)',
  },
  {
    id: 'msg-5',
    kind: 'artifact',
    senderName: '陈默',
    senderShort: '陈',
    senderRole: 'owner',
    time: '11:26:12',
    artifactType: '评测报告',
    artifactName: '向量检索模块召回率评测表',
    artifactVersion: 'v1.4.2-rc',
    artifactPath: 'artifacts/eval/recall_bench_v1.4.csv',
    content: '已提交 Top-10 混合检索评测产物（Recall@10 = 94.82%），请周舟按章程 §5 口径核验。',
  },
  {
    id: 'msg-6',
    kind: 'system',
    time: '13:40:09',
    systemTag: '验收退回',
    systemRef: 'TSK-106',
    content: '周舟 退回了任务 TSK-106「负样本基线对齐」的验收申请：缺少困难负样本混淆矩阵附件。',
  },
  {
    id: 'msg-7',
    kind: 'blocker',
    senderName: '许嘉树',
    senderShort: '许',
    senderRole: 'member',
    time: '14:15:33',
    blockerTaskRef: 'TSK-109',
    blockerNeed: '营业执照副本扫描件与企业沙箱网关白名单授权函',
    content:
      '实测环境政务云网关拦截了我们的连接器探针，对方接口人要求先补齐加盖公章的企业营业执照扫描件才能下发测试 Token，目前任务已卡住 5 天。',
  },
  {
    id: 'msg-8',
    kind: 'proposal',
    senderName: '苏哲',
    senderShort: '苏',
    senderRole: 'member',
    time: '15:08:21',
    proposalId: 'DEC-P04',
    proposalStatus: 'pending',
    content:
      '鉴于实测网关仍在等待营业执照，提议将「竞赛答辩演示台」的数据源切换为本地离线加密快照包 v1.4，确保周五路演不受外网联调阻塞影响。',
  },
  {
    id: 'msg-9',
    kind: 'agent_report',
    time: '16:12:49',
    agentTool: 'claude-code-01',
    agentTaskRef: 'TSK-112',
    agentTokens: '9.8k tok',
    agentSummary: '正在扫描多模态图文竞赛集，已剔除 47 张损坏 OCR 图像切片（进度 65%）。',
    content:
      '执行路径：scripts/clean_multimodal.py | 半自动模式：待成员确认是否归档被剔除样本清单。',
  },
  {
    id: 'msg-10',
    kind: 'chat',
    senderName: '周舟',
    senderShort: '周',
    senderRole: 'reviewer',
    time: '16:35:18',
    content:
      '我刚复核完 TSK-108 的评测脚本，建议把重排器的截断阈值固定在 Top-30，这样既能保住 94.8% 的召回率，又能把 P99 延迟稳压在 145ms 以内。',
  },
]

const INITIAL_RISKS: WorkbenchRiskItem[] = [
  {
    id: 'rsk-1',
    severity: 'high',
    taskId: 'TSK-109',
    taskName: '企业实测网关接口联调',
    reason: '阻塞 5 天，等待：营业执照',
  },
  {
    id: 'rsk-2',
    severity: 'high',
    taskId: 'TSK-106',
    taskName: '评测集负样本基线对齐',
    reason: '已逾期 3 天',
  },
  {
    id: 'rsk-3',
    severity: 'medium',
    taskId: 'TSK-108',
    taskName: '向量检索模块召回率评测',
    reason: '等待验收 6 天',
  },
  {
    id: 'rsk-4',
    severity: 'low',
    taskId: 'TSK-114',
    taskName: '多路召回融合重排实验',
    reason: '前置 2 项都已完成，可以开始了',
  },
]

const INITIAL_PENDING_DECISIONS: PendingDecisionItem[] = [
  {
    id: 'DEC-P04',
    title: '路演演示台切换为本地离线加密快照包 v1.4，与外网网关联调解耦',
    proposer: '苏哲',
    proposedAt: '15:08',
    sourceMsgId: 'msg-8',
  },
]

const INITIAL_PENDING_ACCEPTANCE: PendingAcceptanceTask[] = [
  {
    id: 'TSK-108',
    title: '向量检索模块召回率评测与章程指标对齐',
    submitter: '陈默 + cursor-win-02',
    waitDays: 6,
    artifactRef: 'recall_bench_v1.4.csv',
    artifactVersion: 'v1.4.2-rc',
    criteriaNote: '章程 §1/§4：Top-10 召回率 ≥ 93.0% 且 P99 ≤ 180ms（实测 94.82% / 142ms）',
  },
]

const INITIAL_BLOCKED_TASKS: BlockedTaskItem[] = [
  {
    id: 'TSK-109',
    title: '企业实测网关接口联调',
    waitDays: 5,
    needWhat: '需要：营业执照（加盖公章扫描件）',
    owner: '许嘉树',
  },
]

const RUNNING_SESSIONS: RunningAgentSession[] = [
  {
    id: 'SES-91',
    toolType: 'Cursor MCP',
    capability: 'auto',
    taskId: 'TSK-108',
    taskTitle: '向量检索模块召回率评测',
    declaredPath: 'src/retrieval/vector_eval.py',
    duration: '12m 40s',
    tokensUsed: '18.4k tok',
  },
  {
    id: 'SES-94',
    toolType: 'Claude Code CLI',
    capability: 'semi',
    taskId: 'TSK-112',
    taskTitle: '多模态竞赛集异常清洗',
    declaredPath: 'scripts/clean_multimodal.py',
    duration: '06m 15s',
    tokensUsed: '9.8k tok',
  },
]

const INITIAL_CONFIRMED_DECISIONS: ConfirmedDecisionItem[] = [
  {
    id: 'DEC-03',
    title: '采用 BGE-M3 + 轻量 Cross-Encoder 两阶段架构，放弃 70B 全量微调',
    decider: '林知夏',
    time: '05-12 18:20',
  },
  {
    id: 'DEC-02',
    title: '评测基准集统一锁定为 2,400 条脱敏工业问答对，哈希 #9a4c12',
    decider: '陈默',
    time: '05-10 14:05',
  },
]

const LATEST_ARTIFACTS: LatestArtifactItem[] = [
  {
    id: 'ART-19',
    type: '评测报告',
    name: 'recall_bench_v1.4.csv',
    version: 'v1.4.2-rc',
    path: 'artifacts/eval/recall_bench_v1.4.csv',
    time: '11:26',
  },
  {
    id: 'ART-18',
    type: '代码补丁',
    name: 'hybrid_rerank_pipeline.patch',
    version: 'v1.4.0',
    path: 'src/retrieval/rerank.ts',
    time: '昨日 19:40',
  },
  {
    id: 'ART-17',
    type: '答辩材料',
    name: '挑战杯技术白皮书初稿.pdf',
    version: 'v0.8.0',
    path: 'docs/whitepaper_v0.8.pdf',
    time: '昨日 16:12',
  },
]

const AGENT_ENDPOINTS: AgentEndpointItem[] = [
  {
    id: 'ep-1',
    nodeName: 'cursor-win-02',
    toolName: 'Cursor MCP Connector',
    ownerName: '陈默 (Windows 11)',
    activeSessions: 1,
    capability: 'auto',
  },
  {
    id: 'ep-2',
    nodeName: 'claude-code-01',
    toolName: 'Claude Code CLI',
    ownerName: '许嘉树 (WSL2 Ubuntu)',
    activeSessions: 1,
    capability: 'semi',
    degradeNote: '半自动降级：本地沙箱已限制自动 git push，产物需人工确认上传',
  },
  {
    id: 'ep-3',
    nodeName: 'windsurf-03',
    toolName: 'Windsurf Local Bridge',
    ownerName: '周舟 (Windows 11)',
    activeSessions: 0,
    capability: 'auto',
  },
]

/* ============================================================================
   项目工作台主组件 (1440×900 一屏高密度三栏布局)
   ============================================================================ */

export function ProjectWorkbench({
  onOpenDesignSystem,
}: {
  onOpenDesignSystem?: () => void
}) {
  // 当前查看者的身份角色（决定按钮显隐与输入框状态）
  const [currentRole, setCurrentRole] = useState<RoleType>('initiator')

  // 页面状态快速切换：用于验证空状态、无风险、无待办、无端点等边界要求
  const [presetMode, setPresetMode] = useState<'normal' | 'clear_risks_todos' | 'empty_stream'>('normal')

  // 章程展开项
  const [expandedCharterKey, setExpandedCharterKey] = useState<string | null>('acceptance')

  // 消息流与输入状态
  const [messages, setMessages] = useState<StreamMessage[]>(INITIAL_MESSAGES)
  const [msgFilter, setMsgFilter] = useState<'all' | MessageKind>('all')
  const [composeKind, setComposeKind] = useState<'chat' | 'proposal' | 'blocker' | 'artifact'>('chat')
  const [inputText, setInputText] = useState('')
  const [expandedAgentMsgIds, setExpandedAgentMsgIds] = useState<Record<string, boolean>>({})

  // 右区动态事实与待办数据
  const [risks, setRisks] = useState<WorkbenchRiskItem[]>(INITIAL_RISKS)
  const [pendingDecisions, setPendingDecisions] = useState<PendingDecisionItem[]>(
    INITIAL_PENDING_DECISIONS
  )
  const [pendingAcceptance, setPendingAcceptance] = useState<PendingAcceptanceTask[]>(
    INITIAL_PENDING_ACCEPTANCE
  )
  const [blockedTasks, setBlockedTasks] = useState<BlockedTaskItem[]>(INITIAL_BLOCKED_TASKS)
  const [confirmedDecisions, setConfirmedDecisions] = useState<ConfirmedDecisionItem[]>(
    INITIAL_CONFIRMED_DECISIONS
  )
  const [endpointsPresent, setEndpointsPresent] = useState(true)
  const [lastSyncTime, setLastSyncTime] = useState('2025-05-14 16:48:32')

  // 任务验收检视浮层（点击「待验收任务」进入任务检视）
  const [inspectingTask, setInspectingTask] = useState<PendingAcceptanceTask | null>(null)

  // 权限判断
  const isObserver = currentRole === 'observer'
  const canConfirmDecision = currentRole === 'initiator' || currentRole === 'owner'

  // 根据 presetMode 计算实际展示的数据
  const activeRisks = presetMode === 'clear_risks_todos' ? [] : risks
  const activePendingDecisions = presetMode === 'clear_risks_todos' ? [] : pendingDecisions
  const activePendingAcceptance = presetMode === 'clear_risks_todos' ? [] : pendingAcceptance
  const activeBlockedTasks = presetMode === 'clear_risks_todos' ? [] : blockedTasks
  const activeMessages = presetMode === 'empty_stream' ? [] : messages
  const activeEndpoints = presetMode === 'empty_stream' || !endpointsPresent ? [] : AGENT_ENDPOINTS

  const filteredMessages =
    msgFilter === 'all'
      ? activeMessages
      : activeMessages.filter((m) => m.kind === msgFilter)

  const highRiskCount = activeRisks.filter((r) => r.severity === 'high').length
  const medRiskCount = activeRisks.filter((r) => r.severity === 'medium').length
  const lowRiskCount = activeRisks.filter((r) => r.severity === 'low').length

  const hasAnyTodo =
    activePendingDecisions.length > 0 ||
    activePendingAcceptance.length > 0 ||
    activeBlockedTasks.length > 0

  // 动作 1：在普通讨论消息上悬停点击「形成决策」
  const handlePromoteChatToDecision = (msg: StreamMessage) => {
    if (isObserver) return
    const newProposalId = `DEC-P0${pendingDecisions.length + confirmedDecisions.length + 2}`
    const newTitle =
      msg.content.length > 44 ? `${msg.content.slice(0, 44)}...` : msg.content

    // 1) 加入右区「需要处理 -> 待确认的决策」
    setPendingDecisions((prev) => [
      {
        id: newProposalId,
        title: newTitle,
        proposer: msg.senderName || '团队成员',
        proposedAt: '刚刚',
        sourceMsgId: msg.id,
      },
      ...prev,
    ])

    // 2) 在讨论流追加一条「决策提案」卡片
    const proposalMsg: StreamMessage = {
      id: `msg-prop-${Date.now()}`,
      kind: 'proposal',
      senderName: msg.senderName || '陈默',
      senderShort: msg.senderShort || '陈',
      senderRole: msg.senderRole || currentRole,
      time: '16:49:05',
      proposalId: newProposalId,
      proposalStatus: 'pending',
      content: `由讨论提炼决策提案：${msg.content}`,
    }
    setMessages((prev) => [...prev, proposalMsg])
    if (presetMode !== 'normal') setPresetMode('normal')
  }

  // 动作 2：发起人/负责人点击「确认并写入事实层」
  const handleConfirmDecision = (item: PendingDecisionItem) => {
    if (!canConfirmDecision) return
    const currentUserName =
      TEAM_MEMBERS.find((m) => m.role === currentRole)?.name || '林知夏'
    const confirmedId = item.id.replace('-P', '-')

    setPendingDecisions((prev) => prev.filter((d) => d.id !== item.id))
    setConfirmedDecisions((prev) => [
      {
        id: confirmedId,
        title: item.title,
        decider: currentUserName,
        time: '05-14 16:50',
      },
      ...prev,
    ])

    // 更新讨论流内对应提案状态并写入系统事件
    setMessages((prev) => [
      ...prev.map((m) =>
        m.proposalId === item.id ? { ...m, proposalStatus: 'confirmed' as const } : m
      ),
      {
        id: `sys-${Date.now()}`,
        kind: 'system',
        time: '16:50:00',
        systemTag: '事实写入',
        systemRef: confirmedId,
        content: `${currentUserName} 确认了决策提案 [${item.id}] 并写入事实层：${item.title}`,
      },
    ])
    setLastSyncTime('2025-05-14 16:50:00')
  }

  // 动作 3：发送讨论消息（支持 Ctrl/⌘ + Enter）
  const handleSendMessage = () => {
    if (isObserver || !inputText.trim()) return
    const currentMember =
      TEAM_MEMBERS.find((m) => m.role === currentRole) || TEAM_MEMBERS[0]
    const text = inputText.trim()

    if (composeKind === 'proposal') {
      const pid = `DEC-P0${pendingDecisions.length + confirmedDecisions.length + 2}`
      const newMsg: StreamMessage = {
        id: `msg-${Date.now()}`,
        kind: 'proposal',
        senderName: currentMember.name,
        senderShort: currentMember.avatarShort,
        senderRole: currentMember.role,
        time: '16:51:12',
        proposalId: pid,
        proposalStatus: 'pending',
        content: text,
      }
      setMessages((prev) => [...prev, newMsg])
      setPendingDecisions((prev) => [
        {
          id: pid,
          title: text,
          proposer: currentMember.name,
          proposedAt: '16:51',
        },
        ...prev,
      ])
    } else if (composeKind === 'blocker') {
      const newMsg: StreamMessage = {
        id: `msg-${Date.now()}`,
        kind: 'blocker',
        senderName: currentMember.name,
        senderShort: currentMember.avatarShort,
        senderRole: currentMember.role,
        time: '16:51:12',
        blockerTaskRef: 'TSK-114',
        blockerNeed: text,
        content: `登记阻塞求助：${text}`,
      }
      setMessages((prev) => [...prev, newMsg])
    } else if (composeKind === 'artifact') {
      const newMsg: StreamMessage = {
        id: `msg-${Date.now()}`,
        kind: 'artifact',
        senderName: currentMember.name,
        senderShort: currentMember.avatarShort,
        senderRole: currentMember.role,
        time: '16:51:12',
        artifactType: '评测报告',
        artifactName: text,
        artifactVersion: 'v1.4.3',
        artifactPath: 'artifacts/eval/manual_upload.md',
        content: `提交了新产物：${text}`,
      }
      setMessages((prev) => [...prev, newMsg])
    } else {
      const newMsg: StreamMessage = {
        id: `msg-${Date.now()}`,
        kind: 'chat',
        senderName: currentMember.name,
        senderShort: currentMember.avatarShort,
        senderRole: currentMember.role,
        time: '16:51:12',
        content: text,
      }
      setMessages((prev) => [...prev, newMsg])
    }

    setInputText('')
    if (presetMode === 'empty_stream') setPresetMode('normal')
  }

  // 动作 4：验收任务通过或退回
  const handleAcceptTask = (task: PendingAcceptanceTask, approved: boolean) => {
    setPendingAcceptance((prev) => prev.filter((t) => t.id !== task.id))
    setRisks((prev) => prev.filter((r) => r.taskId !== task.id))
    setMessages((prev) => [
      ...prev,
      {
        id: `sys-acc-${Date.now()}`,
        kind: 'system',
        time: '16:52:10',
        systemTag: approved ? '事实写入' : '验收退回',
        systemRef: task.id,
        content: approved
          ? `评审通过任务 ${task.id}「${task.title}」，产物 ${task.artifactRef} (${task.artifactVersion}) 已正式写入当前事实层。`
          : `退回任务 ${task.id}「${task.title}」的验收申请，请补充验证证据后重新提测。`,
      },
    ])
    setInspectingTask(null)
    setLastSyncTime('2025-05-14 16:52:10')
  }

  return (
    <div
      style={{
        backgroundColor: 'var(--cf-surface-paper)',
        color: 'var(--cf-text-primary)',
      }}
      className="flex h-screen w-full flex-col overflow-hidden select-none"
    >
      {/* =====================================================================
          顶部全局工作台顶栏 (42px 高 · 紧凑高密度)
         ===================================================================== */}
      <header
        style={{
          backgroundColor: 'var(--cf-primary)',
          borderBottom: '1px solid var(--cf-primary-deep)',
          color: 'var(--cf-surface-card)',
        }}
        className="flex h-[42px] shrink-0 items-center justify-between px-3.5"
      >
        {/* 左侧：项目标识与当前章程版本 */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div
            style={{
              backgroundColor: 'var(--cf-primary-deep)',
              borderColor: 'var(--cf-primary-border)',
            }}
            className="flex h-[24px] items-center gap-1.5 border px-2 font-mono-tabular text-[11px] font-semibold tracking-wider text-[#A7F3D0]"
          >
            <span className="h-1.5 w-1.5 bg-[#34D399]" />
            <span>COFLOW WORKBENCH</span>
          </div>

          <div className="flex items-center gap-2 truncate">
            <span className="text-[14px] font-semibold tracking-tight text-white">
              多智能体企业知识库混合检索系统
            </span>
            <span
              style={{
                backgroundColor: 'var(--cf-primary-deep)',
                borderColor: 'var(--cf-primary-border)',
              }}
              className="border px-1.5 py-0.5 font-mono-tabular text-[11px] text-[#E3F1F2]"
            >
              PRJ-04 · 章程 CHR-v2.4
            </span>
          </div>

          {/* 观察员只读醒目提示（当切换为观察员时在顶栏同步高亮） */}
          {isObserver && (
            <span
              style={{
                backgroundColor: 'var(--cf-warning)',
                color: 'var(--cf-surface-card)',
              }}
              className="inline-flex h-[22px] items-center gap-1 px-2 text-[11px] font-semibold"
            >
              <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
                <rect x="2" y="5" width="8" height="6" stroke="currentColor" strokeWidth="1.3" />
                <path d="M4 5V3.5C4 2.4 4.9 1.5 6 1.5C7.1 1.5 8 2.4 8 3.5V5" stroke="currentColor" strokeWidth="1.3" />
              </svg>
              <span>当前身份只读（观察员）</span>
            </span>
          )}
        </div>

        {/* 右侧：五种角色视角切换器 + 状态验证预设 + 设计规范书入口 */}
        <div className="flex items-center gap-2.5">
          {/* 角色切换 */}
          <div
            style={{
              backgroundColor: 'var(--cf-primary-deep)',
              borderColor: 'var(--cf-primary-border)',
            }}
            className="flex items-center border p-0.5 text-[11px]"
          >
            <span className="px-2 text-[#A7F3D0] opacity-85">当前视角:</span>
            {(
              [
                { role: 'initiator', label: '发起人' },
                { role: 'owner', label: '负责人' },
                { role: 'reviewer', label: '评审' },
                { role: 'member', label: '成员' },
                { role: 'observer', label: '观察员(只读)' },
              ] as { role: RoleType; label: string }[]
            ).map((item) => (
              <button
                key={item.role}
                type="button"
                onClick={() => setCurrentRole(item.role)}
                style={{
                  backgroundColor:
                    currentRole === item.role ? 'var(--cf-surface-card)' : 'transparent',
                  color:
                    currentRole === item.role
                      ? 'var(--cf-primary-deep)'
                      : 'var(--cf-surface-card)',
                }}
                className="h-[22px] px-2 font-medium transition-colors"
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* 边界状态预设切换（验证空讨论、无风险无待办、无端点） */}
          <div
            style={{
              backgroundColor: 'var(--cf-primary-deep)',
              borderColor: 'var(--cf-primary-border)',
            }}
            className="hidden items-center border p-0.5 text-[11px] xl:flex"
          >
            <span className="px-1.5 text-[#A7F3D0] opacity-85">状态验证:</span>
            {[
              { id: 'normal', label: '完整高密度态' },
              { id: 'clear_risks_todos', label: '无风险 & 无待办态' },
              { id: 'empty_stream', label: '空讨论 & 无端点态' },
            ].map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setPresetMode(p.id as typeof presetMode)}
                style={{
                  backgroundColor:
                    presetMode === p.id ? 'var(--cf-warning)' : 'transparent',
                  color: 'var(--cf-surface-card)',
                }}
                className="h-[22px] px-2 font-medium transition-colors"
              >
                {p.label}
              </button>
            ))}
          </div>

          {onOpenDesignSystem && (
            <button
              type="button"
              onClick={onOpenDesignSystem}
              style={{
                borderColor: 'var(--cf-primary-border)',
                backgroundColor: 'var(--cf-primary-deep)',
              }}
              className="h-[24px] border px-2 font-mono-tabular text-[11px] text-[#E3F1F2] hover:bg-[#062629]"
            >
              查阅令牌与组件库
            </button>
          )}
        </div>
      </header>

      {/* =====================================================================
          主工作台三栏主体 (严格适配 1440×900 剩余高度 858px，三栏独立精密排布)
          A. 方向 (左栏 336px) | B. 讨论 (中栏自适应 ~516px) | C. 要处理的事 (右栏 560px)
         ===================================================================== */}
      <div className="mx-auto grid flex-1 w-full max-w-[1440px] grid-cols-12 overflow-hidden">
        {/* ===================================================================
            A. 方向区 (LEFT COLUMN · 3 cols / 350px · 回答「方向是什么」)
               包含：1. 项目章程(当前版本号) 2. 里程碑列表 3. 成员列表
           =================================================================== */}
        <aside
          style={{
            backgroundColor: 'var(--cf-surface-card)',
            borderRight: '1px solid var(--cf-border-strong)',
          }}
          className="col-span-3 flex h-full flex-col overflow-y-auto select-text"
        >
          {/* 分区眉头 */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-secondary)',
              borderBottom: '1px solid var(--cf-border-strong)',
            }}
            className="flex items-center justify-between px-3 py-2 shrink-0"
          >
            <div className="flex items-center gap-1.5">
              <span
                style={{
                  backgroundColor: 'var(--cf-primary)',
                  color: 'var(--cf-surface-card)',
                }}
                className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold"
              >
                A · 方向
              </span>
              <h2 className="text-[13px] font-semibold text-[var(--cf-text-primary)]">
                项目章程与里程碑基线
              </h2>
            </div>
            <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]">
              事实基线层
            </span>
          </div>

          <div className="flex-1 space-y-3.5 p-3">
            {/* ---------------------------------------------------------------
                A1. 项目章程（当前版本号 CHR-v2.4）
                    五项齐备：项目目标、交付范围、非目标、硬性约束、验收口径
               --------------------------------------------------------------- */}
            <div
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-border-strong)',
                boxShadow: 'var(--cf-shadow-card)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="border"
            >
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderBottom: '1px solid var(--cf-border-strong)',
                }}
                className="flex items-center justify-between px-2.5 py-1.5"
              >
                <div className="flex items-center gap-1.5">
                  <svg
                    width="12"
                    height="12"
                    viewBox="0 0 12 12"
                    fill="none"
                    className="text-[var(--cf-primary)]"
                  >
                    <path
                      d="M2.5 1.5H7.5L10 4V10.5H2.5V1.5Z"
                      stroke="currentColor"
                      strokeWidth="1.3"
                    />
                    <path d="M4.2 6H8.2M4.2 8H7" stroke="currentColor" strokeWidth="1.2" />
                  </svg>
                  <span className="text-[12px] font-semibold text-[var(--cf-text-primary)]">
                    项目章程
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span
                    style={{
                      backgroundColor: 'var(--cf-primary-tint)',
                      color: 'var(--cf-primary)',
                      borderColor: 'var(--cf-primary-border)',
                    }}
                    className="border px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold"
                  >
                    v2.4.0 (已锁定)
                  </span>
                </div>
              </div>

              {/* 五大条款紧凑台账 */}
              <div className="divide-y divide-[var(--cf-border-subtle)]">
                {CHARTER_SECTIONS.map((sec) => {
                  const isExpanded = expandedCharterKey === sec.key
                  return (
                    <div key={sec.key} className="px-2.5 py-1.5">
                      <button
                        type="button"
                        onClick={() =>
                          setExpandedCharterKey(isExpanded ? null : sec.key)
                        }
                        className="flex w-full items-center justify-between text-left"
                      >
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]">
                            {sec.code}
                          </span>
                          <span className="text-[12px] font-semibold text-[var(--cf-text-primary)]">
                            {sec.title}
                          </span>
                        </div>
                        <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                          {isExpanded ? '收起 −' : '细则 +'}
                        </span>
                      </button>
                      <p className="mt-0.5 text-[12px] leading-[17px] text-[var(--cf-text-secondary)]">
                        {sec.summary}
                      </p>
                      {isExpanded && (
                        <ul
                          style={{
                            backgroundColor: 'var(--cf-surface-secondary)',
                            borderColor: 'var(--cf-border-subtle)',
                          }}
                          className="mt-1.5 space-y-1 border-l-2 border-l-[var(--cf-primary)] px-2 py-1 text-[11px] leading-[16px] text-[var(--cf-text-secondary)]"
                        >
                          {sec.details.map((d, i) => (
                            <li key={i}>{d}</li>
                          ))}
                        </ul>
                      )}
                    </div>
                  )
                })}
              </div>
            </div>

            {/* ---------------------------------------------------------------
                A2. 里程碑列表（名称、进度百分比、任务数、状态）
               --------------------------------------------------------------- */}
            <div
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-border-strong)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="border"
            >
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderBottom: '1px solid var(--cf-border-strong)',
                }}
                className="flex items-center justify-between px-2.5 py-1.5"
              >
                <span className="text-[12px] font-semibold text-[var(--cf-text-primary)]">
                  里程碑列表 (Milestones)
                </span>
                <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                  共 4 阶段 · 15/23 任务
                </span>
              </div>

              <div className="divide-y divide-[var(--cf-border-subtle)]">
                {INITIAL_MILESTONES.map((ms) => (
                  <div key={ms.id} className="px-2.5 py-2">
                    <div className="flex items-center justify-between gap-1.5">
                      <span className="truncate text-[12px] font-semibold text-[var(--cf-text-primary)]">
                        {ms.name}
                      </span>
                      <TaskStatusBadge status={ms.status} size="compact" />
                    </div>
                    <div className="mt-1.5 flex items-center gap-2">
                      <div className="flex-1">
                        <ThinProgressBar percent={ms.progress} />
                      </div>
                      <span
                        style={{
                          backgroundColor: 'var(--cf-surface-secondary)',
                          borderColor: 'var(--cf-border-subtle)',
                        }}
                        className="border px-1.5 py-0.5 font-mono-tabular text-[10px] font-medium text-[var(--cf-text-secondary)]"
                      >
                        {ms.doneTasks}/{ms.totalTasks} 任务
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* ---------------------------------------------------------------
                A3. 成员列表（头像、姓名、角色）
               --------------------------------------------------------------- */}
            <div
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-border-strong)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="border"
            >
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderBottom: '1px solid var(--cf-border-strong)',
                }}
                className="flex items-center justify-between px-2.5 py-1.5"
              >
                <span className="text-[12px] font-semibold text-[var(--cf-text-primary)]">
                  项目成员列表 ({TEAM_MEMBERS.length} 人)
                </span>
                <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                  点击顶栏可切换角色视角
                </span>
              </div>

              <div className="divide-y divide-[var(--cf-border-subtle)]">
                {TEAM_MEMBERS.map((member) => {
                  const isCurrentRole = member.role === currentRole
                  return (
                    <div
                      key={member.id}
                      style={{
                        backgroundColor: isCurrentRole
                          ? 'var(--cf-primary-tint)'
                          : undefined,
                      }}
                      className="flex items-center justify-between px-2.5 py-1.5 text-[12px]"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <SingleAvatar
                          item={{
                            id: member.id,
                            name: member.name,
                            short: member.avatarShort,
                            kind: member.kind,
                          }}
                          size={22}
                        />
                        <span className="font-medium text-[var(--cf-text-primary)]">
                          {member.name}
                        </span>
                        <span className="truncate text-[11px] text-[var(--cf-text-tertiary)]">
                          {member.specialty}
                        </span>
                      </div>
                      <RoleBadge role={member.role} />
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        </aside>

        {/* ===================================================================
            B. 讨论区 (CENTER COLUMN · 4 cols / ~480px · 回答「大家在说什么」)
               过程层（底色为亚麻草稿灰 --cf-surface-paper）：
               区分 6 种消息类型 + 悬停「形成决策」 + Ctrl/⌘+Enter 发送 + 空态与只读态
           =================================================================== */}
        <section
          style={{
            backgroundColor: 'var(--cf-surface-paper)',
            borderRight: '1px solid var(--cf-border-strong)',
          }}
          className="col-span-4 flex h-full flex-col overflow-hidden select-text"
        >
          {/* B1. 频道顶栏：频道名 (#general) + 成员头像组 + 消息类型过滤 */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-secondary)',
              borderBottom: '1px solid var(--cf-border-strong)',
            }}
            className="shrink-0 px-3 py-2"
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span
                  style={{
                    backgroundColor: 'var(--cf-neutral)',
                    color: 'var(--cf-surface-card)',
                  }}
                  className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold"
                >
                  B · 讨论过程
                </span>
                <span className="font-mono-tabular text-[14px] font-bold text-[var(--cf-text-primary)]">
                  #general
                </span>
                <span className="text-[11px] text-[var(--cf-text-tertiary)]">
                  过程不等于事实 · 悬停消息可「形成决策」
                </span>
              </div>
              <AvatarGroup items={COLLABORATOR_AVATARS} max={5} />
            </div>

            {/* 消息类型快速筛选器 */}
            <div className="mt-2 flex flex-wrap items-center gap-1 text-[11px]">
              {[
                { id: 'all', label: '全部过程' },
                { id: 'chat', label: '普通讨论' },
                { id: 'proposal', label: '决策提案' },
                { id: 'artifact', label: '产物提交' },
                { id: 'blocker', label: '阻塞求助' },
                { id: 'system', label: '系统事件' },
                { id: 'agent_report', label: 'Agent汇报' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setMsgFilter(tab.id as typeof msgFilter)}
                  style={{
                    backgroundColor:
                      msgFilter === tab.id
                        ? 'var(--cf-primary)'
                        : 'var(--cf-surface-card)',
                    color:
                      msgFilter === tab.id
                        ? 'var(--cf-surface-card)'
                        : 'var(--cf-text-secondary)',
                    borderColor:
                      msgFilter === tab.id
                        ? 'var(--cf-primary)'
                        : 'var(--cf-border-strong)',
                  }}
                  className="h-[20px] border px-1.5 font-medium transition-colors"
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* B2. 消息流（核心设计重点：6 种消息类型视觉层级严格区分） */}
          <div className="flex-1 space-y-2.5 overflow-y-auto p-3">
            {filteredMessages.length === 0 ? (
              /* 空状态：没有任何消息时展示引导文案 */
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-card)',
                  borderColor: 'var(--cf-border-strong)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="my-12 flex flex-col items-center justify-center border border-dashed p-6 text-center"
              >
                <div
                  style={{
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderColor: 'var(--cf-border-strong)',
                  }}
                  className="mb-2 flex h-9 w-9 items-center justify-center border font-mono-tabular text-[13px] font-semibold text-[var(--cf-primary)]"
                >
                  #
                </div>
                <div className="text-[13px] font-semibold text-[var(--cf-text-primary)]">
                  #general 频道暂无讨论记录
                </div>
                <p className="mt-1 max-w-[280px] text-[12px] leading-[18px] text-[var(--cf-text-tertiary)]">
                  在此发起任务澄清、登记阻塞求助，或在任意成员发言上悬停点击「形成决策」将其沉淀为项目待确认事实。
                </p>
                {presetMode === 'empty_stream' && (
                  <button
                    type="button"
                    onClick={() => setPresetMode('normal')}
                    style={{
                      borderColor: 'var(--cf-primary)',
                      color: 'var(--cf-primary)',
                      backgroundColor: 'var(--cf-primary-tint)',
                    }}
                    className="mt-3 h-[24px] border px-2.5 text-[11px] font-medium"
                  >
                    恢复示例讨论流与端点数据
                  </button>
                )}
              </div>
            ) : (
              filteredMessages.map((msg) => {
                /* -----------------------------------------------------------
                   类型 2：系统事件 (System Event)
                   创建项目、升级章程、验收退回 —— 横贯式单行台账刻印条，与聊天截然不同
                   ----------------------------------------------------------- */
                if (msg.kind === 'system') {
                  const isReturn = msg.systemTag === '验收退回'
                  return (
                    <div
                      key={msg.id}
                      style={{
                        backgroundColor: isReturn
                          ? 'var(--cf-danger-bg)'
                          : 'var(--cf-surface-tertiary)',
                        borderColor: isReturn
                          ? 'var(--cf-danger-border)'
                          : 'var(--cf-border-strong)',
                      }}
                      className="flex items-center justify-between gap-2 border-y px-2.5 py-1 text-[11px]"
                    >
                      <div className="flex min-w-0 items-center gap-1.5">
                        <span
                          style={{
                            backgroundColor: isReturn
                              ? 'var(--cf-danger)'
                              : 'var(--cf-neutral)',
                            color: 'var(--cf-surface-card)',
                          }}
                          className="shrink-0 px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold"
                        >
                          系统事件 · {msg.systemTag}
                        </span>
                        {msg.systemRef && (
                          <span className="font-mono-tabular shrink-0 font-semibold text-[var(--cf-primary)]">
                            [{msg.systemRef}]
                          </span>
                        )}
                        <span className="truncate text-[var(--cf-text-secondary)]">
                          {msg.content}
                        </span>
                      </div>
                      <span className="font-mono-tabular shrink-0 text-[10px] text-[var(--cf-text-tertiary)]">
                        {msg.time}
                      </span>
                    </div>
                  )
                }

                /* -----------------------------------------------------------
                   类型 6：Agent 汇报 (Agent Report)
                   必须弱化或折叠，不能和人的发言同级！采用缩进暗槽单行折叠条
                   ----------------------------------------------------------- */
                if (msg.kind === 'agent_report') {
                  const isExpanded = !!expandedAgentMsgIds[msg.id]
                  return (
                    <div
                      key={msg.id}
                      style={{
                        backgroundColor: 'var(--cf-surface-tertiary)',
                        borderColor: 'var(--cf-border-strong)',
                      }}
                      className="ml-5 border-l-2 px-2.5 py-1 text-[11px] text-[var(--cf-text-tertiary)]"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex min-w-0 items-center gap-1.5">
                          <span className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] px-1 font-mono-tabular text-[10px] text-[var(--cf-text-secondary)]">
                            AGENT 汇报
                          </span>
                          <span className="font-mono-tabular font-semibold text-[var(--cf-text-secondary)]">
                            {msg.agentTool}
                          </span>
                          <span className="font-mono-tabular text-[10px]">
                            ({msg.agentTaskRef} · {msg.agentTokens})
                          </span>
                          <span className="truncate text-[var(--cf-text-secondary)]">
                            {msg.agentSummary}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            setExpandedAgentMsgIds((prev) => ({
                              ...prev,
                              [msg.id]: !isExpanded,
                            }))
                          }
                          className="font-mono-tabular shrink-0 text-[10px] text-[var(--cf-primary)] hover:underline"
                        >
                          {isExpanded ? '收起日志 ▲' : '展开详情 ▼'}
                        </button>
                      </div>
                      {isExpanded && (
                        <div className="mt-1 border-t border-dashed border-[var(--cf-border-strong)] pt-1 font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                          {msg.content}
                        </div>
                      )}
                    </div>
                  )
                }

                /* -----------------------------------------------------------
                   类型 3：决策提案 (Decision Proposal) —— 带「决策提案」标记
                   ----------------------------------------------------------- */
                if (msg.kind === 'proposal') {
                  const isConfirmed = msg.proposalStatus === 'confirmed'
                  return (
                    <div
                      key={msg.id}
                      style={{
                        backgroundColor: isConfirmed
                          ? 'var(--cf-success-bg)'
                          : 'var(--cf-warning-bg)',
                        borderColor: isConfirmed
                          ? 'var(--cf-success-border)'
                          : 'var(--cf-warning-border)',
                        borderLeft: isConfirmed
                          ? '4px solid var(--cf-success)'
                          : '4px solid var(--cf-warning)',
                      }}
                      className="border p-2.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          <span
                            style={{
                              backgroundColor: isConfirmed
                                ? 'var(--cf-success)'
                                : 'var(--cf-warning)',
                              color: 'var(--cf-surface-card)',
                            }}
                            className="px-1.5 py-0.5 text-[10px] font-semibold"
                          >
                            决策提案
                          </span>
                          <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-text-primary)]">
                            {msg.proposalId}
                          </span>
                          <span className="text-[12px] font-semibold text-[var(--cf-text-primary)]">
                            {msg.senderName}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono-tabular text-[10px] font-semibold text-[var(--cf-text-secondary)]">
                            {isConfirmed ? '[已写入事实层]' : '[待发起人/负责人确认]'}
                          </span>
                          <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                            {msg.time}
                          </span>
                        </div>
                      </div>
                      <p className="mt-1.5 text-[13px] leading-[19px] text-[var(--cf-text-primary)]">
                        {msg.content}
                      </p>
                    </div>
                  )
                }

                /* -----------------------------------------------------------
                   类型 4：产物提交 (Artifact Submission) —— 带「产物」标记与位置
                   ----------------------------------------------------------- */
                if (msg.kind === 'artifact') {
                  return (
                    <div
                      key={msg.id}
                      style={{
                        backgroundColor: 'var(--cf-surface-card)',
                        borderColor: 'var(--cf-primary-border)',
                        borderLeft: '4px solid var(--cf-primary)',
                        boxShadow: 'var(--cf-shadow-card)',
                      }}
                      className="border p-2.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          <span
                            style={{
                              backgroundColor: 'var(--cf-primary)',
                              color: 'var(--cf-surface-card)',
                            }}
                            className="px-1.5 py-0.5 text-[10px] font-semibold"
                          >
                            产物
                          </span>
                          <span className="text-[12px] font-semibold text-[var(--cf-text-primary)]">
                            {msg.senderName}
                          </span>
                          <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]">
                            {msg.artifactName} ({msg.artifactVersion})
                          </span>
                        </div>
                        <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                          {msg.time}
                        </span>
                      </div>
                      <p className="mt-1 text-[13px] leading-[19px] text-[var(--cf-text-primary)]">
                        {msg.content}
                      </p>
                      <div
                        style={{
                          backgroundColor: 'var(--cf-surface-secondary)',
                          borderColor: 'var(--cf-border-subtle)',
                        }}
                        className="mt-1.5 flex items-center justify-between border px-2 py-1 font-mono-tabular text-[11px]"
                      >
                        <span className="truncate text-[var(--cf-primary)]">
                          位置：{msg.artifactPath}
                        </span>
                        <span className="shrink-0 text-[10px] text-[var(--cf-text-tertiary)]">
                          [{msg.artifactType}]
                        </span>
                      </div>
                    </div>
                  )
                }

                /* -----------------------------------------------------------
                   类型 5：阻塞求助 (Blocker Help) —— 带「阻塞」标记
                   ----------------------------------------------------------- */
                if (msg.kind === 'blocker') {
                  return (
                    <div
                      key={msg.id}
                      style={{
                        backgroundColor: 'var(--cf-danger-bg)',
                        borderColor: 'var(--cf-danger-border)',
                        borderLeft: '4px solid var(--cf-danger)',
                      }}
                      className="border p-2.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          <span
                            style={{
                              backgroundColor: 'var(--cf-danger)',
                              color: 'var(--cf-surface-card)',
                            }}
                            className="px-1.5 py-0.5 text-[10px] font-semibold"
                          >
                            阻塞
                          </span>
                          <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-danger)]">
                            [{msg.blockerTaskRef}]
                          </span>
                          <span className="text-[12px] font-semibold text-[var(--cf-text-primary)]">
                            {msg.senderName}
                          </span>
                        </div>
                        <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                          {msg.time}
                        </span>
                      </div>
                      <p className="mt-1 text-[13px] leading-[19px] text-[var(--cf-text-primary)]">
                        {msg.content}
                      </p>
                      {msg.blockerNeed && (
                        <div
                          style={{
                            backgroundColor: 'var(--cf-surface-card)',
                            borderColor: 'var(--cf-danger-border)',
                            color: 'var(--cf-danger)',
                          }}
                          className="mt-1.5 border px-2 py-1 text-[12px] font-semibold"
                        >
                          需要：{msg.blockerNeed}
                        </div>
                      )}
                    </div>
                  )
                }

                /* -----------------------------------------------------------
                   类型 1：普通讨论 (Normal Chat)
                   头像、姓名、时间、正文 + 悬停出现「形成决策」操作
                   ----------------------------------------------------------- */
                return (
                  <div
                    key={msg.id}
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-subtle)',
                    }}
                    className="group relative border p-2.5 transition-colors hover:border-[var(--cf-border-strong)]"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <SingleAvatar
                          item={{
                            id: msg.id,
                            name: msg.senderName || '成员',
                            short: msg.senderShort || '员',
                            kind: 'human',
                          }}
                          size={22}
                        />
                        <span className="text-[12px] font-semibold text-[var(--cf-text-primary)]">
                          {msg.senderName}
                        </span>
                        {msg.senderRole && <RoleBadge role={msg.senderRole} />}
                      </div>
                      <div className="flex items-center gap-2">
                        {/* 悬停出现「形成决策」操作 */}
                        {!isObserver && (
                          <button
                            type="button"
                            onClick={() => handlePromoteChatToDecision(msg)}
                            style={{
                              backgroundColor: 'var(--cf-primary)',
                              color: 'var(--cf-surface-card)',
                            }}
                            className="hidden h-[20px] items-center gap-1 px-2 text-[11px] font-medium group-hover:inline-flex"
                          >
                            <span>+ 形成决策</span>
                          </button>
                        )}
                        <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                          {msg.time}
                        </span>
                      </div>
                    </div>
                    <p className="mt-1.5 pl-7 text-[13px] leading-[20px] text-[var(--cf-text-primary)]">
                      {msg.content}
                    </p>
                  </div>
                )
              })
            )}
          </div>

          {/* B3. 底部消息输入框（支持 Ctrl/⌘ + Enter 发送；观察员视角禁用并说明只读） */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-secondary)',
              borderTop: '1px solid var(--cf-border-strong)',
            }}
            className="shrink-0 p-2.5"
          >
            {isObserver ? (
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-tertiary)',
                  borderColor: 'var(--cf-border-strong)',
                  color: 'var(--cf-text-secondary)',
                }}
                className="flex h-[64px] flex-col items-center justify-center border border-dashed px-3 text-center text-[12px]"
              >
                <span className="font-semibold text-[var(--cf-text-primary)]">
                  当前身份只读（观察员视角）
                </span>
                <span className="text-[11px] text-[var(--cf-text-tertiary)]">
                  输入框已锁定，无法发送过程讨论或将决策写入事实层。可在顶栏切换为「发起人/负责人」体验完整操作。
                </span>
              </div>
            ) : (
              <div>
                <div className="mb-1.5 flex items-center justify-between text-[11px]">
                  <div className="flex items-center gap-1">
                    <span className="text-[var(--cf-text-tertiary)]">消息标记:</span>
                    {[
                      { id: 'chat', label: '普通讨论' },
                      { id: 'proposal', label: '决策提案' },
                      { id: 'artifact', label: '产物提交' },
                      { id: 'blocker', label: '阻塞求助' },
                    ].map((t) => (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => setComposeKind(t.id as typeof composeKind)}
                        style={{
                          backgroundColor:
                            composeKind === t.id
                              ? 'var(--cf-primary-tint)'
                              : 'var(--cf-surface-card)',
                          color:
                            composeKind === t.id
                              ? 'var(--cf-primary)'
                              : 'var(--cf-text-secondary)',
                          borderColor:
                            composeKind === t.id
                              ? 'var(--cf-primary)'
                              : 'var(--cf-border-strong)',
                        }}
                        className="h-[20px] border px-1.5 font-medium"
                      >
                        {t.label}
                      </button>
                    ))}
                  </div>
                  <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                    Ctrl / ⌘ + Enter 发送
                  </span>
                </div>

                <div className="flex gap-2">
                  <textarea
                    rows={2}
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyDown={(e) => {
                      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                        e.preventDefault()
                        handleSendMessage()
                      }
                    }}
                    placeholder="在 #general 输入讨论内容、登记阻塞或发起决策提案（按 Ctrl/⌘ + Enter 发送）..."
                    style={{
                      backgroundColor: 'var(--cf-surface-card)',
                      borderColor: 'var(--cf-border-strong)',
                      borderRadius: 'var(--cf-radius-control)',
                    }}
                    className="flex-1 resize-none border px-2.5 py-1.5 text-[13px] leading-[18px] text-[var(--cf-text-primary)] outline-none focus:border-[var(--cf-primary)]"
                  />
                  <CfButton
                    variant="primary"
                    size="default"
                    onClick={handleSendMessage}
                  >
                    发送
                  </CfButton>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* ===================================================================
            C. 要处理的事 (RIGHT COLUMN · 5 cols / ~600px · 回答「现在有什么要我处理」)
               按重要性从上到下严格包含全部 7 块：
               1. 风险 (无风险时整块不显示)
               2. 需要处理 (待确认决策 / 待验收任务 / 阻塞任务)
               3. 正在执行 (Agent 会话)
               4. 已确认决策
               5. 最新产物
               6. Agent 端点
               7. 最后同步时间
           =================================================================== */}
        <section
          style={{
            backgroundColor: 'var(--cf-surface-card)',
          }}
          className="col-span-5 flex h-full flex-col overflow-hidden select-text"
        >
          {/* 分区眉头 */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-secondary)',
              borderBottom: '1px solid var(--cf-border-strong)',
            }}
            className="flex shrink-0 items-center justify-between px-3.5 py-2"
          >
            <div className="flex items-center gap-2">
              <span
                style={{
                  backgroundColor: 'var(--cf-danger)',
                  color: 'var(--cf-surface-card)',
                }}
                className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold"
              >
                C · 要处理的事
              </span>
              <h2 className="text-[13px] font-semibold text-[var(--cf-text-primary)]">
                风险告警 · 待办裁决 · 实时事实与端点台账
              </h2>
            </div>
            <div className="flex items-center gap-1.5">
              <KeyValueTag
                k="当前权限"
                v={
                  currentRole === 'initiator'
                    ? '发起人(可写事实)'
                    : currentRole === 'owner'
                      ? '负责人(可写事实)'
                      : currentRole === 'reviewer'
                        ? '评审(可验收)'
                        : currentRole === 'member'
                          ? '成员(执行)'
                          : '观察员(只读)'
                }
                mono={false}
                highlight={canConfirmDecision}
              />
            </div>
          </div>

          {/* 右栏高密度主体（6 大核心区块 + 底部同步时间栏） */}
          <div className="flex-1 space-y-2.5 overflow-y-auto p-3">
            {/* ---------------------------------------------------------------
                C1. 风险（高/中/低三级，每条一行：任务名 + 原因；顶部高/中数量汇总；没有风险时整块不显示）
               --------------------------------------------------------------- */}
            {activeRisks.length > 0 && (
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-card)',
                  borderColor: 'var(--cf-danger)',
                  boxShadow: 'var(--cf-shadow-card)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="border"
              >
                <div
                  style={{
                    backgroundColor: 'var(--cf-danger-bg)',
                    borderBottom: '1px solid var(--cf-danger-border)',
                  }}
                  className="flex items-center justify-between px-2.5 py-1.5"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-[12px] font-bold text-[var(--cf-danger)]">
                      1. 风险 (Risks)
                    </span>
                    <span
                      style={{
                        backgroundColor: 'var(--cf-danger)',
                        color: 'var(--cf-surface-card)',
                      }}
                      className="px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold"
                    >
                      高 {highRiskCount} · 中 {medRiskCount}
                      {lowRiskCount > 0 ? ` · 低 ${lowRiskCount}` : ''}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setPresetMode('clear_risks_todos')}
                    className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)] hover:text-[var(--cf-danger)]"
                  >
                    [模拟全部化解以验证隐藏]
                  </button>
                </div>

                <div className="divide-y divide-[var(--cf-border-subtle)]">
                  {activeRisks.map((r) => {
                    const sevConfig: Record<
                      RiskSeverity,
                      { label: string; bg: string; color: string; leftBar: string }
                    > = {
                      high: {
                        label: '高',
                        bg: 'var(--cf-danger)',
                        color: 'var(--cf-surface-card)',
                        leftBar: 'var(--cf-danger)',
                      },
                      medium: {
                        label: '中',
                        bg: 'var(--cf-warning)',
                        color: 'var(--cf-surface-card)',
                        leftBar: 'var(--cf-warning)',
                      },
                      low: {
                        label: '低',
                        bg: 'var(--cf-info-bg)',
                        color: 'var(--cf-info)',
                        leftBar: 'var(--cf-info)',
                      },
                    }
                    const sc = sevConfig[r.severity]
                    return (
                      <div
                        key={r.id}
                        style={{ borderLeft: `3px solid ${sc.leftBar}` }}
                        className="flex items-center justify-between gap-2 px-2.5 py-1.5 text-[12px]"
                      >
                        <div className="flex min-w-0 items-center gap-1.5">
                          <span
                            style={{ backgroundColor: sc.bg, color: sc.color }}
                            className="inline-flex h-[18px] w-[18px] shrink-0 items-center justify-center font-mono-tabular text-[10px] font-bold"
                          >
                            {sc.label}
                          </span>
                          <span className="font-mono-tabular shrink-0 text-[11px] font-semibold text-[var(--cf-primary)]">
                            {r.taskId}
                          </span>
                          <span className="truncate font-medium text-[var(--cf-text-primary)]">
                            {r.taskName}
                          </span>
                        </div>
                        <span
                          style={{
                            color:
                              r.severity === 'high'
                                ? 'var(--cf-danger)'
                                : r.severity === 'medium'
                                  ? 'var(--cf-warning)'
                                  : 'var(--cf-info)',
                          }}
                          className="shrink-0 font-semibold text-[12px]"
                        >
                          「{r.reason}」
                        </span>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {/* ---------------------------------------------------------------
                C2. 需要处理（待确认决策 / 待验收任务 / 阻塞任务；都没有时显示指定空文案）
               --------------------------------------------------------------- */}
            <div
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-border-strong)',
                boxShadow: 'var(--cf-shadow-card)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="border"
            >
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderBottom: '1px solid var(--cf-border-strong)',
                }}
                className="flex items-center justify-between px-2.5 py-1.5"
              >
                <span className="text-[12px] font-bold text-[var(--cf-text-primary)]">
                  2. 需要处理 (Action Required)
                </span>
                <span className="font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                  决策 {activePendingDecisions.length} · 验收 {activePendingAcceptance.length} · 阻塞{' '}
                  {activeBlockedTasks.length}
                </span>
              </div>

              {!hasAnyTodo ? (
                <div className="px-3 py-4 text-center text-[12px] text-[var(--cf-text-secondary)]">
                  没有待办。当前没有阻塞，也没有等结论的验收。
                </div>
              ) : (
                <div className="divide-y divide-[var(--cf-border-subtle)]">
                  {/* 2a. 待确认的决策（含「确认并写入事实层」按钮，仅发起人/负责人可见） */}
                  {activePendingDecisions.map((dec) => (
                    <div
                      key={dec.id}
                      style={{ backgroundColor: 'var(--cf-warning-bg)' }}
                      className="px-2.5 py-2"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <span
                              style={{
                                backgroundColor: 'var(--cf-warning)',
                                color: 'var(--cf-surface-card)',
                              }}
                              className="px-1.5 py-0.5 text-[10px] font-semibold"
                            >
                              待确认决策
                            </span>
                            <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-text-primary)]">
                              {dec.id}
                            </span>
                            <span className="text-[11px] text-[var(--cf-text-tertiary)]">
                              由 {dec.proposer} 提议于 {dec.proposedAt}
                            </span>
                          </div>
                          <div className="mt-1 text-[12px] font-medium leading-[18px] text-[var(--cf-text-primary)]">
                            {dec.title}
                          </div>
                        </div>

                        {/* 仅发起人/负责人可见「确认并写入事实层」按钮 */}
                        {canConfirmDecision ? (
                          <CfButton
                            variant="primary"
                            size="xs"
                            onClick={() => handleConfirmDecision(dec)}
                          >
                            确认并写入事实层
                          </CfButton>
                        ) : (
                          <span className="font-mono-tabular shrink-0 text-[10px] text-[var(--cf-text-tertiary)]">
                            [仅发起人/负责人可确认]
                          </span>
                        )}
                      </div>
                    </div>
                  ))}

                  {/* 2b. 待验收任务（点击进任务） */}
                  {activePendingAcceptance.map((task) => (
                    <div
                      key={task.id}
                      onClick={() => setInspectingTask(task)}
                      className="group flex cursor-pointer items-center justify-between gap-2 px-2.5 py-2 transition-colors hover:bg-[var(--cf-primary-tint)]/50"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <TaskStatusBadge status="pending_accept" size="compact" />
                          <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]">
                            {task.id}
                          </span>
                          <span className="truncate text-[12px] font-semibold text-[var(--cf-text-primary)] group-hover:text-[var(--cf-primary)]">
                            {task.title}
                          </span>
                        </div>
                        <div className="mt-0.5 flex items-center gap-2 font-mono-tabular text-[11px] text-[var(--cf-text-tertiary)]">
                          <span>产物: {task.artifactRef}</span>
                          <span>·</span>
                          <span className="text-[var(--cf-warning)]">
                            已等待验收 {task.waitDays} 天
                          </span>
                        </div>
                      </div>
                      <span
                        style={{
                          borderColor: 'var(--cf-primary)',
                          color: 'var(--cf-primary)',
                          backgroundColor: 'var(--cf-surface-card)',
                        }}
                        className="shrink-0 border px-2 py-0.5 text-[11px] font-medium group-hover:bg-[var(--cf-primary)] group-hover:text-white"
                      >
                        点击进任务验收 →
                      </span>
                    </div>
                  ))}

                  {/* 2c. 阻塞任务（含"需要：XXX"） */}
                  {activeBlockedTasks.map((blk) => (
                    <div
                      key={blk.id}
                      style={{ backgroundColor: 'var(--cf-danger-bg)' }}
                      className="flex items-center justify-between gap-2 px-2.5 py-2"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <TaskStatusBadge status="blocked" size="compact" />
                          <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-danger)]">
                            {blk.id}
                          </span>
                          <span className="truncate text-[12px] font-semibold text-[var(--cf-text-primary)]">
                            {blk.title}
                          </span>
                          <span className="text-[11px] text-[var(--cf-text-tertiary)]">
                            ({blk.owner})
                          </span>
                        </div>
                      </div>
                      <span
                        style={{
                          backgroundColor: 'var(--cf-surface-card)',
                          borderColor: 'var(--cf-danger)',
                          color: 'var(--cf-danger)',
                        }}
                        className="shrink-0 border px-1.5 py-0.5 text-[11px] font-semibold"
                      >
                        {blk.needWhat}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* ---------------------------------------------------------------
                C3. 正在执行（当前有哪些 Agent 会话在跑：工具类型、所属任务、声明的路径）
               --------------------------------------------------------------- */}
            <div
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-border-strong)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="border"
            >
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderBottom: '1px solid var(--cf-border-strong)',
                }}
                className="flex items-center justify-between px-2.5 py-1.5"
              >
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-[var(--cf-success)]" />
                  <span className="text-[12px] font-bold text-[var(--cf-text-primary)]">
                    3. 正在执行 (Running Agent Sessions)
                  </span>
                </div>
                <span className="font-mono-tabular text-[11px] text-[var(--cf-primary)]">
                  {RUNNING_SESSIONS.length} 个并发会话运行中
                </span>
              </div>

              <div className="divide-y divide-[var(--cf-border-subtle)] text-[12px]">
                {RUNNING_SESSIONS.map((ses) => (
                  <div key={ses.id} className="px-2.5 py-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span
                          style={{
                            backgroundColor: 'var(--cf-primary-tint)',
                            color: 'var(--cf-primary)',
                            borderColor: 'var(--cf-primary-border)',
                          }}
                          className="border px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold"
                        >
                          {ses.toolType}
                        </span>
                        <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]">
                          {ses.taskId}
                        </span>
                        <span className="truncate font-medium text-[var(--cf-text-primary)]">
                          {ses.taskTitle}
                        </span>
                      </div>
                      <span className="font-mono-tabular shrink-0 text-[11px] text-[var(--cf-text-tertiary)]">
                        {ses.duration} · {ses.tokensUsed}
                      </span>
                    </div>
                    <div className="mt-1 flex items-center justify-between font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                      <span className="truncate">
                        声明路径: <strong className="text-[var(--cf-primary)]">{ses.declaredPath}</strong>
                      </span>
                      <span className="text-[10px] text-[var(--cf-text-tertiary)]">
                        {ses.capability === 'auto' ? '自动接入' : '半自动受控'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* ---------------------------------------------------------------
                C4. 已确认决策 & C5. 最新产物（双栏紧凑并列或上下台账，完整展示每项字段）
               --------------------------------------------------------------- */}
            <div className="grid grid-cols-1 gap-2.5 xl:grid-cols-2">
              {/* C4. 已确认决策（标题、决策人、时间） */}
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-card)',
                  borderColor: 'var(--cf-border-strong)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="border"
              >
                <div
                  style={{
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderBottom: '1px solid var(--cf-border-strong)',
                  }}
                  className="flex items-center justify-between px-2.5 py-1.5"
                >
                  <span className="text-[12px] font-bold text-[var(--cf-text-primary)]">
                    4. 已确认决策
                  </span>
                  <span className="font-mono-tabular text-[10px] text-[var(--cf-success)]">
                    事实层 ({confirmedDecisions.length})
                  </span>
                </div>
                <div className="divide-y divide-[var(--cf-border-subtle)]">
                  {confirmedDecisions.map((d) => (
                    <div key={d.id} className="px-2.5 py-1.5">
                      <div className="text-[12px] font-medium leading-[17px] text-[var(--cf-text-primary)]">
                        <span className="font-mono-tabular mr-1 text-[11px] font-semibold text-[var(--cf-primary)]">
                          [{d.id}]
                        </span>
                        {d.title}
                      </div>
                      <div className="mt-1 flex items-center justify-between font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                        <span>决策人：{d.decider}</span>
                        <span>{d.time}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* C5. 最新产物（类型、名称、版本） */}
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-card)',
                  borderColor: 'var(--cf-border-strong)',
                  borderRadius: 'var(--cf-radius-container)',
                }}
                className="border"
              >
                <div
                  style={{
                    backgroundColor: 'var(--cf-surface-secondary)',
                    borderBottom: '1px solid var(--cf-border-strong)',
                  }}
                  className="flex items-center justify-between px-2.5 py-1.5"
                >
                  <span className="text-[12px] font-bold text-[var(--cf-text-primary)]">
                    5. 最新产物
                  </span>
                  <span className="font-mono-tabular text-[10px] text-[var(--cf-primary)]">
                    证据库 ({LATEST_ARTIFACTS.length})
                  </span>
                </div>
                <div className="divide-y divide-[var(--cf-border-subtle)]">
                  {LATEST_ARTIFACTS.map((art) => (
                    <div key={art.id} className="px-2.5 py-1.5">
                      <div className="flex items-center justify-between gap-1.5">
                        <div className="flex min-w-0 items-center gap-1.5">
                          <span
                            style={{
                              backgroundColor: 'var(--cf-surface-secondary)',
                              borderColor: 'var(--cf-border-strong)',
                            }}
                            className="shrink-0 border px-1 py-0.5 text-[10px] font-medium text-[var(--cf-text-secondary)]"
                          >
                            {art.type}
                          </span>
                          <span className="truncate font-mono-tabular text-[11px] font-semibold text-[var(--cf-text-primary)]">
                            {art.name}
                          </span>
                        </div>
                        <span
                          style={{
                            backgroundColor: 'var(--cf-primary-tint)',
                            color: 'var(--cf-primary)',
                          }}
                          className="shrink-0 px-1.5 py-0.5 font-mono-tabular text-[10px] font-semibold"
                        >
                          {art.version}
                        </span>
                      </div>
                      <div className="mt-0.5 flex items-center justify-between font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                        <span className="truncate">{art.path}</span>
                        <span className="shrink-0">{art.time}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* ---------------------------------------------------------------
                C6. Agent 端点（可用端点数量、执行中的会话数；没有端点时显示引导）
               --------------------------------------------------------------- */}
            <div
              style={{
                backgroundColor: 'var(--cf-surface-card)',
                borderColor: 'var(--cf-border-strong)',
                borderRadius: 'var(--cf-radius-container)',
              }}
              className="border"
            >
              <div
                style={{
                  backgroundColor: 'var(--cf-surface-secondary)',
                  borderBottom: '1px solid var(--cf-border-strong)',
                }}
                className="flex items-center justify-between px-2.5 py-1.5"
              >
                <div className="flex items-center gap-2">
                  <span className="text-[12px] font-bold text-[var(--cf-text-primary)]">
                    6. Agent 端点 (Local Connectors)
                  </span>
                  <span className="font-mono-tabular text-[11px] font-semibold text-[var(--cf-primary)]">
                    可用端点 {activeEndpoints.length} · 执行中会话{' '}
                    {activeEndpoints.reduce((acc, e) => acc + e.activeSessions, 0)}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setEndpointsPresent((v) => !v)}
                  className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)] hover:text-[var(--cf-primary)]"
                >
                  {activeEndpoints.length > 0 ? '[模拟无端点引导态]' : '[恢复端点列表]'}
                </button>
              </div>

              {activeEndpoints.length === 0 ? (
                <div className="flex items-center justify-between gap-3 px-3 py-3 text-[12px]">
                  <div>
                    <div className="font-semibold text-[var(--cf-text-primary)]">
                      当前没有可用的本地 Agent 端点
                    </div>
                    <div className="text-[11px] text-[var(--cf-text-tertiary)]">
                      在成员电脑终端运行{' '}
                      <code className="font-mono-tabular text-[var(--cf-primary)]">
                        npx @coflow/connector --project PRJ-04
                      </code>{' '}
                      即可接入 Cursor / Claude Code 领任务。
                    </div>
                  </div>
                  <CfButton
                    variant="secondary"
                    size="xs"
                    onClick={() => {
                      setEndpointsPresent(true)
                      if (presetMode === 'empty_stream') setPresetMode('normal')
                    }}
                  >
                    + 接入端点引导
                  </CfButton>
                </div>
              ) : (
                <div className="divide-y divide-[var(--cf-border-subtle)]">
                  {activeEndpoints.map((ep) => (
                    <div key={ep.id} className="px-2.5 py-1.5 text-[11px]">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="h-2 w-2 shrink-0 rounded-full bg-[var(--cf-success)]" />
                          <span className="font-mono-tabular font-semibold text-[var(--cf-text-primary)]">
                            {ep.nodeName}
                          </span>
                          <span className="truncate text-[var(--cf-text-secondary)]">
                            {ep.toolName} · {ep.ownerName}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <CapabilityBadge level={ep.capability} />
                          <span className="font-mono-tabular text-[11px] text-[var(--cf-text-secondary)]">
                            会话: <strong>{ep.activeSessions}</strong>
                          </span>
                        </div>
                      </div>
                      {ep.degradeNote && (
                        <div className="mt-1 border-l-2 border-[var(--cf-warning)] bg-[var(--cf-warning-bg)] px-2 py-0.5 text-[11px] text-[var(--cf-warning)]">
                          {ep.degradeNote}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* -----------------------------------------------------------------
              C7. 最后同步时间（固定底栏，随时可查事实同步新鲜度）
             ----------------------------------------------------------------- */}
          <div
            style={{
              backgroundColor: 'var(--cf-surface-secondary)',
              borderTop: '1px solid var(--cf-border-strong)',
            }}
            className="flex h-[30px] shrink-0 items-center justify-between px-3 text-[11px]"
          >
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 bg-[var(--cf-success)]" />
              <span className="font-semibold text-[var(--cf-text-secondary)]">
                7. 最后同步时间：
              </span>
              <span className="font-mono-tabular font-semibold text-[var(--cf-text-primary)]">
                {lastSyncTime}
              </span>
              <span className="font-mono-tabular text-[10px] text-[var(--cf-text-tertiary)]">
                (MCP 事实总线正常 · 延迟 14ms)
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                const now = new Date()
                const pad = (n: number) => String(n).padStart(2, '0')
                setLastSyncTime(
                  `2025-05-14 ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(
                    now.getSeconds()
                  )}`
                )
              }}
              className="font-mono-tabular text-[11px] font-medium text-[var(--cf-primary)] hover:underline"
            >
              [立即同步]
            </button>
          </div>
        </section>
      </div>

      {/* =====================================================================
          任务验收详情浮层（点击右区「2. 需要处理 -> 待验收任务」时打开）
         ===================================================================== */}
      {inspectingTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div
            style={{
              backgroundColor: 'var(--cf-surface-card)',
              borderColor: 'var(--cf-border-strong)',
              boxShadow: 'var(--cf-shadow-float)',
              borderRadius: 'var(--cf-radius-container)',
            }}
            className="w-full max-w-lg border p-5 select-text"
          >
            <div className="flex items-center justify-between border-b border-[var(--cf-border-strong)] pb-3">
              <div className="flex items-center gap-2">
                <TaskStatusBadge status="pending_accept" size="compact" />
                <span className="font-mono-tabular text-[13px] font-bold text-[var(--cf-primary)]">
                  {inspectingTask.id}
                </span>
                <h3 className="text-[15px] font-semibold text-[var(--cf-text-primary)]">
                  人工验收核验单
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setInspectingTask(null)}
                className="font-mono-tabular text-[12px] text-[var(--cf-text-tertiary)] hover:text-[var(--cf-text-primary)]"
              >
                关闭 [ESC]
              </button>
            </div>

            <div className="mt-3 space-y-2.5 text-[13px]">
              <div>
                <div className="text-[11px] text-[var(--cf-text-tertiary)]">任务名称：</div>
                <div className="font-semibold text-[var(--cf-text-primary)]">
                  {inspectingTask.title}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 font-mono-tabular text-[12px]">
                <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)] p-2">
                  <div className="text-[10px] text-[var(--cf-text-tertiary)]">提交者与节点</div>
                  <div className="mt-0.5 font-semibold">{inspectingTask.submitter}</div>
                </div>
                <div className="border border-[var(--cf-border-subtle)] bg-[var(--cf-surface-secondary)] p-2">
                  <div className="text-[10px] text-[var(--cf-text-tertiary)]">证据产物版本</div>
                  <div className="mt-0.5 font-semibold text-[var(--cf-primary)]">
                    {inspectingTask.artifactRef} ({inspectingTask.artifactVersion})
                  </div>
                </div>
              </div>
              <div className="border border-[var(--cf-border-strong)] bg-[var(--cf-surface-secondary)] p-2.5 text-[12px]">
                <div className="font-semibold text-[var(--cf-text-primary)]">
                  对应章程验收口径核对：
                </div>
                <div className="mt-1 text-[var(--cf-text-secondary)]">
                  {inspectingTask.criteriaNote}
                </div>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-between border-t border-[var(--cf-border-subtle)] pt-3">
              <span className="text-[11px] text-[var(--cf-text-tertiary)]">
                {isObserver
                  ? '当前为观察员只读身份，不可签批验收结论'
                  : '签批后结论将写入右侧「已确认事实」并解除逾期风险'}
              </span>
              <div className="flex items-center gap-2">
                <CfButton
                  variant="secondary"
                  size="sm"
                  onClick={() => setInspectingTask(null)}
                >
                  暂不处理
                </CfButton>
                {!isObserver && (
                  <>
                    <CfButton
                      variant="danger"
                      size="sm"
                      onClick={() => handleAcceptTask(inspectingTask, false)}
                    >
                      退回返工
                    </CfButton>
                    <CfButton
                      variant="primary"
                      size="sm"
                      onClick={() => handleAcceptTask(inspectingTask, true)}
                    >
                      验收通过并入库
                    </CfButton>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
